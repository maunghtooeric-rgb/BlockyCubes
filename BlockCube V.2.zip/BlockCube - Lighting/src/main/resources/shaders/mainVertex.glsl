#version 330 core

layout(location = 0) in vec3 aPos;
layout(location = 1) in vec2 aUV;
layout(location = 2) in float aTexID;
layout(location = 3) in float aSunLight;
layout(location = 4) in float aBlockLight;
layout(location = 5) in float aAmbientOcclusion;

out vec2 vUV;
out float vTexID;
out float vSunLight;
out float vBlockLight;
out float vAmbientOcclusion;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main() {
    gl_Position = projection * view * model * vec4(aPos, 1.0);
    vUV         = aUV;
    vTexID      = aTexID;
    vSunLight   = aSunLight;
    vBlockLight = aBlockLight;
    vAmbientOcclusion = aAmbientOcclusion;
}