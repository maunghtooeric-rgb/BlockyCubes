#version 330 core

in vec2 vUV;
in float vTexID;
in float vSunLight;
in float vBlockLight;
in float vAmbientOcclusion;

out vec4 FragColor;

uniform sampler2D textures[8];
uniform bool useColorOverride;
uniform vec3 overrideColor;
uniform float daylight; // 0–1
uniform float alpha = 1.0; // Alpha transparency (1.0 = opaque, 0.0 = transparent)

void main() {
    if (useColorOverride) {
        FragColor = vec4(overrideColor, 1.0);
        return;
    }

    int id = int(vTexID);
    vec4 texColor = texture(textures[id], vUV);

    float ambient = 0.35;

    // True dual-channel:
    // - Sunlight is affected by day/night
    // - Block light is NOT affected by day/night
    float sun   = vSunLight * daylight;
    float block = vBlockLight;

    float finalLight = max(max(sun, block), ambient);
    
    // Apply ambient occlusion as a shadow multiplier
    // AO value: 1.0 = no shadow, 0.0 = full shadow
    // This creates smooth shadows in corners and on block sides
    finalLight *= vAmbientOcclusion;

    // Apply alpha transparency (for x-ray mode)
    FragColor = vec4(texColor.rgb * finalLight, texColor.a * alpha);
}