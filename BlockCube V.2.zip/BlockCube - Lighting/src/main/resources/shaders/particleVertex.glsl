#version 330 core

layout(location = 0) in vec3 aPos;   // quad vertex (-0.5..0.5)
layout(location = 1) in vec2 aUV;
layout(location = 2) in float aTexID;

out vec2 vUV;

uniform mat4 view;
uniform mat4 projection;

uniform vec3 particlePos;   // world-space center of the particle
uniform float particleScale;

uniform vec3 camRight;
uniform vec3 camUp;

void main() {
    // Build billboard quad in world space
    vec3 worldPos =
        particlePos +
        camRight * aPos.x * particleScale +
        camUp    * aPos.y * particleScale;

    gl_Position = projection * view * vec4(worldPos, 1.0);

    vUV = aUV;
}