#version 330 core

in vec2 vUV;
out vec4 FragColor;

uniform sampler2D particleTex;
uniform bool useParticleTex;

void main() {
    if (useParticleTex) {
        FragColor = texture(particleTex, vUV);
    } else {
        FragColor = vec4(1, 0, 1, 1); // fallback magenta
    }
}