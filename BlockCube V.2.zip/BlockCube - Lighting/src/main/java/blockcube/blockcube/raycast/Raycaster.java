package blockcube.blockcube.raycast;

import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;
import blockcube.blockcube.objects.Camera;

public class Raycaster {
	
	private Vector3f normal;
	public Vector3f getNormal() { return normal; }
    private static int lastStepAxis = 0; // 1 = X, 2 = Y, 3 = Z

    public static RaycastResult raycast(Camera camera, ChunkManager chunkManager, float maxDistance) {
        // 1. Ray origin and direction
        Vector3f pos = camera.getPosition();
        Vector3f rot = camera.getRotation();

        float pitch = (float) Math.toRadians(rot.getX());
        float yaw   = (float) Math.toRadians(rot.getY());

        float dx = (float) (-Math.sin(yaw) * Math.cos(pitch));
        float dy = (float) ( Math.sin(pitch));
        float dz = (float) (-Math.cos(yaw) * Math.cos(pitch));

        Vector3f dir = Vector3f.normalize(new Vector3f(dx, dy, dz));
        dx = dir.getX();
        dy = dir.getY();
        dz = dir.getZ();

        // 2. Starting block (world space)
        int bx = (int) Math.floor(pos.getX());
        int by = (int) Math.floor(pos.getY());
        int bz = (int) Math.floor(pos.getZ());

        // 3. Step direction per axis
        int stepX = dx > 0 ? 1 : (dx < 0 ? -1 : 0);
        int stepY = dy > 0 ? 1 : (dy < 0 ? -1 : 0);
        int stepZ = dz > 0 ? 1 : (dz < 0 ? -1 : 0);

        // 4. Distance to the first boundary on each axis (tMax)
        float tMaxX, tMaxY, tMaxZ;
        float tDeltaX, tDeltaY, tDeltaZ;

        // We parametrize the ray as: origin + t * dir, in world units

        if (stepX != 0) {
            float nextBoundaryX = stepX > 0 ? (bx + 1.0f) : (bx * 1.0f);
            tMaxX = (nextBoundaryX - pos.getX()) / dx;
            tDeltaX = 1.0f / Math.abs(dx);
        } else {
            tMaxX = Float.POSITIVE_INFINITY;
            tDeltaX = Float.POSITIVE_INFINITY;
        }

        if (stepY != 0) {
            float nextBoundaryY = stepY > 0 ? (by + 1.0f) : (by * 1.0f);
            tMaxY = (nextBoundaryY - pos.getY()) / dy;
            tDeltaY = 1.0f / Math.abs(dy);
        } else {
            tMaxY = Float.POSITIVE_INFINITY;
            tDeltaY = Float.POSITIVE_INFINITY;
        }

        if (stepZ != 0) {
            float nextBoundaryZ = stepZ > 0 ? (bz + 1.0f) : (bz * 1.0f);
            tMaxZ = (nextBoundaryZ - pos.getZ()) / dz;
            tDeltaZ = 1.0f / Math.abs(dz);
        } else {
            tMaxZ = Float.POSITIVE_INFINITY;
            tDeltaZ = Float.POSITIVE_INFINITY;
        }

        float t = 0.0f; // how far along the ray we are

        // 5. Traverse the grid
        while (t <= maxDistance) {

            // Check if current block is raycastable (solid blocks OR vegetation)
            if (chunkManager.isRaycastableAtWorld(bx, by, bz)) {
                // Compute exact hit position
                float hitX = pos.getX() + dx * t;
                float hitY = pos.getY() + dy * t;
                float hitZ = pos.getZ() + dz * t;

                // Normal comes from which axis we stepped last
                int nx = 0, ny = 0, nz = 0;

                if (lastStepAxis == 1) nx = -stepX;
                if (lastStepAxis == 2) ny = -stepY;
                if (lastStepAxis == 3) nz = -stepZ;

                // We don't know which axis we hit from this loop directly,
                // so we track it when we step:
                // BUT simpler: we can approximate normal from comparing hit vs block center.
                float cx = bx + 0.5f;
                float cy = by + 0.5f;
                float cz = bz + 0.5f;

                float ax = Math.abs(hitX - cx);
                float ay = Math.abs(hitY - cy);
                float az = Math.abs(hitZ - cz);

                if (ax > ay && ax > az) {
                    nx = (hitX > cx) ? -1 : 1;
                } else if (ay > ax && ay > az) {
                    ny = (hitY > cy) ? -1 : 1;
                } else {
                    nz = (hitZ > cz) ? -1 : 1;
                }

                Vector3f hitPos = new Vector3f(hitX, hitY, hitZ);
                return new RaycastResult(hitPos, bx, by, bz, -nx, -ny, -nz);
            }

            // Advance to next voxel
            if (tMaxX < tMaxY) {
                if (tMaxX < tMaxZ) {
                    bx += stepX;
                    lastStepAxis = 1;
                    t = tMaxX;
                    tMaxX += tDeltaX;
                } else {
                    bz += stepZ;
                    lastStepAxis = 3;
                    t = tMaxZ;
                    tMaxZ += tDeltaZ;
                }
            } else {
                if (tMaxY < tMaxZ) {
                    by += stepY;
                    lastStepAxis = 2;
                    t = tMaxY;
                    tMaxY += tDeltaY;
                } else {
                    bz += stepZ;
                    lastStepAxis = 3;
                    t = tMaxZ;
                    tMaxZ += tDeltaZ;
                }
            }

            }

        return null; // nothing hit
    }
}