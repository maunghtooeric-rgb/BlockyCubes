package blockcube.blockcube.raycast;

import blockcube.blockcube.math.Vector3f;

public class RaycastResult {
    private final Vector3f hitPos;      // exact hit position in world space
    private final int blockX, blockY, blockZ;        // solid block hit
    private final int normalX, normalY, normalZ;     // face normal
    private final int placeX, placeY, placeZ;        // adjacent block pos for placing
    private final Vector3f normal;                   // normal as vector

    public RaycastResult(Vector3f hitPos,
                         int blockX, int blockY, int blockZ,
                         int normalX, int normalY, int normalZ) {

        this.hitPos = hitPos;
        this.blockX = blockX;
        this.blockY = blockY;
        this.blockZ = blockZ;

        this.normalX = normalX;
        this.normalY = normalY;
        this.normalZ = normalZ;

        // FIXED: use the correct variables
        this.normal = new Vector3f(normalX, normalY, normalZ);

        // Block to place into = block hit + normal
        this.placeX = blockX + normalX;
        this.placeY = blockY + normalY;
        this.placeZ = blockZ + normalZ;
    }

    public Vector3f getHitPos() { return hitPos; }

    public int getBlockX() { return blockX; }
    public int getBlockY() { return blockY; }
    public int getBlockZ() { return blockZ; }

    public int getNormalX() { return normalX; }
    public int getNormalY() { return normalY; }
    public int getNormalZ() { return normalZ; }

    public int getPlaceX() { return placeX; }
    public int getPlaceY() { return placeY; }
    public int getPlaceZ() { return placeZ; }

    public Vector3f getNormal() { return normal; }

    @Override
    public String toString() {
        return "Hit block [" + blockX + "," + blockY + "," + blockZ +
               "] normal [" + normalX + "," + normalY + "," + normalZ + "]" +
               " placeAt [" + placeX + "," + placeY + "," + placeZ + "]";
    }
}