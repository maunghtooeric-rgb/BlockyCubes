package blockcube.blockcube.objects;

import org.lwjgl.glfw.GLFW;

import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.io.Input;
import blockcube.blockcube.math.Vector3f;

public class Camera {
	private Vector3f position, rotation;
	private float moveSpeed = 0.05f, mouseSensitivity = 0.15f;
	private double oldMouseX = 0, oldMouseY = 0, newMouseX, newMouseY;
	
	private float velocityY = 0f;
	private boolean onGround = false;
	private boolean wasJumpPressed = false; // Track previous frame's jump key state

	private final float gravity = -0.005f;   // falling speed
	private final float jumpStrength = 0.2f; // Initial upward velocity when jumping
	private final float playerWidth = 0.2f;
	private final float playerHeight = 1.8f;
	
	public Camera(Vector3f position, Vector3f rotation) {
		this.position = position;
		this.rotation = rotation;
	}
	
	public void update(ChunkManager chunkManager) {
		update(chunkManager, true, false);
	}
	
	public void update(ChunkManager chunkManager, boolean allowMovement) {
		update(chunkManager, allowMovement, false);
	}
	
	public void update(ChunkManager chunkManager, boolean allowMovement, boolean flyMode) {

	    // 1. Mouse look (unchanged)
	    newMouseX = Input.getMouseX();
	    newMouseY = Input.getMouseY();
	    float dx = (float)(newMouseX - oldMouseX);
	    float dy = (float)(newMouseY - oldMouseY);
	    rotation = Vector3f.add(rotation, new Vector3f(-dy * mouseSensitivity, -dx * mouseSensitivity, 0));
	    rotation.setX(Math.max(-89, Math.min(89, rotation.getX())));
	    oldMouseX = newMouseX;
	    oldMouseY = newMouseY;

	    // FLY MODE: Simplified movement without collision or gravity
	    if (flyMode && allowMovement) {
	        float x = (float)Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
	        float z = (float)Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;
	        
	        // Horizontal movement
	        if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { position.setX(position.getX() - z); position.setZ(position.getZ() + x); }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { position.setX(position.getX() + z); position.setZ(position.getZ() - x); }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { position.setX(position.getX() - x); position.setZ(position.getZ() - z); }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { position.setX(position.getX() + x); position.setZ(position.getZ() + z); }
	        
	        // Vertical movement (fly up/down)
	        if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) {
	            position.setY(position.getY() + moveSpeed);
	        }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT) || Input.isKeyDown(GLFW.GLFW_KEY_RIGHT_SHIFT)) {
	            position.setY(position.getY() - moveSpeed);
	        }
	        
	        // Reset velocity when entering fly mode
	        velocityY = 0;
	        onGround = false;
	        return; // Skip all collision and physics
	    }

	 // Horizontal movement vector
	    float xMove = 0;
	    float zMove = 0;

	    // Only process WASD movement if movement is allowed
	    if (allowMovement) {
	        float x = (float)Math.sin(Math.toRadians(rotation.getY())) * moveSpeed;
	        float z = (float)Math.cos(Math.toRadians(rotation.getY())) * moveSpeed;

	        if (Input.isKeyDown(GLFW.GLFW_KEY_A)) { xMove -= z; zMove += x; }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_D)) { xMove += z; zMove -= x; }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_W)) { xMove -= x; zMove -= z; }
	        if (Input.isKeyDown(GLFW.GLFW_KEY_S)) { xMove += x; zMove += z; }
	    }

	    // Note: nextY will be calculated AFTER jump and gravity are applied

	    // Horizontal movement - check at both current Y and predicted next Y to handle slopes
	    // This allows smooth movement when going up/down slopes
	    // Use current position for now, nextY will be calculated after jump/gravity
	    float currentY = position.getY();
	    float predictedNextY = currentY + velocityY; // Predict next Y for collision checks
	    float testY1 = currentY;
	    float testY2 = predictedNextY;
	    
	    float nextX = position.getX() + xMove;
	    float nextZ = position.getZ() + zMove;
	    
	    // Try X movement - check at both Y positions to allow movement on slopes
	    boolean xMoveSuccess = false;
	    if (xMove != 0) {
	        // Try at current Y first
	        if (!collidesAt(chunkManager, nextX, testY1, position.getZ())) {
	            position.setX(nextX);
	            xMoveSuccess = true;
	        } else if (!collidesAt(chunkManager, nextX, testY2, position.getZ())) {
	            // If current Y fails, try at next Y (for going down slopes)
	            position.setX(nextX);
	            xMoveSuccess = true;
	        }
	    } else {
	        xMoveSuccess = true; // No X movement attempted
	    }
	    
	    // Try Z movement - use updated X position if X movement succeeded
	    boolean zMoveSuccess = false;
	    if (zMove != 0) {
	        float testZ = position.getZ() + zMove;
	        float testX = position.getX(); // Use current X (may have been updated)
	        
	        // Try at current Y first
	        if (!collidesAt(chunkManager, testX, testY1, testZ)) {
	            position.setZ(testZ);
	            zMoveSuccess = true;
	        } else if (!collidesAt(chunkManager, testX, testY2, testZ)) {
	            // If current Y fails, try at next Y (for going down slopes)
	            position.setZ(testZ);
	            zMoveSuccess = true;
	        }
	    } else {
	        zMoveSuccess = true; // No Z movement attempted
	    }
	    
	    // If diagonal movement failed, try corner sliding with reduced movement
	    if ((xMove != 0 && zMove != 0) && (!xMoveSuccess || !zMoveSuccess)) {
	        // Try moving mostly in one direction if the other failed
	        if (!xMoveSuccess && zMoveSuccess) {
	            // X failed but Z succeeded - try reduced X movement
	            float reducedX = position.getX() + xMove * 0.5f;
	            if (!collidesAt(chunkManager, reducedX, testY1, position.getZ()) ||
	                !collidesAt(chunkManager, reducedX, testY2, position.getZ())) {
	                position.setX(reducedX);
	            }
	        } else if (xMoveSuccess && !zMoveSuccess) {
	            // Z failed but X succeeded - try reduced Z movement
	            float reducedZ = position.getZ() + zMove * 0.5f;
	            if (!collidesAt(chunkManager, position.getX(), testY1, reducedZ) ||
	                !collidesAt(chunkManager, position.getX(), testY2, reducedZ)) {
	                position.setZ(reducedZ);
	            }
	        }
	    }

	    // 3. REMOVE THIS OLD FLYING LOGIC:
	    // if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) position = ...
	    // if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT)) position = ...

	    // 4. JUMP HANDLING - Check BEFORE gravity and ground detection
	    // Ground check: if there's a solid block directly below the player's feet, they can jump
	    float currentFeetY = position.getY() - playerHeight;
	    
	    // Check if there's a solid block below the player's feet (within reasonable tolerance)
	    // This allows jumping when standing on any solid block
	    boolean currentlyOnGround = false;
	    
	    // Check multiple points around player's feet to ensure we detect ground properly
	    float checkRadius = playerWidth * 0.9f;
	    float groundCheckTolerance = 0.3f; // Generous tolerance - check slightly below feet
	    
	    // Check the block directly at feet level (most common case)
	    int checkBlockY = (int)Math.floor(currentFeetY);
	    if (isBlockSolid(chunkManager, position.getX(), checkBlockY, position.getZ())) {
	        currentlyOnGround = true;
	    }
	    
	    // Also check slightly below feet (for when player is slightly above ground)
	    if (!currentlyOnGround) {
	        int checkBlockYBelow = (int)Math.floor(currentFeetY - groundCheckTolerance);
	        if (isBlockSolid(chunkManager, position.getX(), checkBlockYBelow, position.getZ())) {
	            currentlyOnGround = true;
	        }
	    }
	    
	    // Check corners if center didn't find ground
	    if (!currentlyOnGround) {
	        if (isBlockSolid(chunkManager, position.getX() - checkRadius, checkBlockY, position.getZ() - checkRadius) ||
	            isBlockSolid(chunkManager, position.getX() + checkRadius, checkBlockY, position.getZ() - checkRadius) ||
	            isBlockSolid(chunkManager, position.getX() - checkRadius, checkBlockY, position.getZ() + checkRadius) ||
	            isBlockSolid(chunkManager, position.getX() + checkRadius, checkBlockY, position.getZ() + checkRadius)) {
	            currentlyOnGround = true;
	        }
	    }
	    
	    // Check edges if still not found
	    if (!currentlyOnGround) {
	        if (isBlockSolid(chunkManager, position.getX(), checkBlockY, position.getZ() - checkRadius) ||
	            isBlockSolid(chunkManager, position.getX(), checkBlockY, position.getZ() + checkRadius) ||
	            isBlockSolid(chunkManager, position.getX() - checkRadius, checkBlockY, position.getZ()) ||
	            isBlockSolid(chunkManager, position.getX() + checkRadius, checkBlockY, position.getZ())) {
	            currentlyOnGround = true;
	        }
	    }
	    
	    // Also check if player was on ground in previous frame and not moving (for more reliable jumping)
	    // This helps when the player is moving or at the edge of blocks
	    if (!currentlyOnGround && onGround && velocityY == 0) {
	        currentlyOnGround = true; // If we were on ground and not moving, we're still on ground
	    }
	    
	    // Jump handling - only jump once when key is first pressed, not every frame
	    boolean isJumpPressed = Input.isKeyDown(GLFW.GLFW_KEY_SPACE);
	    
	    // IMPORTANT: Only apply jump if:
	    // 1. Player is on ground (use currentlyOnGround OR onGround as fallback)
	    // 2. Jump key was just pressed (edge detection)
	    // 3. Player is not already moving upward (prevent double jump)
	    boolean canJump = (currentlyOnGround || onGround) && velocityY <= 0;
	    if (canJump && isJumpPressed && !wasJumpPressed) {
	        // Apply jumpStrength EXACTLY as specified - this is the ONLY place velocityY should be set to jumpStrength
	        // jumpStrength directly controls jump height - no other modifications or overrides
	        velocityY = jumpStrength; // Use jumpStrength directly, no modifications, no additions, no multiplications
	        onGround = false;
	        currentlyOnGround = false; // Ensure we don't jump again this frame
	    }
	    wasJumpPressed = isJumpPressed; // Remember state for next frame

	    // 5. APPLY GRAVITY (reduces upward velocity over time)
	    // This is the ONLY place velocityY should be modified after jump (except collision resets)
	    velocityY += gravity;

	    // NOW calculate nextY with the updated velocity (after jump and gravity)
	    float nextY = position.getY() + velocityY;
	    
	    // HEAD COLLISION (ceiling) - check after velocity is updated
	    if (velocityY > 0) {  // only when moving upward
	        float headY = nextY; // top of player
	        boolean hitCeiling = isBlockSolid(chunkManager,
	            position.getX(),
	            headY,
	            position.getZ()
	        );

	        if (hitCeiling) {
	            // Stop upward movement
	            velocityY = 0;

	            // Snap player just below the ceiling block
	            float ceilingBlockY = (float)Math.floor(headY);
	            position.setY(ceilingBlockY - 0.001f); // tiny offset to avoid jitter
	            nextY = position.getY(); // update nextY so ground logic uses correct value
	        }
	    }

	    // 6. GROUND DETECTION - check multiple points including corners
	    // Check at the new horizontal position (after movement) to handle slopes correctly
	    float feetY = nextY - playerHeight;
	    float checkX = position.getX(); // Use updated X position
	    float checkZ = position.getZ(); // Use updated Z position
	    
	    // Only check for ground if moving downward or stationary (not when jumping upward)
	    // This prevents the ground from canceling jumps
	    boolean belowSolid = false;
	    if (velocityY <= 0) {
	        // Only check ground when falling or stationary
	        belowSolid = isStandingOnSolid(chunkManager, checkX, feetY, checkZ);
	        
	        // Additional check: make sure feet are actually at or below the block top
	        // This prevents false positives when just starting to jump
	        if (belowSolid) {
	            // Find the highest block the player might be standing on
	            float highestBlockTop = -Float.MAX_VALUE;
	            for (int bx = (int)Math.floor(checkX - playerWidth); bx <= (int)Math.ceil(checkX + playerWidth); bx++) {
	                for (int bz = (int)Math.floor(checkZ - playerWidth); bz <= (int)Math.ceil(checkZ + playerWidth); bz++) {
	                    // Check block at feet level
	                    int blockY = (int)Math.floor(feetY);
	                    if (isBlockSolid(chunkManager, bx, blockY, bz)) {
	                        float blockTop = blockY + 1.0f;
	                        if (blockTop > highestBlockTop) {
	                            highestBlockTop = blockTop;
	                        }
	                    }
	                }
	            }
	            
	            // Only consider it "standing on solid" if feet are actually at or below block top
	            // Add small tolerance to account for floating point precision
	            float groundTolerance = 0.05f;
	            if (highestBlockTop > -Float.MAX_VALUE && feetY <= highestBlockTop + groundTolerance) {
	                belowSolid = true;
	            } else {
	                belowSolid = false; // Feet are above ground, not standing on it
	            }
	        }
	    }

	    if (belowSolid) {
	        velocityY = 0;
	        onGround = true;

	        // Snap exactly to the top of the block you're standing on
	        // Find the highest block the player is standing on
	        float highestBlockTop = -Float.MAX_VALUE;
	        for (int bx = (int)Math.floor(checkX - playerWidth); bx <= (int)Math.ceil(checkX + playerWidth); bx++) {
	            for (int bz = (int)Math.floor(checkZ - playerWidth); bz <= (int)Math.ceil(checkZ + playerWidth); bz++) {
	                int blockY = (int)Math.floor(feetY);
	                if (isBlockSolid(chunkManager, bx, blockY, bz)) {
	                    float blockTop = blockY + 1.0f;
	                    if (blockTop > highestBlockTop) {
	                        highestBlockTop = blockTop;
	                    }
	                }
	            }
	        }
	        
	        if (highestBlockTop > -Float.MAX_VALUE) {
	            position.setY(highestBlockTop + playerHeight);
	        } else {
	            // Fallback to original method
	            float blockTop = (float)Math.floor(feetY) + 1.0f;
	            position.setY(blockTop + playerHeight);
	        }
	    } else {
	        onGround = false;
	        position.setY(nextY);
	    }
	    
	    // 7. PREVENT CAMERA CLIPPING - push camera out of blocks to prevent seeing through faces
	    preventCameraClipping(chunkManager);
	}

	public Vector3f getPosition() {
		return position;
	}

	public Vector3f getRotation() {
		return rotation;
	}
	
	public boolean collidesAt(ChunkManager chunkManager, float x, float y, float z) {
	    // Player feet to head
	    float minY = y - playerHeight;
	    float maxY = y;
	    float feetY = minY; // Player's feet position

	    // Player width (square) - add small epsilon to allow movement when just touching
	    float epsilon = 0.001f; // Small tolerance to prevent getting stuck
	    float minX = x - playerWidth - epsilon;
	    float maxX = x + playerWidth + epsilon;
	    float minZ = z - playerWidth - epsilon;
	    float maxZ = z + playerWidth + epsilon;

	    // Tolerance for floor detection - blocks at or slightly below feet are considered floor
	    float floorTolerance = 0.1f; // Allow small gap for floor blocks

	    // Check all blocks inside this bounding box
	    // Use ceil for max values to ensure we check all potentially overlapping blocks
	    for (int bx = (int)Math.floor(minX); bx <= (int)Math.ceil(maxX); bx++) {
	        for (int by = (int)Math.floor(minY); by <= (int)Math.ceil(maxY); by++) {
	            for (int bz = (int)Math.floor(minZ); bz <= (int)Math.ceil(maxZ); bz++) {
	                if (chunkManager.isSolidAtWorld(bx, by, bz)) {
	                    // Check if there's actual overlap (not just touching edges)
	                    float blockMinX = bx;
	                    float blockMaxX = bx + 1.0f;
	                    float blockMinY = by;
	                    float blockMaxY = by + 1.0f;
	                    float blockMinZ = bz;
	                    float blockMaxZ = bz + 1.0f;
	                    
	                    // IGNORE FLOOR BLOCKS: If the block's top is at or below the player's feet,
	                    // it's a floor block and shouldn't block horizontal movement
	                    if (blockMaxY <= feetY + floorTolerance) {
	                        continue; // Skip this block - it's the floor
	                    }
	                    
	                    // Check for actual intersection (not just touching)
	                    boolean overlapX = maxX > blockMinX && minX < blockMaxX;
	                    boolean overlapY = maxY > blockMinY && minY < blockMaxY;
	                    boolean overlapZ = maxZ > blockMinZ && minZ < blockMaxZ;
	                    
	                    if (overlapX && overlapY && overlapZ) {
	                        return true;
	                    }
	                }
	            }
	        }
	    }

	    return false;
	}
	
	public boolean wouldCollideWithBlock(int bx, int by, int bz) {
	    // Player AABB
	    float playerMinX = position.getX() - playerWidth;
	    float playerMaxX = position.getX() + playerWidth;
	    float playerMinY = position.getY() - playerHeight;
	    float playerMaxY = position.getY();
	    float playerMinZ = position.getZ() - playerWidth;
	    float playerMaxZ = position.getZ() + playerWidth;

	    // Block AABB
	    float blockMinX = bx;
	    float blockMaxX = bx + 1.0f;
	    float blockMinY = by;
	    float blockMaxY = by + 1.0f;
	    float blockMinZ = bz;
	    float blockMaxZ = bz + 1.0f;

	    // If the block is fully below the player's feet, allow it
	    float feetY = playerMinY;
	    if (blockMaxY <= feetY) {
	        return false; // no collision relevant to being "inside" the block
	    }

	    boolean overlapX = playerMaxX > blockMinX && playerMinX < blockMaxX;
	    boolean overlapY = playerMaxY > blockMinY && playerMinY < blockMaxY;
	    boolean overlapZ = playerMaxZ > blockMinZ && playerMinZ < blockMaxZ;

	    return overlapX && overlapY && overlapZ;
	}
	
	public Vector3f getForwardVector() {
	    // rotation.x = pitch (up/down), rotation.y = yaw (left/right)
	    float pitchRad = (float)Math.toRadians(rotation.getX());
	    float yawRad   = (float)Math.toRadians(rotation.getY());

	    float x = (float)(-Math.sin(yawRad) * Math.cos(pitchRad));
	    float y = (float)( Math.sin(pitchRad));
	    float z = (float)(-Math.cos(yawRad) * Math.cos(pitchRad));

	    return new Vector3f(x, y, z);
	}
	
	public Vector3f getRightVector() {
	    float yaw = (float)Math.toRadians(rotation.getY());

	    float x = (float)Math.cos(yaw);
	    float y = 0;
	    float z = (float)-Math.sin(yaw);

	    return new Vector3f(x, y, z);
	}
	
	public Vector3f getUpVector() {
	    Vector3f forward = getForwardVector();
	    Vector3f right = getRightVector();

	    // up = right × forward
	    float ux = right.getY() * forward.getZ() - right.getZ() * forward.getY();
	    float uy = right.getZ() * forward.getX() - right.getX() * forward.getZ();
	    float uz = right.getX() * forward.getY() - right.getY() * forward.getX();

	    return new Vector3f(ux, uy, uz);
	}
	
	
	
	public boolean isBlockSolid(ChunkManager chunkManager, float x, float y, float z) {
	    int bx = (int)Math.floor(x);
	    int by = (int)Math.floor(y);
	    int bz = (int)Math.floor(z);
	    return chunkManager.isSolidAtWorld(bx, by, bz);
	}
	
	// Check if player is standing on a solid block (checks corners too)
	private boolean isStandingOnSolid(ChunkManager chunkManager, float x, float feetY, float z) {
	    // Check multiple points around the player's feet area to handle corners
	    float checkRadius = playerWidth * 0.9f; // Slightly smaller than player width
	    
	    // Check center
	    if (isBlockSolid(chunkManager, x, feetY, z)) {
	        return true;
	    }
	    
	    // Check corners
	    if (isBlockSolid(chunkManager, x - checkRadius, feetY, z - checkRadius) ||
	        isBlockSolid(chunkManager, x + checkRadius, feetY, z - checkRadius) ||
	        isBlockSolid(chunkManager, x - checkRadius, feetY, z + checkRadius) ||
	        isBlockSolid(chunkManager, x + checkRadius, feetY, z + checkRadius)) {
	        return true;
	    }
	    
	    // Check edges (optional, for better coverage)
	    if (isBlockSolid(chunkManager, x, feetY, z - checkRadius) ||
	        isBlockSolid(chunkManager, x, feetY, z + checkRadius) ||
	        isBlockSolid(chunkManager, x - checkRadius, feetY, z) ||
	        isBlockSolid(chunkManager, x + checkRadius, feetY, z)) {
	        return true;
	    }
	    
	    return false;
	}
	
	// Prevent camera from clipping into blocks by pushing it out if it's inside a block
	// Only prevents horizontal clipping (X/Z) to avoid interfering with jumping
	private void preventCameraClipping(ChunkManager chunkManager) {
	    // Skip clipping prevention when moving upward (jumping) - let ceiling collision handle it
	    if (velocityY > 0) {
	        return; // Don't interfere with upward movement
	    }
	    
	    // Check if camera head position (eye level) is inside a block
	    float headX = position.getX();
	    float headY = position.getY();
	    float headZ = position.getZ();
	    
	    // Small offset to push camera outside blocks
	    float eyeRadius = 0.1f;
	    
	    // Check blocks in a small radius around the camera head
	    int blockX = (int)Math.floor(headX);
	    int blockY = (int)Math.floor(headY);
	    int blockZ = (int)Math.floor(headZ);
	    
	    for (int bx = blockX - 1; bx <= blockX + 1; bx++) {
	        for (int by = blockY - 1; by <= blockY + 1; by++) {
	            for (int bz = blockZ - 1; bz <= blockZ + 1; bz++) {
	                if (chunkManager.isSolidAtWorld(bx, by, bz)) {
	                    // Check if camera head is inside this block
	                    float blockMinX = bx;
	                    float blockMaxX = bx + 1.0f;
	                    float blockMinY = by;
	                    float blockMaxY = by + 1.0f;
	                    float blockMinZ = bz;
	                    float blockMaxZ = bz + 1.0f;
	                    
	                    if (headX > blockMinX && headX < blockMaxX &&
	                        headY > blockMinY && headY < blockMaxY &&
	                        headZ > blockMinZ && headZ < blockMaxZ) {
	                        
	                        // Camera is inside this block, push it out
	                        // Only push horizontally (X/Z) to avoid interfering with jumping/falling
	                        // Vertical clipping is handled by ceiling/ground collision
	                        float blockCenterX = bx + 0.5f;
	                        float blockCenterZ = bz + 0.5f;
	                        
	                        float dx = headX - blockCenterX;
	                        float dz = headZ - blockCenterZ;
	                        
	                        float absDx = Math.abs(dx);
	                        float absDz = Math.abs(dz);
	                        
	                        // Push out horizontally along the closest face (X or Z)
	                        if (absDx <= absDz) {
	                            // Push along X axis
	                            float pushX = (dx > 0 ? 1.0f : -1.0f) * (0.5f - absDx + eyeRadius);
	                            position.setX(position.getX() + pushX);
	                        } else {
	                            // Push along Z axis
	                            float pushZ = (dz > 0 ? 1.0f : -1.0f) * (0.5f - absDz + eyeRadius);
	                            position.setZ(position.getZ() + pushZ);
	                        }
	                    }
	                }
	            }
	        }
	    }
	}
}
