package blockcube.blockcube.entity.ai;

import blockcube.blockcube.entity.Entity;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;

/**
 * Zombie AI (Minecraft Alpha-style hostile mob)
 * - Wanders when player is far away
 * - Moves straight toward player when in range (no pathfinding)
 * - Tries to jump over obstacles
 */
public class ZombieAI implements AIBehavior {
    
    // Detection range
    private static final float DETECTION_RANGE = 16.0f; // Blocks
    private static final float CHASE_SPEED_MULTIPLIER = 1.2f;
    private static final float WANDER_SPEED_MULTIPLIER = 0.6f;
    
    // State
    private boolean isChasing = false;
    private float moveDirection = 0.0f;
    private float speedMultiplier = 1.0f;
    private boolean wantsJump = false;
    
    // Wander state (when not chasing)
    private float wanderTimer = 0.0f;
    private float wanderChangeInterval = 4.0f;
    
    public ZombieAI() {
        this.moveDirection = (float)(Math.random() * 360.0);
    }
    
    @Override
    public void update(Entity entity, ChunkManager chunkManager, Vector3f playerPos, float deltaTime) {
        wantsJump = false;
        Vector3f pos = entity.getPosition();
        
        // Calculate distance to player
        float dx = playerPos.getX() - pos.getX();
        float dz = playerPos.getZ() - pos.getZ();
        float distanceToPlayer = (float)Math.sqrt(dx * dx + dz * dz);
        
        // Check if player is in range
        if (distanceToPlayer <= DETECTION_RANGE) {
            // Chase mode - move directly toward player
            isChasing = true;
            
            // Calculate direction to player
            moveDirection = (float)Math.toDegrees(Math.atan2(dx, dz));
            if (moveDirection < 0) moveDirection += 360.0f;
            
            speedMultiplier = CHASE_SPEED_MULTIPLIER;
        } else {
            // Wander mode
            isChasing = false;
            speedMultiplier = WANDER_SPEED_MULTIPLIER;
            
            // Update wander timer
            wanderTimer += deltaTime;
            if (wanderTimer >= wanderChangeInterval) {
                wanderTimer = 0.0f;
                moveDirection += (float)(Math.random() * 90.0 - 45.0);
                normalizeDirection();
                wanderChangeInterval = 3.0f + (float)(Math.random() * 3.0);
            }
        }
        
        // Check for obstacles ahead
        float checkDistance = 1.0f;
        float dirRad = (float)Math.toRadians(moveDirection);
        float checkX = pos.getX() + (float)Math.sin(dirRad) * checkDistance;
        float checkZ = pos.getZ() + (float)Math.cos(dirRad) * checkDistance;
        float feetY = pos.getY() - entity.getHeight();
        
        int blockX = (int)Math.floor(checkX);
        int blockY = (int)Math.floor(feetY + 0.5f);
        int blockZ = (int)Math.floor(checkZ);
        
        boolean wallAhead = chunkManager.isSolidAtWorld(blockX, blockY, blockZ);
        
        if (wallAhead) {
            // Check if we can jump over
            boolean canJumpOver = !chunkManager.isSolidAtWorld(blockX, blockY + 1, blockZ) &&
                                  !chunkManager.isSolidAtWorld(blockX, blockY + 2, blockZ);
            if (canJumpOver && entity.isOnGround()) {
                wantsJump = true;
            } else if (!isChasing) {
                // Only turn if not chasing (zombies are persistent when chasing)
                moveDirection += 90.0f;
                normalizeDirection();
            }
        }
        
        // If not chasing, avoid cliffs
        if (!isChasing) {
            boolean groundAhead = chunkManager.isSolidAtWorld(blockX, blockY - 1, blockZ);
            if (!groundAhead) {
                moveDirection += 180.0f;
                normalizeDirection();
            }
        }
    }
    
    private void normalizeDirection() {
        while (moveDirection < 0) moveDirection += 360.0f;
        while (moveDirection >= 360.0f) moveDirection -= 360.0f;
    }
    
    @Override
    public float getMovementDirection() {
        return moveDirection;
    }
    
    @Override
    public boolean wantsToJump() {
        return wantsJump;
    }
    
    @Override
    public float getSpeedMultiplier() {
        return speedMultiplier;
    }
    
    public boolean isChasing() {
        return isChasing;
    }
}
