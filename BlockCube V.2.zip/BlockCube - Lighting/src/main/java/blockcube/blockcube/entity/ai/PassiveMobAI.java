package blockcube.blockcube.entity.ai;

import blockcube.blockcube.entity.Entity;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;

/**
 * Minecraft Alpha-style passive mob AI
 * 
 * SIMPLE BEHAVIOR (no pathfinding):
 * 1. Pick a random direction
 * 2. Face that direction IMMEDIATELY
 * 3. Walk straight forward for a few seconds
 * 4. Stop and idle for a moment
 * 5. Repeat
 * 
 * If blocked by a wall, just stop and pick a new direction.
 * NO smooth turning - instant direction changes like Alpha.
 */
public class PassiveMobAI implements AIBehavior {
    
    // Current facing direction (degrees, 0-360)
    private float facingDirection = 0.0f;
    
    // State machine
    private enum State { WALKING, IDLE }
    private State currentState = State.IDLE;
    
    // Timers
    private float stateTimer = 0.0f;
    private float walkDuration = 3.0f;
    private float idleDuration = 1.0f;
    
    // Movement
    private float speedMultiplier = 1.0f;
    private boolean wantsJump = false;
    private int blockedFrames = 0;
    
    public PassiveMobAI() {
        // Start in idle state, will pick direction when transitioning to walk
        this.currentState = State.IDLE;
        this.stateTimer = 0.0f;
        this.idleDuration = 0.5f + (float)(Math.random() * 1.0f); // Short initial idle
        this.facingDirection = (float)(Math.random() * 360.0);
    }
    
    @Override
    public void update(Entity entity, ChunkManager chunkManager, Vector3f playerPos, float deltaTime) {
        wantsJump = false;
        stateTimer += deltaTime;
        
        switch (currentState) {
            case IDLE:
                updateIdle(entity, deltaTime);
                break;
            case WALKING:
                updateWalking(entity, chunkManager, deltaTime);
                break;
        }
    }
    
    private void updateIdle(Entity entity, float deltaTime) {
        speedMultiplier = 0.0f;
        
        // Wait for idle duration to pass
        if (stateTimer >= idleDuration) {
            // Transition to walking
            currentState = State.WALKING;
            stateTimer = 0.0f;
            
            // Pick a completely new random direction INSTANTLY
            facingDirection = (float)(Math.random() * 360.0);
            
            // Random walk duration (2-6 seconds)
            walkDuration = 2.0f + (float)(Math.random() * 4.0);
            
            blockedFrames = 0;
        }
    }
    
    private void updateWalking(Entity entity, ChunkManager chunkManager, float deltaTime) {
        speedMultiplier = 1.0f;
        
        // Check if blocked by a wall ahead
        Vector3f pos = entity.getPosition();
        float checkDist = 0.6f;
        float dirRad = (float)Math.toRadians(facingDirection);
        float aheadX = pos.getX() + (float)Math.sin(dirRad) * checkDist;
        float aheadZ = pos.getZ() + (float)Math.cos(dirRad) * checkDist;
        
        int blockX = (int)Math.floor(aheadX);
        int blockZ = (int)Math.floor(aheadZ);
        int groundY = (int)Math.floor(pos.getY()) - 1;
        
        // Check for wall at body level (block above ground)
        boolean wallAhead = chunkManager.isSolidAtWorld(blockX, groundY + 1, blockZ);
        
        if (wallAhead) {
            blockedFrames++;
            speedMultiplier = 0.0f; // Stop moving
            
            // After being blocked for a bit, pick new direction
            if (blockedFrames > 30) { // About 0.5 seconds at 60fps
                // Pick new direction and keep walking
                facingDirection = (float)(Math.random() * 360.0);
                blockedFrames = 0;
            }
        } else {
            blockedFrames = 0;
        }
        
        // Check if walk duration is over
        if (stateTimer >= walkDuration) {
            // Transition to idle
            currentState = State.IDLE;
            stateTimer = 0.0f;
            
            // Random idle duration (1-3 seconds)
            idleDuration = 1.0f + (float)(Math.random() * 2.0);
        }
    }
    
    @Override
    public float getMovementDirection() {
        // Return -1 when idle (no movement)
        if (currentState == State.IDLE) {
            return -1;
        }
        return facingDirection;
    }
    
    @Override
    public boolean wantsToJump() {
        return wantsJump;
    }
    
    @Override
    public float getSpeedMultiplier() {
        return speedMultiplier;
    }
    
    // For external access
    public float getWanderDirection() {
        return facingDirection;
    }
    
    public void setWanderDirection(float direction) {
        this.facingDirection = direction;
        while (facingDirection < 0) facingDirection += 360.0f;
        while (facingDirection >= 360.0f) facingDirection -= 360.0f;
    }
    
    public boolean isIdle() {
        return currentState == State.IDLE;
    }
}
