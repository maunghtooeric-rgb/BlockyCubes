package blockcube.blockcube.entity;

import blockcube.blockcube.entity.ai.AIBehavior;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;

/**
 * Base class for all entities (mobs, items, etc.)
 */
public abstract class Entity {
    protected Vector3f position;
    protected Vector3f velocity;
    protected float width;
    protected float height;
    protected float depth; // For non-cubic entities like pigs
    protected boolean onGround;
    protected float yaw; // Rotation around Y axis (facing direction)
    
    // AI behavior (can be null for non-AI entities)
    protected AIBehavior ai;
    
    public Entity(Vector3f position, float width, float height) {
        this.position = position;
        this.velocity = new Vector3f(0, 0, 0);
        this.width = width;
        this.height = height;
        this.depth = width; // Default to square
        this.onGround = false;
        this.yaw = 0;
        this.ai = null;
    }
    
    public Entity(Vector3f position, float width, float height, float depth) {
        this.position = position;
        this.velocity = new Vector3f(0, 0, 0);
        this.width = width;
        this.height = height;
        this.depth = depth;
        this.onGround = false;
        this.yaw = 0;
        this.ai = null;
    }
    
    public Vector3f getPosition() {
        return position;
    }
    
    public void setPosition(Vector3f position) {
        this.position = position;
    }
    
    public Vector3f getVelocity() {
        return velocity;
    }
    
    public void setVelocity(Vector3f velocity) {
        this.velocity = velocity;
    }
    
    public float getWidth() {
        return width;
    }
    
    public float getHeight() {
        return height;
    }
    
    public float getDepth() {
        return depth;
    }
    
    public boolean isOnGround() {
        return onGround;
    }
    
    public void setOnGround(boolean onGround) {
        this.onGround = onGround;
    }
    
    public float getYaw() {
        return yaw;
    }
    
    public void setYaw(float yaw) {
        this.yaw = yaw;
    }
    
    public AIBehavior getAI() {
        return ai;
    }
    
    public void setAI(AIBehavior ai) {
        this.ai = ai;
    }
    
    /**
     * Update AI behavior
     * @param chunkManager World for collision checks
     * @param playerPos Player position for chase behaviors
     * @param deltaTime Time since last update
     */
    public void updateAI(ChunkManager chunkManager, Vector3f playerPos, float deltaTime) {
        if (ai != null) {
            ai.update(this, chunkManager, playerPos, deltaTime);
            // Note: Yaw is smoothly interpolated by EntityManager, not set directly here
        }
    }
    
    /**
     * Update entity logic (called every frame)
     * @param deltaTime Time since last frame
     */
    public abstract void update(float deltaTime);
}
