package blockcube.blockcube.entity.ai;

import blockcube.blockcube.entity.Entity;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;

/**
 * Interface for AI behaviors (Minecraft Alpha-style)
 * Each AI implementation defines how an entity behaves in the world.
 */
public interface AIBehavior {
    
    /**
     * Update the entity's AI behavior
     * @param entity The entity being controlled
     * @param chunkManager The world (for collision/block checks)
     * @param playerPos The player's position (for chase behaviors)
     * @param deltaTime Time since last update
     */
    void update(Entity entity, ChunkManager chunkManager, Vector3f playerPos, float deltaTime);
    
    /**
     * Get the desired movement direction in degrees (0-360)
     * @return Movement direction in degrees, or -1 if not moving
     */
    float getMovementDirection();
    
    /**
     * Check if the AI wants the entity to jump
     * @return true if the entity should jump
     */
    boolean wantsToJump();
    
    /**
     * Get the movement speed multiplier (0-1)
     * @return Speed multiplier
     */
    float getSpeedMultiplier();
}
