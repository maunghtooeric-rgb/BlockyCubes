package blockcube.blockcube.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import blockcube.blockcube.entity.ai.AIBehavior;
import blockcube.blockcube.graphics.Chunk;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.math.Vector3f;

/**
 * Manages all entities in the world
 */
public class EntityManager {
    private final ChunkManager chunkManager;
    private final List<Entity> entities;
    private final Map<String, List<Entity>> entitiesByChunk; // Key: "cx,cz"
    private static final int MAX_MOBS_PER_CHUNK = 10;
    
    // Reference to player position for AI behaviors
    private Vector3f playerPosition = new Vector3f(0, 60, 0);
    
    public EntityManager(ChunkManager chunkManager) {
        this.chunkManager = chunkManager;
        this.entities = new ArrayList<>();
        this.entitiesByChunk = new HashMap<>();
    }
    
    /**
     * Update the player position reference (called from Main)
     */
    public void setPlayerPosition(Vector3f playerPos) {
        this.playerPosition = playerPos;
    }
    
    /**
     * Get all entities
     */
    public List<Entity> getEntities() {
        return entities;
    }
    
    /**
     * Add an entity to the world
     */
    public void addEntity(Entity entity) {
        entities.add(entity);
        updateEntityChunk(entity);
    }
    
    /**
     * Remove an entity from the world
     */
    public void removeEntity(Entity entity) {
        entities.remove(entity);
        // Remove from chunk tracking
        for (List<Entity> chunkEntities : entitiesByChunk.values()) {
            chunkEntities.remove(entity);
        }
    }
    
    /**
     * Update all entities and their AI
     */
    public void update(float deltaTime) {
        for (Entity entity : entities) {
            // Update AI behavior first
            entity.updateAI(chunkManager, playerPosition, deltaTime);
            
            // Update entity physics/movement
            if (entity instanceof PigMob) {
                updatePigMobPhysics((PigMob) entity, deltaTime);
            }
            
            entity.update(deltaTime);
        }
    }
    
    /**
     * Update physics for a PigMob - gravity, collision, and movement
     * Pig position represents FEET level (bottom of entity)
     */
    private void updatePigMobPhysics(PigMob pig, float deltaTime) {
        Vector3f pos = pig.getPosition();
        Vector3f vel = pig.getVelocity();
        AIBehavior ai = pig.getAI();
        
        float pigWidth = pig.getWidth();
        float pigHeight = pig.getHeight();
        
        // ========== 1. GET AI INPUTS ==========
        float moveDirection = ai != null ? ai.getMovementDirection() : -1;
        float speedMultiplier = ai != null ? ai.getSpeedMultiplier() : 0;
        boolean wantsToJump = ai != null && ai.wantsToJump();
        
        // ========== 2. SET FACING DIRECTION (INSTANT - Alpha style) ==========
        // In Minecraft Alpha, mobs instantly face their movement direction
        // No smooth turning - just snap to the direction
        if (moveDirection >= 0) {
            pig.setYaw(moveDirection);
        }
        
        // ========== 3. CALCULATE MOVEMENT ==========
        float xMove = 0;
        float zMove = 0;
        float walkSpeed = pig.getWalkSpeed();
        
        // Only move if we have a valid direction and speed
        if (moveDirection >= 0 && speedMultiplier > 0) {
            float dirRad = (float)Math.toRadians(moveDirection);
            xMove = (float)Math.sin(dirRad) * walkSpeed * speedMultiplier;
            zMove = (float)Math.cos(dirRad) * walkSpeed * speedMultiplier;
        }
        
        // ========== 4. GROUND DETECTION (BEFORE JUMP) ==========
        // Pig position is FEET level, so feetY = pos.getY()
        float feetY = pos.getY();
        int feetBlockY = (int)Math.floor(feetY - 0.1f); // Block just below feet
        
        boolean onGround = false;
        
        // Check center
        if (chunkManager.isSolidAtWorld((int)Math.floor(pos.getX()), feetBlockY, (int)Math.floor(pos.getZ()))) {
            onGround = true;
        }
        
        // Check corners
        if (!onGround) {
            float checkOffset = pigWidth * 0.4f;
            if (chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() - checkOffset), feetBlockY, (int)Math.floor(pos.getZ() - checkOffset)) ||
                chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() + checkOffset), feetBlockY, (int)Math.floor(pos.getZ() - checkOffset)) ||
                chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() - checkOffset), feetBlockY, (int)Math.floor(pos.getZ() + checkOffset)) ||
                chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() + checkOffset), feetBlockY, (int)Math.floor(pos.getZ() + checkOffset))) {
                onGround = true;
            }
        }
        
        pig.setOnGround(onGround);
        
        // ========== 5. JUMPING ==========
        if (wantsToJump && onGround && vel.getY() <= 0) {
            vel.setY(pig.getJumpStrength());
            pig.setOnGround(false);
            onGround = false;
        }
        
        // ========== 6. APPLY GRAVITY ==========
        vel.setY(vel.getY() + pig.getGravity());
        
        // Limit fall speed
        if (vel.getY() < -0.3f) {
            vel.setY(-0.3f);
        }
        
        // Safety: limit upward velocity too
        if (vel.getY() > 0.3f) {
            vel.setY(0.3f);
        }
        
        // Safety: check for NaN or Infinity
        if (Float.isNaN(vel.getY()) || Float.isInfinite(vel.getY())) {
            vel.setY(0);
        }
        if (Float.isNaN(pos.getX()) || Float.isInfinite(pos.getX()) ||
            Float.isNaN(pos.getY()) || Float.isInfinite(pos.getY()) ||
            Float.isNaN(pos.getZ()) || Float.isInfinite(pos.getZ())) {
            // Reset to spawn position if corrupted
            pos.setX(0); pos.setY(20); pos.setZ(0);
            vel.setX(0); vel.setY(0); vel.setZ(0);
            System.out.println("WARNING: Pig position was NaN/Infinite, reset!");
        }
        
        // ========== 7. HORIZONTAL COLLISION ==========
        float newX = pos.getX() + xMove;
        float newZ = pos.getZ() + zMove;
        
        // Check X movement
        if (xMove != 0 && collidesHorizontal(newX, pos.getY(), pos.getZ(), pigWidth, pigHeight)) {
            newX = pos.getX(); // Cancel X movement
        }
        
        // Check Z movement  
        if (zMove != 0 && collidesHorizontal(newX, pos.getY(), newZ, pigWidth, pigHeight)) {
            newZ = pos.getZ(); // Cancel Z movement
        }
        
        pos.setX(newX);
        pos.setZ(newZ);
        
        // ========== 8. VERTICAL MOVEMENT ==========
        float newY = pos.getY() + vel.getY();
        
        // Falling - check ground collision
        if (vel.getY() <= 0) {
            int checkY = (int)Math.floor(newY - 0.01f);
            boolean hitGround = false;
            
            // Check if any solid block is at or below new feet position
            if (chunkManager.isSolidAtWorld((int)Math.floor(pos.getX()), checkY, (int)Math.floor(pos.getZ()))) {
                hitGround = true;
            }
            
            // Check corners
            if (!hitGround) {
                float checkOffset = pigWidth * 0.4f;
                if (chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() - checkOffset), checkY, (int)Math.floor(pos.getZ() - checkOffset)) ||
                    chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() + checkOffset), checkY, (int)Math.floor(pos.getZ() - checkOffset)) ||
                    chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() - checkOffset), checkY, (int)Math.floor(pos.getZ() + checkOffset)) ||
                    chunkManager.isSolidAtWorld((int)Math.floor(pos.getX() + checkOffset), checkY, (int)Math.floor(pos.getZ() + checkOffset))) {
                    hitGround = true;
                }
            }
            
            if (hitGround) {
                // Snap to top of block
                newY = checkY + 1.0f;
                vel.setY(0);
                pig.setOnGround(true);
            }
        }
        
        // Rising - check ceiling collision
        if (vel.getY() > 0) {
            float headY = newY + pigHeight;
            int checkY = (int)Math.floor(headY);
            
            if (chunkManager.isSolidAtWorld((int)Math.floor(pos.getX()), checkY, (int)Math.floor(pos.getZ()))) {
                // Hit ceiling - stop upward movement
                newY = checkY - pigHeight - 0.01f;
                vel.setY(0);
            }
        }
        
        pos.setY(newY);
        
        // ========== 9. UPDATE CHUNK TRACKING ==========
        updateEntityChunk(pig);
    }
    
    /**
     * Check if entity collides with blocks horizontally (for walls)
     */
    private boolean collidesHorizontal(float x, float y, float z, float width, float height) {
        // Check from feet (y) to head (y + height)
        float minX = x - width;
        float maxX = x + width;
        float minZ = z - width;
        float maxZ = z + width;
        
        // Check at feet level and body level (not at ground level)
        for (float checkY = y + 0.1f; checkY < y + height; checkY += 0.5f) {
            int by = (int)Math.floor(checkY);
            
            for (int bx = (int)Math.floor(minX); bx <= (int)Math.floor(maxX); bx++) {
                for (int bz = (int)Math.floor(minZ); bz <= (int)Math.floor(maxZ); bz++) {
                    if (chunkManager.isSolidAtWorld(bx, by, bz)) {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    /**
     * Update which chunk an entity belongs to
     */
    private void updateEntityChunk(Entity entity) {
        Vector3f pos = entity.getPosition();
        int chunkX = (int)Math.floor(pos.getX() / 16);
        int chunkZ = (int)Math.floor(pos.getZ() / 16);
        String chunkKey = chunkX + "," + chunkZ;
        
        // Remove from all chunks first
        for (List<Entity> chunkEntities : entitiesByChunk.values()) {
            chunkEntities.remove(entity);
        }
        
        // Add to new chunk
        entitiesByChunk.computeIfAbsent(chunkKey, k -> new ArrayList<>()).add(entity);
    }
    
    /**
     * Spawn entities in a chunk (called when chunk is generated)
     */
    public void spawnEntitiesInChunk(Chunk chunk) {
        // 50% chance to spawn mobs in this chunk
        if (Math.random() >= 0.5) {
            return; // Skip this chunk (50% chance)
        }
        
        int chunkX = chunk.getOriginX() / 16;
        int chunkZ = chunk.getOriginZ() / 16;
        String chunkKey = chunkX + "," + chunkZ;
        
        // Check current mob count
        int currentMobCount = entitiesByChunk.getOrDefault(chunkKey, new ArrayList<>()).size();
        if (currentMobCount >= MAX_MOBS_PER_CHUNK) {
            return;
        }
        
        // Spawn 1-3 pigs randomly
        int pigsToSpawn = 1 + (int)(Math.random() * 3);
        int remainingSlots = MAX_MOBS_PER_CHUNK - currentMobCount;
        pigsToSpawn = Math.min(pigsToSpawn, remainingSlots);
        
        for (int i = 0; i < pigsToSpawn; i++) {
            // Find a valid spawn position (on top of a solid block)
            Vector3f spawnPos = findValidSpawnPosition(chunk);
            if (spawnPos != null) {
                PigMob pig = new PigMob(spawnPos);
                addEntity(pig);
                System.out.println("Spawned pig at: " + spawnPos.getX() + ", " + spawnPos.getY() + ", " + spawnPos.getZ());
            }
        }
    }
    
    /**
     * Find a valid spawn position in a chunk (on top of a solid block)
     */
    private Vector3f findValidSpawnPosition(Chunk chunk) {
        int originX = chunk.getOriginX();
        int originZ = chunk.getOriginZ();
        
        // Try random positions in the chunk
        for (int attempts = 0; attempts < 20; attempts++) {
            int x = originX + (int)(Math.random() * 16);
            int z = originZ + (int)(Math.random() * 16);
            
            // Find the top solid block
            for (int y = 30; y >= 0; y--) {
                if (chunkManager.isSolidAtWorld(x, y, z)) {
                    // Spawn on top of this block
                    // Position is FEET level, so spawnY = blockTop
                    float spawnY = y + 1.0f;
                    return new Vector3f(x + 0.5f, spawnY, z + 0.5f);
                }
            }
        }
        
        return null; // No valid spawn position found
    }
}
