package blockcube.blockcube.entity;

import blockcube.blockcube.entity.ai.PassiveMobAI;
import blockcube.blockcube.math.Vector3f;

/**
 * Pig mob entity - Minecraft Alpha-style pig with torso and 4 legs
 * 
 * Model dimensions:
 * - Torso: 0.9 x 0.9 x 1.2 (width x height x depth)
 * - Legs: 0.2 x 0.5 x 0.2 each
 * 
 * The position represents the center-bottom of the entity (feet level)
 */
public class PigMob extends Entity {
    // Collision box dimensions (half-widths for collision)
    private static final float PIG_COLLISION_WIDTH = 0.45f;  // Half of 0.9
    private static final float PIG_COLLISION_HEIGHT = 1.4f;  // Legs (0.5) + Torso (0.9)
    private static final float PIG_COLLISION_DEPTH = 0.6f;   // Half of 1.2
    
    // Model dimensions (for rendering)
    public static final float TORSO_WIDTH = 0.9f;
    public static final float TORSO_HEIGHT = 0.9f;
    public static final float TORSO_DEPTH = 1.2f;
    
    public static final float LEG_WIDTH = 0.2f;
    public static final float LEG_HEIGHT = 0.5f;
    public static final float LEG_DEPTH = 0.2f;
    
    // Movement constants
    private static final float WALK_SPEED = 0.015f;  // Very slow walking speed (like real pigs)
    private static final float JUMP_STRENGTH = 0.10f; // Jump velocity
    private static final float GRAVITY = -0.006f; // Gravity acceleration per frame
    
    public PigMob(Vector3f position) {
        super(position, PIG_COLLISION_WIDTH, PIG_COLLISION_HEIGHT, PIG_COLLISION_DEPTH);
        
        // Set up passive mob AI (wandering)
        PassiveMobAI pigAI = new PassiveMobAI();
        this.ai = pigAI;
        
        // Initialize yaw to match AI's initial wander direction
        this.yaw = pigAI.getWanderDirection();
    }
    
    @Override
    public float getWidth() {
        return PIG_COLLISION_WIDTH;
    }
    
    public float getWalkSpeed() {
        return WALK_SPEED;
    }
    
    public float getJumpStrength() {
        return JUMP_STRENGTH;
    }
    
    public float getGravity() {
        return GRAVITY;
    }
    
    /**
     * Get the current leg animation phase for rendering
     * @return Animation phase in radians (currently disabled - returns 0)
     */
    public float getLegAnimationPhase() {
        return 0; // Animation disabled for now
    }
    
    /**
     * Get the wander direction from the AI
     */
    public float getWanderDirection() {
        if (ai instanceof PassiveMobAI) {
            return ((PassiveMobAI) ai).getWanderDirection();
        }
        return yaw;
    }
    
    /**
     * Set the wander direction in the AI
     */
    public void setWanderDirection(float direction) {
        if (ai instanceof PassiveMobAI) {
            ((PassiveMobAI) ai).setWanderDirection(direction);
        }
    }
    
    /**
     * Check if the AI wants to jump
     */
    public boolean wantsToJump() {
        return ai != null && ai.wantsToJump();
    }
    
    @Override
    public void update(float deltaTime) {
        // Gravity and collision are handled by EntityManager.updatePigMobPhysics()
        // This method is for animation updates only
        
        // Leg animation is disabled for now
    }
    
    /**
     * Calculate leg swing angle for animation
     * @param legIndex 0=front-left, 1=front-right, 2=back-left, 3=back-right
     * @return Swing angle in degrees (currently disabled - returns 0)
     */
    public float getLegSwingAngle(int legIndex) {
        // Animation disabled for now - legs stay straight
        return 0;
    }
}
