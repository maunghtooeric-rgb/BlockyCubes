package blockcube.blockcube.particle;

import blockcube.blockcube.math.Vector3f;

public class Particle {
    public Vector3f position;
    public Vector3f velocity;
    public float life;       // seconds left
    public float maxLife;    // for fading

    public Particle(Vector3f pos, Vector3f vel, float life) {
        this.position = pos;
        this.velocity = vel;
        this.life = life;
        this.maxLife = life;
    }
}
