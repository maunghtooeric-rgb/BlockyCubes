package blockcube.blockcube.particle;

import java.util.ArrayList;
import java.util.List;

import blockcube.blockcube.graphics.Mesh;
import blockcube.blockcube.graphics.Renderer;
import blockcube.blockcube.math.Vector3f;
import blockcube.blockcube.objects.Camera;

public class ParticleSystem {

	private static class Particle {
	    public Vector3f position;
	    public Vector3f velocity;
	    public float life;
	    public float maxLife;
	    public int texID;   // NEW

	    public Particle(Vector3f pos, Vector3f vel, float life, int texID) {
	        this.position = pos;
	        this.velocity = vel;
	        this.life = life;
	        this.maxLife = life;
	        this.texID = texID;   // NEW
	    }
	}

    private List<Particle> particles = new ArrayList<>();
    private Mesh quadMesh;
    private int textureID;

    public ParticleSystem(int textureID) {
        this.textureID = textureID;

        try {
            this.quadMesh = ParticleMesh.get();
            System.out.println("ParticleSystem: quadMesh loaded OK");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ParticleSystem FAILED to initialize");
        }
    }

    public void spawn(Vector3f pos, int count, int texID) {
        for (int i = 0; i < count; i++) {

            float vx = (float)(Math.random() - 0.5f) * 2f;
            float vy = (float)(Math.random() * 2f);
            float vz = (float)(Math.random() - 0.5f) * 2f;

            Vector3f vel = new Vector3f(vx, vy, vz);
            Vector3f startPos = new Vector3f(pos.getX(), pos.getY(), pos.getZ());
            float life = 0.5f + (float)Math.random() * 0.3f;

            particles.add(new Particle(startPos, vel, life, texID)); // <-- pass texID
        }
    }

    public void update(float dt) {
    	
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            
            

            p.life -= dt;
            if (p.life <= 0) {
                particles.remove(i);
                continue;
            }

            // gravity on Y (using getter/setter, not direct field)
            float vy = p.velocity.getY();
            vy -= 9.8f * dt * 0.3f;
            p.velocity.setY(vy);

            // integrate position manually (no mul())
            float px = p.position.getX() + p.velocity.getX() * dt;
            float py = p.position.getY() + p.velocity.getY() * dt;
            float pz = p.position.getZ() + p.velocity.getZ() * dt;

            p.position = new Vector3f(px, py, pz);
        }
    }

    public void render(Renderer renderer, Camera camera) {
        float scale = 0.1f; // tune later

        for (Particle p : particles) {
        	renderer.renderParticle(quadMesh, p.texID, p.position, scale, camera);
        }
    }
}