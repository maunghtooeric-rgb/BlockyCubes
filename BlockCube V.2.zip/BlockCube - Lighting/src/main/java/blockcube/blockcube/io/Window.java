package blockcube.blockcube.io;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.glfw.GLFWWindowSizeCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;

import blockcube.blockcube.math.Matrix4f;
import blockcube.blockcube.math.Vector3f;

public class Window {
	private int width, height;
	private String title;
	private long window;
	public int frames;
	public static long time;
	public Input input;
	private Vector3f bg = new Vector3f(0, 0, 0);
	private GLFWWindowSizeCallback sizeCallback;
	private boolean isResized;
	private boolean isFullscreen;
	private int[] windowPosX = new int[1], windowPosY = new int[1];
	private int windowedWidth, windowedHeight; // Store windowed size
	private Matrix4f projection;
	private double lastFrameTime = 0;
	private double deltaTime = 0;
	
	public Window(int width, int height, String title) {
		this.width = width;
		this.height = height;
		this.windowedWidth = width;
		this.windowedHeight = height;
		this.title = title;
		projection = Matrix4f.projection(70.0f, (float) width / (float) height, 0.1f, 1000.0f);
	}
	
	public void create() {
		if (!GLFW.glfwInit()) {
			System.err.println("GLFW wasn't initialized");
			return;
		}
		
		input = new Input();
		window = GLFW.glfwCreateWindow(width, height, title, isFullscreen ? GLFW.glfwGetPrimaryMonitor() : 0, 0);
		
		if (window == 0) {
			System.err.println("Window wasn't created");
			return;
		}
		
		GLFWVidMode videoMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
		windowPosX[0] = (videoMode.width() - width) / 2;
		windowPosY[0] = (videoMode.height() - height) / 2;
		GLFW.glfwSetWindowPos(window, windowPosX[0], windowPosY[0]);
		GLFW.glfwMakeContextCurrent(window);
		GL.createCapabilities();
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		
		createCallbacks();
		
		GLFW.glfwShowWindow(window);
		
		GLFW.glfwSwapInterval(1);
		
		time = System.currentTimeMillis();
	}
	
	private void createCallbacks() {
		sizeCallback = new GLFWWindowSizeCallback() {
			public void invoke(long window, int w, int h) {
				width = w;
				height = h;
				isResized = true;
			}
		};
		
		GLFW.glfwSetKeyCallback(window, input.getKeyboardCallback());
		GLFW.glfwSetCursorPosCallback(window, input.getMousePosCallback());
		GLFW.glfwSetMouseButtonCallback(window, input.getMouseButtonCallback());
		GLFW.glfwSetScrollCallback(window, input.getMouseScrollCallback());
		GLFW.glfwSetWindowSizeCallback(window, sizeCallback);
	}
	
	public void update() {
		// Calculate delta time
	    double currentTime = GLFW.glfwGetTime();
	    deltaTime = currentTime - lastFrameTime;
	    lastFrameTime = currentTime;
		
		if (isResized) {
			GL11.glViewport(0, 0, width, height);
			// Update projection matrix when window size changes
			projection = Matrix4f.projection(70.0f, (float) width / (float) height, 0.1f, 1000.0f);
			isResized = false;
		}
		
		GL11.glClearColor(bg.getX(), bg.getY(), bg.getZ(), 1.0f);
		GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
		GLFW.glfwPollEvents();
		frames++;
		if (System.currentTimeMillis() > time + 1000) {
			GLFW.glfwSetWindowTitle(window, title + " | FPS: " + frames);
			time = System.currentTimeMillis();
			frames = 0;
		}
	}
	
	public void swapBuffers() {
		GLFW.glfwSwapBuffers(window);
	}
	
	public boolean shouldClose() {
		return GLFW.glfwWindowShouldClose(window);
	}
	
	public void destory() {
		input.destoryInput();
		sizeCallback.free();
		GLFW.glfwWindowShouldClose(window);
		GLFW.glfwDestroyWindow(window);
		GLFW.glfwTerminate();
	}
	
	public void setBGColor(float red, float green, float blue) {
		bg.set(red, green, blue);
	}

	public boolean isFullscreen() {
		return isFullscreen;
	}

	public void setFullscreen(boolean isFullscreen) {
		if (this.isFullscreen == isFullscreen) {
			return; // Already in the desired state
		}
		
		this.isFullscreen = isFullscreen;
		
		if (isFullscreen) {
			// Save current window position and size
			GLFW.glfwGetWindowPos(window, windowPosX, windowPosY);
			windowedWidth = width;
			windowedHeight = height;
			
			// Get monitor resolution
			GLFWVidMode videoMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
			int monitorWidth = videoMode.width();
			int monitorHeight = videoMode.height();
			
			// Set fullscreen with monitor resolution
			GLFW.glfwSetWindowMonitor(window, GLFW.glfwGetPrimaryMonitor(), 0, 0, monitorWidth, monitorHeight, videoMode.refreshRate());
			width = monitorWidth;
			height = monitorHeight;
		} else {
			// Restore windowed mode with saved size and position
			GLFW.glfwSetWindowMonitor(window, 0, windowPosX[0], windowPosY[0], windowedWidth, windowedHeight, 0);
			width = windowedWidth;
			height = windowedHeight;
		}
		
		isResized = true; // Trigger viewport and projection update
	}
	
	public void mouseState(boolean lock) {
		GLFW.glfwSetInputMode(window, GLFW.GLFW_CURSOR, lock ? GLFW.GLFW_CURSOR_DISABLED : GLFW.GLFW_CURSOR_NORMAL);
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public String getTitle() {
		return title;
	}

	public long getWindow() {
		return window;
	}

	public double getDeltaTime() {
	    return deltaTime;
	}
	
	public Matrix4f getProjectionMatrix() {
		return projection;
	}
	
	
}
