package blockcube.blockcube.world;

public class DayNightCycle {

    private float time;        // 0 → 1
    private float speed;       // cycle speed multiplier

    public DayNightCycle(float speed) {
        this.time = 0f;
        this.speed = speed;
    }

    public void update(float dt) {
        time += dt * speed;
        if (time > 1f) time -= 1f;
    }

    // Smooth daylight curve (cosine)
    public float getDaylight() {
        return (float)((Math.cos(time * Math.PI * 2) + 1) / 2);
    }

    // Sky color based on daylight
    public float[] getSkyColor() {
        float d = getDaylight();

        // Day sky
        float rDay = 0.4f;
        float gDay = 0.7f;
        float bDay = 1.0f;

        // Night sky
        float rNight = 0.02f;
        float gNight = 0.02f;
        float bNight = 0.08f;

        // Lerp
        float r = rNight + (rDay - rNight) * d;
        float g = gNight + (gDay - gNight) * d;
        float b = bNight + (bDay - bNight) * d;

        return new float[]{ r, g, b };
    }
    
    // Get sun position in sky (returns world position)
    public float[] getSunPosition() {
        // Sun follows a circular path in the sky
        // time = 0 -> noon (top), time = 0.5 -> midnight (bottom)
        float angle = time * (float)Math.PI * 2 - (float)Math.PI / 2; // Start at top
        
        float radius = 200.0f; // Distance from world center
        float height = (float)Math.sin(angle) * radius;
        float distance = (float)Math.cos(angle) * radius;
        
        // Position sun in +Z direction (south)
        float x = 0;
        float y = height;
        float z = -distance; // Negative because we want it visible
        
        return new float[]{ x, y, z };
    }
    
    // Get moon position in sky (opposite of sun)
    public float[] getMoonPosition() {
        float[] sunPos = getSunPosition();
        // Moon is opposite the sun
        return new float[]{ -sunPos[0], -sunPos[1], -sunPos[2] };
    }
    
    // Get sun visibility (0-1, 1 = fully visible, 0 = hidden)
    public float getSunVisibility() {
        float[] sunPos = getSunPosition();
        float sunY = sunPos[1];
        
        // Sun is visible when above horizon (y > 0)
        // Gradually fade in/out
        float visibility = (sunY + 50.0f) / 100.0f; // Fade zone of 50 units
        return Math.max(0, Math.min(1, visibility));
    }
    
    // Get moon visibility (0-1, 1 = fully visible, 0 = hidden)
    public float getMoonVisibility() {
        float[] moonPos = getMoonPosition();
        float moonY = moonPos[1];
        
        // Moon is visible when above horizon (y > 0)
        float visibility = (moonY + 50.0f) / 100.0f;
        return Math.max(0, Math.min(1, visibility));
    }
    
    // Get raw time (0-1)
    public float getTime() {
        return time;
    }
    
    // Set raw time (0-1) - used for loading saved time
    public void setTime(float time) {
        this.time = Math.max(0, Math.min(1, time)); // Clamp to 0-1
    }
}