package blockcube.blockcube.graphics;

import blockcube.blockcube.graphics.Vertex;
import blockcube.blockcube.graphics.Mesh;
import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

public class BreakOverlay {

    private static Mesh mesh;

    public static Mesh get() {
        if (mesh != null) return mesh;

        // 0..1 cube, same as OutlineCube
        Vertex[] v = new Vertex[] {
            // FRONT (z+)
            new Vertex(new Vector3f(0,0,1), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,0,1), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,1), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,1,1), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),

            // BACK (z-)
            new Vertex(new Vector3f(1,0,0), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,0,0), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,1,0), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,0), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),

            // LEFT (x-)
            new Vertex(new Vector3f(0,0,0), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,0,1), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,1,1), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,1,0), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),

            // RIGHT (x+)
            new Vertex(new Vector3f(1,0,1), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,0,0), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,0), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,1), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),

            // TOP (y+)
            new Vertex(new Vector3f(0,1,1), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,1), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,1,0), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,1,0), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),

            // BOTTOM (y-)
            new Vertex(new Vector3f(0,0,0), new Vector2f(0,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,0,0), new Vector2f(1,1), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(1,0,1), new Vector2f(1,0), 7, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(0,0,1), new Vector2f(0,0), 7, 1.0f, 0.0f, 1.0f),
        };

        int[] idx = {
            0,1,2, 0,2,3,
            4,5,6, 4,6,7,
            8,9,10, 8,10,11,
            12,13,14, 12,14,15,
            16,17,18, 16,18,19,
            20,21,22, 20,22,23
        };

        mesh = new Mesh(v, idx, null);
        mesh.create();
        return mesh;
    }
}