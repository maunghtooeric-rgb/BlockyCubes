package blockcube.blockcube.graphics;

import blockcube.blockcube.graphics.Vertex;
import blockcube.blockcube.graphics.Mesh;
import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

public class OutlineCube {

    private static Mesh mesh;

    public static Mesh get() {
        if (mesh != null) return mesh;

        Vertex[] verts = new Vertex[] {
            new Vertex(new Vector3f(0f, 0f, 0f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 0
            new Vertex(new Vector3f(1f, 0f, 0f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 1
            new Vertex(new Vector3f(1f, 1f, 0f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 2
            new Vertex(new Vector3f(0f, 1f, 0f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 3

            new Vertex(new Vector3f(0f, 0f, 1f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 4
            new Vertex(new Vector3f(1f, 0f, 1f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 5
            new Vertex(new Vector3f(1f, 1f, 1f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 6
            new Vertex(new Vector3f(0f, 1f, 1f), new Vector2f(0f, 0f), 0, 1.0f, 0.0f, 1.0f), // 7
        };

        int[] lines = {
            0,1, 1,2, 2,3, 3,0,
            4,5, 5,6, 6,7, 7,4,
            0,4, 1,5, 2,6, 3,7
        };

        mesh = new Mesh(verts, lines, null);
        mesh.create();
        return mesh;
    }
}