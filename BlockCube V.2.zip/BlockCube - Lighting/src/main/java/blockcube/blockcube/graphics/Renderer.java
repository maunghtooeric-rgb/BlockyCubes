package blockcube.blockcube.graphics;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;

import blockcube.blockcube.entity.Entity;
import blockcube.blockcube.entity.PigMob;
import blockcube.blockcube.io.Window;
import blockcube.blockcube.math.Matrix4f;
import blockcube.blockcube.math.Vector3f;
import blockcube.blockcube.objects.Camera;
import blockcube.blockcube.objects.GameObject;

public class Renderer {

    private final Window window;

    // Separate shaders
    private final Shader blockShader;
    private final Shader particleShader;

    // Store texture IDs for all block types
    private int dirtID;
    private int logID;
    private int leavesID;
    private int lightID;
    private int[] breakTex = new int[4];
    
    // Vegetation texture IDs
    private int grassID;
    private int flowerID;
    private int fernID;
    private int deadBushID;
    private int mushroomID;
    
    // Torch texture ID
    private int torchID;
    
    public int getTextureForBlock(int blockID) {
        return switch (blockID) {
            case 1 -> dirtID;
            case 2 -> logID;
            case 3 -> leavesID;
            case 4 -> lightID;
            default -> dirtID; // fallback
        };
    }
    
    public int getTextureForVegetation(int blockID) {
        return switch (blockID) {
            case 5 -> grassID;      // GRASS
            case 6 -> flowerID;    // FLOWER
            case 7 -> fernID;      // FERN
            case 8 -> deadBushID;  // DEAD_BUSH
            case 9 -> mushroomID;  // MUSHROOM
            default -> grassID;    // fallback
        };
    }

    public Renderer(Window window, Shader blockShader, Shader particleShader) {
        this.window = window;
        this.blockShader = blockShader;
        this.particleShader = particleShader;
    }

    // Call this once after loading materials
    public void setBlockTextures(Material dirt, Material log, Material leaves, Material light) {
        this.dirtID = dirt.getTextureID();
        this.logID = log.getTextureID();
        this.leavesID = leaves.getTextureID();
        this.lightID = light.getTextureID();
    }

    public void setBreakTextures(Material b1, Material b2, Material b3, Material b4) {
        breakTex[0] = b1.getTextureID();
        breakTex[1] = b2.getTextureID();
        breakTex[2] = b3.getTextureID();
        breakTex[3] = b4.getTextureID();
    }
    
    public void setVegetationTextures(Material grass, Material flower, Material fern, Material deadBush, Material mushroom) {
        this.grassID = grass.getTextureID();
        this.flowerID = flower.getTextureID();
        this.fernID = fern.getTextureID();
        this.deadBushID = deadBush.getTextureID();
        this.mushroomID = mushroom.getTextureID();
    }
    
    public void setTorchTexture(Material torch) {
        this.torchID = torch.getTextureID();
    }

    // -------- BLOCK / WORLD RENDERING --------

    public void renderMesh(GameObject object, Camera camera) {
        renderMesh(object, camera, false);
    }
    
    public void renderMesh(GameObject object, Camera camera, boolean xRayMode) {
        blockShader.bind();

        blockShader.setUniform(
            "model",
            Matrix4f.transform(object.getPosition(), object.getRotation(), object.getScale())
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());
        
        // Set alpha for x-ray mode (0.3 = semi-transparent, 1.0 = opaque)
        float alphaValue = xRayMode ? 0.3f : 1.0f;
        blockShader.setUniform("alpha", alphaValue);

        // ---- Bind all 4 block textures ----
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, dirtID);

        GL13.glActiveTexture(GL13.GL_TEXTURE1);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, logID);

        GL13.glActiveTexture(GL13.GL_TEXTURE2);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, leavesID);

        GL13.glActiveTexture(GL13.GL_TEXTURE3);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, lightID);   // NEW

        // ---- Tell shader which texture slots to use ----
        blockShader.setUniform("textures[0]", 0);
        blockShader.setUniform("textures[1]", 1);
        blockShader.setUniform("textures[2]", 2);
        blockShader.setUniform("textures[3]", 3);           // NEW

        GL30.glBindVertexArray(object.getMesh().getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);
        GL30.glEnableVertexAttribArray(3); // sunLight
        GL30.glEnableVertexAttribArray(4); // blockLight
        GL30.glEnableVertexAttribArray(5); // ambientOcclusion
        
        // Enable blending for x-ray mode
        if (xRayMode) {
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glDepthMask(false); // Don't write to depth buffer for transparent blocks
        }

        GL11.glDrawElements(GL11.GL_TRIANGLES, object.getMesh().getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        
        // Disable blending if it was enabled
        if (xRayMode) {
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glDepthMask(true); // Re-enable depth writing
        }

        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glDisableVertexAttribArray(3);
        GL30.glDisableVertexAttribArray(4);
        GL30.glDisableVertexAttribArray(5);
        GL30.glBindVertexArray(0);

        blockShader.unbind();
    }

    public void renderOutlineCube(Vector3f blockPos, Camera camera) {
        Mesh m = OutlineCube.get();

        blockShader.bind();

        blockShader.setUniform("useColorOverride", true);
        blockShader.setUniform("overrideColor", new Vector3f(1, 1, 1));

        blockShader.setUniform(
            "model",
            Matrix4f.transform(
                blockPos,
                new Vector3f(0, 0, 0),
                new Vector3f(1f, 1f, 1f)
            )
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());

        GL30.glBindVertexArray(m.getVAO());
        GL30.glEnableVertexAttribArray(0);

        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);
        GL11.glDrawElements(GL11.GL_LINES, m.getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_FILL);

        GL30.glDisableVertexAttribArray(0);
        GL30.glBindVertexArray(0);

        blockShader.setUniform("useColorOverride", false);

        blockShader.unbind();
    }

    public void renderBreakOverlay(Vector3f pos, int frame, Camera camera) {
        Mesh m = BreakOverlay.get();

        blockShader.bind();

        blockShader.setUniform("useColorOverride", false);

        GL13.glActiveTexture(GL13.GL_TEXTURE7);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, breakTex[frame]);
        blockShader.setUniform("textures[7]", 7);

        blockShader.setUniform(
            "model",
            Matrix4f.transform(
                pos,
                new Vector3f(0, 0, 0),
                new Vector3f(1f, 1f, 1f)
            )
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());

        GL30.glBindVertexArray(m.getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);

        GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
        GL11.glPolygonOffset(-1f, -1f);

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glDrawElements(GL11.GL_TRIANGLES, m.getIndices().length, GL11.GL_UNSIGNED_INT, 0);

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);

        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glBindVertexArray(0);

        blockShader.unbind();
    }


    // -------- PARTICLE RENDERING --------

    public void renderParticle(Mesh mesh, int texID, Vector3f pos, float scale, Camera camera) {
        particleShader.bind();

        particleShader.setUniform("useColorOverride", false);
        particleShader.setUniform("useParticleTex", true);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texID);
        particleShader.setUniform("particleTex", 0);

        particleShader.setUniform("particlePos", pos);
        particleShader.setUniform("particleScale", scale);

        particleShader.setUniform("camRight", camera.getRightVector());
        particleShader.setUniform("camUp", camera.getUpVector());

        particleShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        particleShader.setUniform("projection", window.getProjectionMatrix());

        GL30.glBindVertexArray(mesh.getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);

        GL11.glDepthMask(false);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        GL11.glDrawElements(GL11.GL_TRIANGLES, mesh.getIndices().length, GL11.GL_UNSIGNED_INT, 0);

        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDepthMask(true);

        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glBindVertexArray(0);

        particleShader.setUniform("useParticleTex", false);
        particleShader.unbind();
    }
    
    // -------- SUN/MOON RENDERING (Minecraft-style) --------
    
    /**
     * Helper method to render a world-oriented sky quad
     * @param pos World position
     * @param color Color (RGB)
     * @param scale Size
     * @param rotationAngle Rotation around X-axis in degrees
     * @param camera Camera
     */
    private void renderWorldOrientedQuad(Vector3f pos, Vector3f color, float scale, float rotationAngle, Camera camera) {
        Mesh m = SkyQuad.get();
        if (m == null || m.getIndices() == null || m.getIndices().length == 0) return;
        
        blockShader.bind();
        blockShader.setUniform("useColorOverride", true);
        blockShader.setUniform("overrideColor", color);
        
        // World-oriented quad: rotate around X-axis based on sky position
        // SkyQuad faces +Z by default, rotate to be oriented in world space
        blockShader.setUniform(
            "model",
            Matrix4f.transform(
                pos,
                new Vector3f(rotationAngle, 0.0f, 0.0f), // Rotate around X-axis for sky dome
                new Vector3f(scale, scale, scale)
            )
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());
        
        // Bind textures
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, dirtID);
        blockShader.setUniform("textures[0]", 0);
        
        GL30.glBindVertexArray(m.getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);
        
        // Rendering state (Minecraft-style):
        // - Keep depth test enabled (render behind terrain)
        // - Disable depth write (don't write to depth buffer)
        // - Disable face culling (render both sides)
        // - Enable alpha blending
        GL11.glDepthMask(false); // Disable depth write
        GL11.glDisable(GL11.GL_CULL_FACE); // Disable face culling
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        
        GL11.glDrawElements(GL11.GL_TRIANGLES, m.getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        
        // Restore state
        GL11.glDisable(GL11.GL_BLEND);
        // Don't re-enable face culling - it's disabled globally for blocks
        GL11.glDepthMask(true);
        
        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glBindVertexArray(0);
        
        blockShader.setUniform("useColorOverride", false);
        blockShader.unbind();
    }
    
    /**
     * Render the sun
     * @param pos World position
     * @param scale Size
     * @param rotationAngle Rotation around X-axis in degrees
     * @param camera Camera
     */
    public void renderSun(Vector3f pos, float scale, float rotationAngle, Camera camera) {
        // Bright yellow/white sun, unaffected by world lighting
        renderWorldOrientedQuad(pos, new Vector3f(1.0f, 1.0f, 0.8f), scale, rotationAngle, camera);
    }
    
    /**
     * Render the moon
     * @param pos World position
     * @param scale Size
     * @param rotationAngle Rotation around X-axis in degrees
     * @param camera Camera
     */
    public void renderMoon(Vector3f pos, float scale, float rotationAngle, Camera camera) {
        // Bright blue/white moon, unaffected by world lighting
        // TODO: Add moon phase support
        renderWorldOrientedQuad(pos, new Vector3f(0.9f, 0.9f, 1.0f), scale, rotationAngle, camera);
    }
    
    // -------- VEGETATION RENDERING --------
    
    /**
     * Render vegetation mesh with alpha blending and no face culling.
     * Vegetation blocks are rendered as crossed quads (X-shaped).
     * All vegetation textures are bound to texture slots 4-8.
     * @param object GameObject containing the vegetation mesh
     * @param camera Camera for view/projection
     */
    public void renderVegetationMesh(GameObject object, Camera camera) {
        blockShader.bind();
        
        blockShader.setUniform(
            "model",
            Matrix4f.transform(object.getPosition(), object.getRotation(), object.getScale())
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());
        
        // Bind all vegetation textures to slots 4-8
        // The shader will select the correct texture based on vTexID from vertices
        GL13.glActiveTexture(GL13.GL_TEXTURE4);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, grassID);
        blockShader.setUniform("textures[4]", 4);
        
        GL13.glActiveTexture(GL13.GL_TEXTURE5);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, flowerID);
        blockShader.setUniform("textures[5]", 5);
        
        GL13.glActiveTexture(GL13.GL_TEXTURE6);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, fernID);
        blockShader.setUniform("textures[6]", 6);
        
        GL13.glActiveTexture(GL13.GL_TEXTURE7);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, deadBushID);
        blockShader.setUniform("textures[7]", 7);
        
        GL13.glActiveTexture(GL13.GL_TEXTURE8);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, mushroomID);
        blockShader.setUniform("textures[8]", 8);
        
        GL30.glBindVertexArray(object.getMesh().getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);
        GL30.glEnableVertexAttribArray(3); // sunLight
        GL30.glEnableVertexAttribArray(4); // blockLight
        GL30.glEnableVertexAttribArray(5); // ambientOcclusion
        
        // Vegetation rendering state:
        // - Enable alpha blending (for transparent textures)
        // - Disable face culling (render both sides of quads)
        // - Keep depth test enabled (render behind solid blocks)
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_CULL_FACE); // Already disabled globally, but explicit for clarity
        
        GL11.glDrawElements(GL11.GL_TRIANGLES, object.getMesh().getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        
        // Restore state (but don't re-enable culling - it's disabled globally)
        GL11.glDisable(GL11.GL_BLEND);
        
        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glDisableVertexAttribArray(3);
        GL30.glDisableVertexAttribArray(4);
        GL30.glDisableVertexAttribArray(5);
        GL30.glBindVertexArray(0);
        
        blockShader.unbind();
    }
    
    // -------- TORCH RENDERING --------
    
    /**
     * Render a torch at the given block position with proper orientation.
     * @param bx Block X coordinate in world space
     * @param by Block Y coordinate in world space
     * @param bz Block Z coordinate in world space
     * @param normal Normal vector indicating which face the torch is placed on (flipped - points away from block)
     * @param camera Camera for view/projection
     * @param debugRotationY Additional Y rotation for debug mode (in degrees)
     */
    public void renderTorch(int bx, int by, int bz, Vector3f normal, Camera camera, float debugRotationY) {
        Mesh m = TorchMesh.get();
        if (m == null || m.getIndices() == null || m.getIndices().length == 0) return;
    
        blockShader.bind();

        System.out.println("Torch at " + bx + "," + by + "," + bz +
                   " normal=" + normal.getX() + "," + normal.getY() + "," + normal.getZ());
    
        // Flip the normal so it points TOWARD the block the torch is attached to
        Vector3f faceNormal = normal;
    
        // Rotation based on the face the torch is mounted on
        Vector3f rotation = calculateTorchRotation(faceNormal);
    
        if (debugRotationY != 0.0f) {
            rotation = new Vector3f(rotation.getX(), rotation.getY() + debugRotationY, rotation.getZ());
        }

        // Minecraft-style offsets
        float outward = 0.27f;
        float yOffset;

        if (faceNormal.getY() == -1) {
            // floor
            yOffset = 0.0f;
        }
        else if (faceNormal.getY() == 1) {
            // ceiling
            yOffset = -0.1f;
        }
        else {
            // wall
            yOffset = 0.2f;
        }

        Vector3f torchPos = new Vector3f(
            bx + 0.5f + faceNormal.getX() * outward,
            by + yOffset,
            bz + 0.5f + faceNormal.getZ() * outward
        );
    
        blockShader.setUniform(
            "model",
            Matrix4f.transform(torchPos, rotation, new Vector3f(1.0f, 1.0f, 1.0f))
        );
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());
    
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, torchID);
        blockShader.setUniform("textures[0]", 0);
    
        GL30.glBindVertexArray(m.getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);
        GL30.glEnableVertexAttribArray(3);
        GL30.glEnableVertexAttribArray(4);
        GL30.glEnableVertexAttribArray(5);
    
        blockShader.setUniform("useColorOverride", true);
        blockShader.setUniform("overrideColor", new Vector3f(1.0f, 1.0f, 1.0f));
    
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glDrawElements(GL11.GL_TRIANGLES, m.getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        GL11.glEnable(GL11.GL_CULL_FACE);
    
        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glDisableVertexAttribArray(3);
        GL30.glDisableVertexAttribArray(4);
        GL30.glDisableVertexAttribArray(5);
        GL30.glBindVertexArray(0);
    
        blockShader.setUniform("useColorOverride", false);
        blockShader.unbind();
    }
    
    /**
     * Calculate torch rotation based on placement face normal.
     * Torch always tilts 20 degrees upward from the face it's mounted on.
     * Rotation order: X, then Y, then Z (as per Matrix4f.transform)
     * @param normal Normal vector of the face the torch is placed on (points away from block)
     * @return Rotation vector (Euler angles in degrees: X, Y, Z)
     */
    private Vector3f calculateTorchRotation(Vector3f normal) {
        float nx = normal.getX();
        float ny = normal.getY();
        float nz = normal.getZ();
        
        // Tilt angle (in degrees) - torch tilts 20 degrees upward from horizontal
        float tiltAngle = 20.0f;
        
        if (ny == 1) {
            // Placed on top (floor): upright, no rotation needed
            return new Vector3f(0, 0, 0);
        } else if (ny == -1) {
            // Placed on bottom (ceiling): inverted, rotate 180 around X
            return new Vector3f(180, 0, 0);
        } else if (nx == 1) {
            // Placed on +X face (right/east wall): torch points toward +X, tilts 20° up
            // Rotate around X by tiltAngle (upward tilt), around Y by -90 (point +X), around Z by 90 (horizontal)
            return new Vector3f(tiltAngle, -90, 90);
        } else if (nx == -1) {
            // Placed on -X face (left/west wall): torch points toward -X, tilts 20° up
            return new Vector3f(tiltAngle, 90, -90);
        } else if (nz == 1) {
            // Placed on +Z face (front/south wall): torch points toward +Z, tilts 20° up
            return new Vector3f(90 + tiltAngle, 0, 0);
        } else if (nz == -1) {
            // Placed on -Z face (back/north wall): torch points toward -Z, tilts 20° up
            return new Vector3f(90 - tiltAngle, 180, 0);
        }
        
        // Default: upright
        return new Vector3f(0, 0, 0);
    }
    
    // -------- ENTITY RENDERING --------
    
    /**
     * Render an entity (pig mob)
     */
    public void renderEntity(Entity entity, Camera camera) {
        if (entity instanceof PigMob) {
            renderPigMob((PigMob) entity, camera);
        }
    }
    
    /**
     * Render a pig mob with torso and 4 animated legs
     */
    private void renderPigMob(PigMob pig, Camera camera) {
        Mesh torsoMesh = PigMesh.getTorso();
        Mesh legMesh = PigMesh.getLeg();
        
        if (torsoMesh == null || legMesh == null) return;
        
        blockShader.bind();
        
        Vector3f pos = pig.getPosition();
        // Rotate pig to face movement direction (yaw is set by AI)
        float rotationY = pig.getYaw();
        
        blockShader.setUniform("view", Matrix4f.view(camera.getPosition(), camera.getRotation()));
        blockShader.setUniform("projection", window.getProjectionMatrix());
        
        // Bind texture (not really used since we use vertex colors)
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, dirtID);
        blockShader.setUniform("textures[0]", 0);
        
        // Use vertex colors for pig coloring (passed via sunLight/blockLight/ao)
        blockShader.setUniform("useColorOverride", true);
        blockShader.setUniform("overrideColor", new Vector3f(0.96f, 0.76f, 0.76f)); // Pink
        
        GL11.glDisable(GL11.GL_CULL_FACE);
        
        // Calculate torso position (above legs)
        float torsoY = pos.getY() + PigMesh.getTorsoYOffset();
        Vector3f torsoPos = new Vector3f(pos.getX(), torsoY, pos.getZ());
        
        // Render torso
        blockShader.setUniform(
            "model",
            Matrix4f.transform(torsoPos, new Vector3f(0, rotationY, 0), new Vector3f(1.0f, 1.0f, 1.0f))
        );
        renderMeshDirect(torsoMesh);
        
        // Render 4 legs (no animation for now - just positioned at corners)
        float yawRad = (float)Math.toRadians(rotationY);
        
        // Slightly different color for legs
        blockShader.setUniform("overrideColor", new Vector3f(0.90f, 0.70f, 0.70f));
        
        for (int legIndex = 0; legIndex < 4; legIndex++) {
            Vector3f legOffset = PigMesh.getLegOffset(legIndex);
            
            // Rotate offset by pig's yaw to get world-space hip position
            float rotatedX = (float)(legOffset.getX() * Math.cos(yawRad) - legOffset.getZ() * Math.sin(yawRad));
            float rotatedZ = (float)(legOffset.getX() * Math.sin(yawRad) + legOffset.getZ() * Math.cos(yawRad));
            
            // Hip position in world space
            Vector3f hipPos = new Vector3f(
                pos.getX() + rotatedX,
                pos.getY() + legOffset.getY(),
                pos.getZ() + rotatedZ
            );
            
            // Simple transform: just position and yaw rotation (no swing animation)
            blockShader.setUniform(
                "model",
                Matrix4f.transform(hipPos, new Vector3f(0, rotationY, 0), new Vector3f(1.0f, 1.0f, 1.0f))
            );
            
            renderMeshDirect(legMesh);
        }
        
        GL11.glEnable(GL11.GL_CULL_FACE);
        
        blockShader.setUniform("useColorOverride", false);
        blockShader.unbind();
    }
    
    /**
     * Render a mesh directly (helper for entity rendering)
     */
    private void renderMeshDirect(Mesh m) {
        if (m == null || m.getIndices() == null || m.getIndices().length == 0) return;
        
        GL30.glBindVertexArray(m.getVAO());
        GL30.glEnableVertexAttribArray(0);
        GL30.glEnableVertexAttribArray(1);
        GL30.glEnableVertexAttribArray(2);
        GL30.glEnableVertexAttribArray(3);
        GL30.glEnableVertexAttribArray(4);
        GL30.glEnableVertexAttribArray(5);
        
        GL11.glDrawElements(GL11.GL_TRIANGLES, m.getIndices().length, GL11.GL_UNSIGNED_INT, 0);
        
        GL30.glDisableVertexAttribArray(0);
        GL30.glDisableVertexAttribArray(1);
        GL30.glDisableVertexAttribArray(2);
        GL30.glDisableVertexAttribArray(3);
        GL30.glDisableVertexAttribArray(4);
        GL30.glDisableVertexAttribArray(5);
        GL30.glBindVertexArray(0);
    }
}