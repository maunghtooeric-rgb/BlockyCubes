package blockcube.blockcube.graphics;

public enum BlockType {
    AIR(0),
    DIRT(1),
    LOG(2),
    LEAVES(3),
    GRASS(5),
    FLOWER(6),
    FERN(7),
    DEAD_BUSH(8),
    MUSHROOM(9),
    TORCH(10);

    public final int id;

    BlockType(int id) {
        this.id = id;
    }
    
    /**
     * Check if a block ID is a vegetation block (rendered as crossed quads)
     */
    public static boolean isVegetation(int blockID) {
        return blockID == GRASS.id || blockID == FLOWER.id || 
               blockID == FERN.id || blockID == DEAD_BUSH.id || 
               blockID == MUSHROOM.id;
    }
    
    /**
     * Check if a block ID is a light source (emits block light)
     */
    public static boolean isLightSource(int blockID) {
        return blockID == 4 || blockID == TORCH.id; // Light source block (4) or torch (10)
    }
}