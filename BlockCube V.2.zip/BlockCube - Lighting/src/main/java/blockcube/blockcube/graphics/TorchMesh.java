package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

/**
 * Torch mesh - a thin vertical rectangular prism (cuboid).
 * The torch is centered at origin, standing upright by default.
 * Dimensions: thin width/depth, full height.
 */
public class TorchMesh {

    private static Mesh mesh;

    public static Mesh get() {
        if (mesh != null) return mesh;

        // Torch dimensions: thin cuboid (like a stick)
        // Width and depth are small (0.15 = 15% of block size)
        // Height is full (1.0 = 100% of block size)
        float torchWidth = 0.15f;  // Thin width
        float torchDepth = 0.15f;  // Thin depth
        float torchHeight = 1.0f;  // Full height
        
        float halfWidth = torchWidth * 0.5f;
        float halfDepth = torchDepth * 0.5f;
        float halfHeight = torchHeight * 0.5f;
        
        // Create a cuboid centered at origin, standing upright
        // Vertices for a thin vertical cuboid (8 vertices)
        Vertex[] verts = new Vertex[] {
            // Bottom face (y = -halfHeight)
            new Vertex(new Vector3f(-halfWidth, -halfHeight, -halfDepth), new Vector2f(0f, 1f), 0, 1.0f, 1.0f, 1.0f), // 0
            new Vertex(new Vector3f( halfWidth, -halfHeight, -halfDepth), new Vector2f(1f, 1f), 0, 1.0f, 1.0f, 1.0f), // 1
            new Vertex(new Vector3f( halfWidth, -halfHeight,  halfDepth), new Vector2f(1f, 0f), 0, 1.0f, 1.0f, 1.0f), // 2
            new Vertex(new Vector3f(-halfWidth, -halfHeight,  halfDepth), new Vector2f(0f, 0f), 0, 1.0f, 1.0f, 1.0f), // 3
            
            // Top face (y = halfHeight)
            new Vertex(new Vector3f(-halfWidth,  halfHeight, -halfDepth), new Vector2f(0f, 1f), 0, 1.0f, 1.0f, 1.0f), // 4
            new Vertex(new Vector3f( halfWidth,  halfHeight, -halfDepth), new Vector2f(1f, 1f), 0, 1.0f, 1.0f, 1.0f), // 5
            new Vertex(new Vector3f( halfWidth,  halfHeight,  halfDepth), new Vector2f(1f, 0f), 0, 1.0f, 1.0f, 1.0f), // 6
            new Vertex(new Vector3f(-halfWidth,  halfHeight,  halfDepth), new Vector2f(0f, 0f), 0, 1.0f, 1.0f, 1.0f), // 7
        };

        // Indices for 6 faces of the cuboid (12 triangles)
        int[] idx = {
            // Bottom face
            0, 2, 1,
            0, 3, 2,
            
            // Top face
            4, 5, 6,
            4, 6, 7,
            
            // Front face (+Z)
            3, 6, 2,
            3, 7, 6,
            
            // Back face (-Z)
            0, 1, 5,
            0, 5, 4,
            
            // Right face (+X)
            1, 2, 6,
            1, 6, 5,
            
            // Left face (-X)
            0, 7, 3,
            0, 4, 7
        };

        mesh = new Mesh(verts, idx, null);
        mesh.create();
        return mesh;
    }
}
