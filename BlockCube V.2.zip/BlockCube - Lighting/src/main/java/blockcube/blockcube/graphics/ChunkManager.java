package blockcube.blockcube.graphics;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;

import blockcube.blockcube.math.Vector3f;

public class ChunkManager {

    private final int sizeX, sizeY, sizeZ;
    private final int loadRadius;
    private final int unloadRadius;
    private final Material material;
    
    // World seed for consistent terrain generation
    private long worldSeed;
    
    // Time of day (0-1) for day/night cycle persistence
    private float timeOfDay = 0f;

    private final Map<String, Chunk> chunks = new HashMap<>();
    private final Map<Integer, Material> materials = new HashMap<>();
    
    // Store torch data: key = "x,y,z" (block position), value = TorchData (normal + hit position)
    private final Map<String, TorchData> torchData = new HashMap<>();
    
    // Store block modifications per chunk for persistence when chunks are unloaded/reloaded
    // Outer key = chunk key (e.g., "0,0"), Inner key = local block position "lx,ly,lz", Value = block ID
    private final Map<String, Map<String, Integer>> chunkModifications = new HashMap<>();
    
    // Callback for entity manager to spawn entities in new chunks
    public interface ChunkCreatedCallback {
        void onChunkCreated(Chunk chunk);
    }
    private ChunkCreatedCallback entityManagerCallback;

    private int lastCenterChunkX = Integer.MIN_VALUE;
    private int lastCenterChunkZ = Integer.MIN_VALUE;

    // Block IDs that emit light
    private static final int LIGHT_SOURCE_ID = 4;
    private static final int TORCH_ID = 10;
    // 0–15 light strength
    private static final byte LIGHT_SOURCE_STRENGTH = 10;

    // Neighbor offsets for flood fill
    private static final int[] DX = { 1, -1, 0, 0, 0, 0 };
    private static final int[] DY = { 0, 0, 1, -1, 0, 0 };
    private static final int[] DZ = { 0, 0, 0, 0, 1, -1 };
    
    // Save file path
    private static final String SAVE_FILE = "level.dat";

    public ChunkManager(int sizeX, int sizeY, int sizeZ,
            int loadRadius, int unloadRadius,
            Material mat) {
			this.sizeX = sizeX;
			this.sizeY = sizeY;
			this.sizeZ = sizeZ;
			this.loadRadius = loadRadius;
			this.unloadRadius = unloadRadius;
			this.material = mat;
			
			// Generate a random seed (will be overwritten if loading from file)
			this.worldSeed = new Random().nextLong();
	}
	
	/**
	 * Get the world seed.
	 */
	public long getWorldSeed() {
		return worldSeed;
	}
	
	/**
	 * Set the world seed (used when loading from file).
	 */
	public void setWorldSeed(long seed) {
		this.worldSeed = seed;
	}
	
	/**
	 * Get the time of day (0-1).
	 */
	public float getTimeOfDay() {
		return timeOfDay;
	}
	
	/**
	 * Set the time of day (0-1) - used for saving/loading.
	 */
	public void setTimeOfDay(float time) {
		this.timeOfDay = Math.max(0, Math.min(1, time));
	}



    private String key(int cx, int cz) {
        return cx + "," + cz;
    }

    private boolean isAirAt(int wx, int wy, int wz) {
        int cx = (int)Math.floor((double)wx / sizeX);
        int cz = (int)Math.floor((double)wz / sizeZ);

        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return true;

        int lx = wx - c.getOriginX();
        int ly = wy - c.getOriginY();
        int lz = wz - c.getOriginZ();

        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ)
            return true;

        int blockID = c.getBlock(lx, ly, lz);
        // Treat vegetation blocks (5-9) and torch (10) as air for collision and lighting purposes
        // This makes them non-collidable and allows light to pass through
        if (blockID == 0) return true;
        if (BlockType.isVegetation(blockID)) return true;
        if (blockID == TORCH_ID) return true; // Torch is non-solid for culling
        return false;
    }

    // ---------------------------------------------------------
    // CHUNK LOADING / UNLOADING
    // ---------------------------------------------------------

    public void update(Vector3f playerPos) {

        int centerX = (int)Math.floor(playerPos.getX() / sizeX);
        int centerZ = (int)Math.floor(playerPos.getZ() / sizeZ);

        if (centerX == lastCenterChunkX && centerZ == lastCenterChunkZ)
            return;

        lastCenterChunkX = centerX;
        lastCenterChunkZ = centerZ;

        boolean createdNewChunks = false;

        // Create chunks in load radius
        for (int dx = -loadRadius; dx <= loadRadius; dx++) {
            for (int dz = -loadRadius; dz <= loadRadius; dz++) {

                int cx = centerX + dx;
                int cz = centerZ + dz;

                String k = key(cx, cz);

                if (!chunks.containsKey(k)) {
                    int originX = cx * sizeX;
                    int originZ = cz * sizeZ;

                    Chunk c = new Chunk(sizeX, sizeY, sizeZ,
                                        originX, 0, originZ,
                                        material, worldSeed);
                    
                    // Apply saved modifications to this chunk (if any)
                    applySavedModifications(c, k);
                    
                    chunks.put(k, c);
                    createdNewChunks = true;
                    
                    // Notify entity manager about new chunk (for spawning)
                    if (entityManagerCallback != null) {
                        entityManagerCallback.onChunkCreated(c);
                    }
                }
            }
        }

        // When new chunks appear, compute lighting and rebuild affected meshes
        if (createdNewChunks) {
            // First pass: compute lighting for new chunks only
            Set<String> newChunkKeys = new HashSet<>();
            for (int dx = -loadRadius; dx <= loadRadius; dx++) {
                for (int dz = -loadRadius; dz <= loadRadius; dz++) {
                    int cx = centerX + dx;
                    int cz = centerZ + dz;
                    String k = key(cx, cz);
                    Chunk c = chunks.get(k);
                    if (c != null && c.getMesh() == null) {
                        // New chunk - compute lighting for it
                        newChunkKeys.add(k);
                        computeSunlightForChunk(cx, cz);
                    }
                }
            }
            
            // Second pass: rebuild meshes of existing neighboring chunks that border new chunks
            // This ensures proper face culling at chunk boundaries
            Set<String> neighborsToRebuild = new HashSet<>();
            for (String newKey : newChunkKeys) {
                String[] parts = newKey.split(",");
                int ncx = Integer.parseInt(parts[0]);
                int ncz = Integer.parseInt(parts[1]);
                
                // Check all 4 cardinal neighbors (not diagonals)
                int[][] neighborOffsets = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                for (int[] offset : neighborOffsets) {
                    String neighborKey = key(ncx + offset[0], ncz + offset[1]);
                    // Only rebuild if neighbor exists and is NOT a new chunk
                    if (chunks.containsKey(neighborKey) && !newChunkKeys.contains(neighborKey)) {
                        neighborsToRebuild.add(neighborKey);
                    }
                }
            }
            
            // Recompute block light (light sources) for all chunks (light sources can affect multiple chunks)
            // This must happen BEFORE mesh building so block light is included in vertex data
            propagateLight();
            
            // Rebuild meshes for NEW chunks after block light propagation
            // This ensures light sources from saved modifications emit light correctly
            for (String newKey : newChunkKeys) {
                String[] parts = newKey.split(",");
                int ncx = Integer.parseInt(parts[0]);
                int ncz = Integer.parseInt(parts[1]);
                Chunk c = chunks.get(key(ncx, ncz));
                if (c != null) {
                    c.buildMesh((x, y, z) -> isAirAt(x, y, z));
                    c.buildVegetationMesh((x, y, z) -> isAirAt(x, y, z));
                }
            }
            
            // Rebuild neighboring chunks' meshes for proper face culling and lighting
            for (String neighborKey : neighborsToRebuild) {
                Chunk c = chunks.get(neighborKey);
                if (c != null) {
                    c.buildMesh((x, y, z) -> isAirAt(x, y, z));
                    c.buildVegetationMesh((x, y, z) -> isAirAt(x, y, z));
                }
            }
        }

        // Unload far chunks
        chunks.entrySet().removeIf(entry -> {
            String[] p = entry.getKey().split(",");
            int cx = Integer.parseInt(p[0]);
            int cz = Integer.parseInt(p[1]);

            if (Math.abs(cx - centerX) > unloadRadius ||
                Math.abs(cz - centerZ) > unloadRadius) {

                Chunk c = entry.getValue();
                Mesh m = c.getMesh();
                if (m != null) m.destroy();
                Mesh vegMesh = c.getVegetationMesh();
                if (vegMesh != null) vegMesh.destroy();
                return true;
            }
            return false;
        });
    }

    // ---------------------------------------------------------
    // BLOCK EDITS
    // ---------------------------------------------------------

    public void setBlockAtWorld(int wx, int wy, int wz, int value) {

        int cx = (int)Math.floor((double)wx / sizeX);
        int cz = (int)Math.floor((double)wz / sizeZ);

        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return;

        int lx = wx - c.getOriginX();
        int ly = wy - c.getOriginY();
        int lz = wz - c.getOriginZ();

        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ)
            return;

        int oldValue = c.getBlock(lx, ly, lz);
        if (oldValue == value) return; // No change

        // Remove light if placing a solid block (check if new value is solid)
        boolean wasAir = (oldValue == 0);
        boolean willBeSolid = (value != 0);
        
        if (willBeSolid && wasAir) {
            // Placing a solid block in air - remove light first
            removeLightAt(wx, wy, wz);
        }

        // Check if breaking/placing a light source
        boolean wasLightSource = (oldValue == LIGHT_SOURCE_ID || oldValue == TORCH_ID);
        boolean willBeLightSource = (value == LIGHT_SOURCE_ID || value == TORCH_ID);
        
        // Remove torch data if breaking a torch
        if (oldValue == TORCH_ID) {
            String torchKey = wx + "," + wy + "," + wz;
            torchData.remove(torchKey);
        }
        
        c.setBlock(lx, ly, lz, value);
        
        // Save the modification for chunk persistence
        saveBlockModification(cx, cz, lx, ly, lz, value);

        // Recompute lighting locally instead of globally
        if (value == 0) {
            // Block removed
            if (wasLightSource) {
                // Light source broken - remove block light first
                removeBlockLightAt(wx, wy, wz);
            }
            // Recompute sunlight locally (light can now flow)
            recomputeSunlightLocal(wx, wy, wz);
        } else {
            // Block placed - light already removed by removeLightAt
            if (willBeLightSource) {
                // If it's a light source (block 4) or torch (block 10), propagate light from this location
                Queue<int[]> queue = new ArrayDeque<>();
                setBlockLightAtWorld(wx, wy, wz, LIGHT_SOURCE_STRENGTH);
                queue.add(new int[]{wx, wy, wz});
                
                // Propagate light (increased range for better lighting)
                int maxPropagation = 128; // Limit propagation distance
                while (!queue.isEmpty() && maxPropagation > 0) {
                    int[] p = queue.poll();
                    int px = p[0], py = p[1], pz = p[2];
                    maxPropagation--;
                    
                    byte current = getBlockLightAtWorld(px, py, pz);
                    if ((current & 0xFF) <= 1) continue;
                    
                    for (int i = 0; i < 6; i++) {
                        int nx = px + DX[i];
                        int ny = py + DY[i];
                        int nz = pz + DZ[i];
                        
                        if (isSolidAtWorld(nx, ny, nz)) continue;
                        
                        byte neighbor = getBlockLightAtWorld(nx, ny, nz);
                        byte newLight = (byte)((current & 0xFF) - 1);
                        
                        if ((neighbor & 0xFF) < (newLight & 0xFF)) {
                            setBlockLightAtWorld(nx, ny, nz, newLight);
                            if (maxPropagation > 0) {
                                queue.add(new int[]{nx, ny, nz});
                            }
                        }
                    }
                }
            }
        }

        // Rebuild ONLY affected chunks' meshes (changed chunk + neighbors)
        rebuildAffectedChunks(wx, wy, wz);
    }



    public boolean isAirAtWorld(int wx, int wy, int wz) {
        return isAirAt(wx, wy, wz);
    }

    public boolean isSolidAtWorld(int wx, int wy, int wz) {
        return !isAirAt(wx, wy, wz);
    }
    
    /**
     * Check if a block can be raycasted (hit by the player's crosshair).
     * Includes solid blocks AND vegetation blocks (for breaking/placing).
     * @param wx World X coordinate
     * @param wy World Y coordinate
     * @param wz World Z coordinate
     * @return true if the block can be raycasted (not air)
     */
    public boolean isRaycastableAtWorld(int wx, int wy, int wz) {
        int cx = (int)Math.floor((double)wx / sizeX);
        int cz = (int)Math.floor((double)wz / sizeZ);

        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return false;

        int lx = wx - c.getOriginX();
        int ly = wy - c.getOriginY();
        int lz = wz - c.getOriginZ();

        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ)
            return false;

        int blockID = c.getBlock(lx, ly, lz);
        // Return true if block is not air (includes vegetation)
        return blockID != 0;
    }

    // ---------------------------------------------------------
    // LIGHT ACCESSORS
    // ---------------------------------------------------------
    
 // ---------------------------------------------------------
 // SKY LIGHT (SUNLIGHT) ACCESSORS
 // ---------------------------------------------------------

 public byte getSkyLightAtWorld(int wx, int wy, int wz) {
     int cx = (int)Math.floor((double)wx / sizeX);
     int cz = (int)Math.floor((double)wz / sizeZ);

     Chunk c = chunks.get(key(cx, cz));
     if (c == null) return 0;

     int lx = wx - c.getOriginX();
     int ly = wy - c.getOriginY();
     int lz = wz - c.getOriginZ();

     if (lx < 0 || ly < 0 || lz < 0 ||
         lx >= sizeX || ly >= sizeY || lz >= sizeZ)
         return 0;

     return c.getSkyLight(lx, ly, lz);
 }

 public void setSkyLightAtWorld(int wx, int wy, int wz, byte value) {
     int cx = (int)Math.floor((double)wx / sizeX);
     int cz = (int)Math.floor((double)wz / sizeZ);

     Chunk c = chunks.get(key(cx, cz));
     if (c == null) return;

     int lx = wx - c.getOriginX();
     int ly = wy - c.getOriginY();
     int lz = wz - c.getOriginZ();

     if (lx < 0 || ly < 0 || lz < 0 ||
         lx >= sizeX || ly >= sizeY || lz >= sizeZ)
         return;

     c.setSkyLight(lx, ly, lz, value);
 }

 // ---------------------------------------------------------
 // BLOCK LIGHT (EMISSIVE) ACCESSORS
 // ---------------------------------------------------------
	
	public byte getBlockLightAtWorld(int wx, int wy, int wz) {
	  int cx = (int)Math.floor((double)wx / sizeX);
	  int cz = (int)Math.floor((double)wz / sizeZ);
	
	  Chunk c = chunks.get(key(cx, cz));
	  if (c == null) return 0;
	
	  int lx = wx - c.getOriginX();
	  int ly = wy - c.getOriginY();
	  int lz = wz - c.getOriginZ();
	
	  if (lx < 0 || ly < 0 || lz < 0 ||
	      lx >= sizeX || ly >= sizeY || lz >= sizeZ)
	      return 0;
	
	  return c.getBlockLight(lx, ly, lz);
	}
	
	public void setBlockLightAtWorld(int wx, int wy, int wz, byte value) {
	  int cx = (int)Math.floor((double)wx / sizeX);
	  int cz = (int)Math.floor((double)wz / sizeZ);
	
	  Chunk c = chunks.get(key(cx, cz));
	  if (c == null) return;
	
	  int lx = wx - c.getOriginX();
	  int ly = wy - c.getOriginY();
	  int lz = wz - c.getOriginZ();
	
	  if (lx < 0 || ly < 0 || lz < 0 ||
	      lx >= sizeX || ly >= sizeY || lz >= sizeZ)
	      return;
	
	  c.setBlockLight(lx, ly, lz, value);
	}
	
	//Optional helper: combined light as max(sky, block)
	public byte getLightAtWorld(int wx, int wy, int wz) {
	  byte sky   = getSkyLightAtWorld(wx, wy, wz);
	  byte block = getBlockLightAtWorld(wx, wy, wz);
	  return (byte)Math.max(sky & 0xFF, block & 0xFF);
	}



    // ---------------------------------------------------------
    // SUNLIGHT (TOP DOWN + HORIZONTAL PROPAGATION)
    // ---------------------------------------------------------

	public void computeSunlight() {
	    // First pass: top-down initial sunlight
	    Queue<int[]> lightQueue = new ArrayDeque<>();
	    
	    for (Chunk c : chunks.values()) {
	        for (int x = 0; x < sizeX; x++)
	        for (int z = 0; z < sizeZ; z++) {

	            int worldX = c.getOriginX() + x;
	            int worldZ = c.getOriginZ() + z;

	            byte light = 15;

	            for (int y = sizeY - 1; y >= 0; y--) {
	                if (isSolidAtWorld(worldX, y, worldZ)) {
	                    // Solid block blocks all sunlight
	                    light = 0;
	                } else {
	                    // Air block gets sunlight
	                    setSkyLightAtWorld(worldX, y, worldZ, light);
	                    if (light > 0) {
	                        lightQueue.add(new int[]{worldX, y, worldZ});
	                    }
	                }
	            }
	        }
	    }
	    
	    // Second pass: horizontal propagation (like Minecraft)
	    while (!lightQueue.isEmpty()) {
	        int[] p = lightQueue.poll();
	        int wx = p[0], wy = p[1], wz = p[2];
	        
	        byte current = getSkyLightAtWorld(wx, wy, wz);
	        if ((current & 0xFF) <= 1) continue;
	        
	        // Propagate to 6 neighbors
	        for (int i = 0; i < 6; i++) {
	            int nx = wx + DX[i];
	            int ny = wy + DY[i];
	            int nz = wz + DZ[i];
	            
	            if (isSolidAtWorld(nx, ny, nz)) continue;
	            
	            byte neighbor = getSkyLightAtWorld(nx, ny, nz);
	            byte newLight = (byte)((current & 0xFF) - 1);
	            
	            if ((neighbor & 0xFF) < (newLight & 0xFF)) {
	                setSkyLightAtWorld(nx, ny, nz, newLight);
	                lightQueue.add(new int[]{nx, ny, nz});
	            }
	        }
	    }
	}





    // ---------------------------------------------------------
    // BLOCK LIGHT (LIGHT SOURCE BLOCKS)
    // ---------------------------------------------------------

    public void propagateLight() {
        Queue<int[]> queue = new ArrayDeque<>();

        // Find all light sources and add them to queue
        for (Chunk c : chunks.values()) {
            for (int x = 0; x < sizeX; x++)
            for (int y = 0; y < sizeY; y++)
            for (int z = 0; z < sizeZ; z++) {

                int blockID = c.getBlock(x, y, z);
                if (blockID == LIGHT_SOURCE_ID || blockID == TORCH_ID) {
                    int wx = c.getOriginX() + x;
                    int wy = y;
                    int wz = c.getOriginZ() + z;
                    c.setBlockLight(x, y, z, LIGHT_SOURCE_STRENGTH);
                    queue.add(new int[]{wx, wy, wz});
                }
            }
        }

        // Propagate block light using flood fill
        while (!queue.isEmpty()) {
            int[] p = queue.poll();
            int wx = p[0], wy = p[1], wz = p[2];

            byte current = getBlockLightAtWorld(wx, wy, wz);
            if ((current & 0xFF) <= 1) continue;

            for (int i = 0; i < 6; i++) {
                int nx = wx + DX[i];
                int ny = wy + DY[i];
                int nz = wz + DZ[i];

                if (isSolidAtWorld(nx, ny, nz)) continue;

                byte neighbor = getBlockLightAtWorld(nx, ny, nz);
                byte newLight = (byte)((current & 0xFF) - 1);
                
                if ((neighbor & 0xFF) < (newLight & 0xFF)) {
                    setBlockLightAtWorld(nx, ny, nz, newLight);
                    queue.add(new int[]{nx, ny, nz});
                }
            }
        }
    }
    
    // Remove block light when a light source is broken
    private void removeBlockLightAt(int wx, int wy, int wz) {
        byte blockLight = getBlockLightAtWorld(wx, wy, wz);
        
        if (blockLight == 0) return;
        
        // Remove block light using flood fill (similar to removeLightAt but only for block light)
        Queue<int[]> removeQueue = new ArrayDeque<>();
        removeQueue.add(new int[]{wx, wy, wz});
        
        while (!removeQueue.isEmpty()) {
            int[] p = removeQueue.poll();
            int x = p[0], y = p[1], z = p[2];
            
            byte current = getBlockLightAtWorld(x, y, z);
            if (current == 0) continue;
            
            setBlockLightAtWorld(x, y, z, (byte)0);
            
            // Check neighbors that might need light removal
            for (int i = 0; i < 6; i++) {
                int nx = x + DX[i];
                int ny = y + DY[i];
                int nz = z + DZ[i];
                
                if (isSolidAtWorld(nx, ny, nz)) continue;
                
                byte neighbor = getBlockLightAtWorld(nx, ny, nz);
                if (neighbor > 0 && neighbor < current) {
                    removeQueue.add(new int[]{nx, ny, nz});
                }
            }
        }
    }
    
    // Remove light when a block is placed (called before setting the block)
    private void removeLightAt(int wx, int wy, int wz) {
        byte skyLight = getSkyLightAtWorld(wx, wy, wz);
        byte blockLight = getBlockLightAtWorld(wx, wy, wz);
        
        if (skyLight == 0 && blockLight == 0) return;
        
        // Remove sky light
        if (skyLight > 0) {
            Queue<int[]> removeQueue = new ArrayDeque<>();
            removeQueue.add(new int[]{wx, wy, wz});
            
            while (!removeQueue.isEmpty()) {
                int[] p = removeQueue.poll();
                int x = p[0], y = p[1], z = p[2];
                
                byte current = getSkyLightAtWorld(x, y, z);
                if (current == 0) continue;
                
                setSkyLightAtWorld(x, y, z, (byte)0);
                
                // Check neighbors that might need light removal
                for (int i = 0; i < 6; i++) {
                    int nx = x + DX[i];
                    int ny = y + DY[i];
                    int nz = z + DZ[i];
                    
                    if (isSolidAtWorld(nx, ny, nz)) continue;
                    
                    byte neighbor = getSkyLightAtWorld(nx, ny, nz);
                    if (neighbor > 0 && neighbor < current) {
                        removeQueue.add(new int[]{nx, ny, nz});
                    }
                }
            }
        }
        
        // Remove block light
        if (blockLight > 0) {
            Queue<int[]> removeQueue = new ArrayDeque<>();
            removeQueue.add(new int[]{wx, wy, wz});
            
            while (!removeQueue.isEmpty()) {
                int[] p = removeQueue.poll();
                int x = p[0], y = p[1], z = p[2];
                
                byte current = getBlockLightAtWorld(x, y, z);
                if (current == 0) continue;
                
                setBlockLightAtWorld(x, y, z, (byte)0);
                
                // Check neighbors that might need light removal
                for (int i = 0; i < 6; i++) {
                    int nx = x + DX[i];
                    int ny = y + DY[i];
                    int nz = z + DZ[i];
                    
                    if (isSolidAtWorld(nx, ny, nz)) continue;
                    
                    byte neighbor = getBlockLightAtWorld(nx, ny, nz);
                    if (neighbor > 0 && neighbor < current) {
                        removeQueue.add(new int[]{nx, ny, nz});
                    }
                }
            }
        }
    }





    // ---------------------------------------------------------
    // LOCAL LIGHTING UPDATES
    // ---------------------------------------------------------

    // Recompute sunlight locally around a block position (simplified for performance)
    private void recomputeSunlightLocal(int centerX, int centerY, int centerZ) {
        // Only recompute sunlight in a 3x3 chunk area around the block change
        int cx = (int)Math.floor((double)centerX / sizeX);
        int cz = (int)Math.floor((double)centerZ / sizeZ);
        Set<String> affectedChunkKeys = new HashSet<>();
        
        // Collect affected chunks (3x3 area)
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                affectedChunkKeys.add(key(cx + dx, cz + dz));
            }
        }
        
        // Reset sunlight in affected chunks
        for (String k : affectedChunkKeys) {
            Chunk c = chunks.get(k);
            if (c != null) {
                for (int x = 0; x < sizeX; x++) {
                    for (int y = 0; y < sizeY; y++) {
                        for (int z = 0; z < sizeZ; z++) {
                            c.setSkyLight(x, y, z, (byte)0);
                        }
                    }
                }
            }
        }
        
        // Recompute sunlight for affected chunks (top-down pass)
        Queue<int[]> lightQueue = new ArrayDeque<>();
        
        for (String k : affectedChunkKeys) {
            Chunk c = chunks.get(k);
            if (c == null) continue;
            
            for (int x = 0; x < sizeX; x++) {
                for (int z = 0; z < sizeZ; z++) {
                    int worldX = c.getOriginX() + x;
                    int worldZ = c.getOriginZ() + z;
                    byte light = 15;
                    
                    for (int y = sizeY - 1; y >= 0; y--) {
                        if (isSolidAtWorld(worldX, y, worldZ)) {
                            light = 0;
                        } else {
                            setSkyLightAtWorld(worldX, y, worldZ, light);
                            if (light > 0) {
                                lightQueue.add(new int[]{worldX, y, worldZ});
                            }
                        }
                    }
                }
            }
        }
        
        // Propagate sunlight (limited propagation for performance)
        int maxPropagation = 128;
        while (!lightQueue.isEmpty() && maxPropagation > 0) {
            int[] p = lightQueue.poll();
            int wx = p[0], wy = p[1], wz = p[2];
            maxPropagation--;
            
            byte current = getSkyLightAtWorld(wx, wy, wz);
            if ((current & 0xFF) <= 1) continue;
            
            for (int i = 0; i < 6; i++) {
                int nx = wx + DX[i];
                int ny = wy + DY[i];
                int nz = wz + DZ[i];
                
                if (isSolidAtWorld(nx, ny, nz)) continue;
                
                byte neighbor = getSkyLightAtWorld(nx, ny, nz);
                byte newLight = (byte)((current & 0xFF) - 1);
                
                if ((neighbor & 0xFF) < (newLight & 0xFF)) {
                    setSkyLightAtWorld(nx, ny, nz, newLight);
                    if (maxPropagation > 0) {
                        lightQueue.add(new int[]{nx, ny, nz});
                    }
                }
            }
        }
    }
    
    // Compute sunlight for a single chunk
    private void computeSunlightForChunk(int cx, int cz) {
        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return;
        
        Queue<int[]> lightQueue = new ArrayDeque<>();
        
        for (int x = 0; x < sizeX; x++) {
            for (int z = 0; z < sizeZ; z++) {
                int worldX = c.getOriginX() + x;
                int worldZ = c.getOriginZ() + z;
                byte light = 15;
                
                for (int y = sizeY - 1; y >= 0; y--) {
                    if (isSolidAtWorld(worldX, y, worldZ)) {
                        light = 0;
                    } else {
                        setSkyLightAtWorld(worldX, y, worldZ, light);
                        if (light > 0) {
                            lightQueue.add(new int[]{worldX, y, worldZ});
                        }
                    }
                }
            }
        }
        
        // Limited horizontal propagation
        int maxPropagation = 128;
        while (!lightQueue.isEmpty() && maxPropagation > 0) {
            int[] p = lightQueue.poll();
            int wx = p[0], wy = p[1], wz = p[2];
            maxPropagation--;
            
            byte current = getSkyLightAtWorld(wx, wy, wz);
            if ((current & 0xFF) <= 1) continue;
            
            for (int i = 0; i < 6; i++) {
                int nx = wx + DX[i];
                int ny = wy + DY[i];
                int nz = wz + DZ[i];
                
                if (isSolidAtWorld(nx, ny, nz)) continue;
                
                byte neighbor = getSkyLightAtWorld(nx, ny, nz);
                byte newLight = (byte)((current & 0xFF) - 1);
                
                if ((neighbor & 0xFF) < (newLight & 0xFF)) {
                    setSkyLightAtWorld(nx, ny, nz, newLight);
                    if (maxPropagation > 0) {
                        lightQueue.add(new int[]{nx, ny, nz});
                    }
                }
            }
        }
        
        // NOTE: Mesh building is now done AFTER propagateLight() is called
        // This ensures block light from light sources is included in vertex data
    }
    
    // Rebuild meshes only for affected chunks (changed chunk + neighbors)
    private void rebuildAffectedChunks(int wx, int wy, int wz) {
        int cx = (int)Math.floor((double)wx / sizeX);
        int cz = (int)Math.floor((double)wz / sizeZ);
        
        // Rebuild the changed chunk and its 8 neighbors (including diagonals for edge cases)
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                int ncx = cx + dx;
                int ncz = cz + dz;
                Chunk c = chunks.get(key(ncx, ncz));
                if (c != null) {
                    c.buildMesh((x, y, z) -> isAirAt(x, y, z));
                    // Build vegetation mesh (crossed quads)
                    c.buildVegetationMesh((x, y, z) -> isAirAt(x, y, z));
                }
            }
        }
    }



    // ---------------------------------------------------------

    public int getBlockAtWorld(int wx, int wy, int wz) {
        int cx = (int)Math.floor((double)wx / sizeX);
        int cz = (int)Math.floor((double)wz / sizeZ);

        Chunk c = chunks.get(key(cx, cz));
        if (c == null) return 0;

        int lx = wx - c.getOriginX();
        int ly = wy - c.getOriginY();
        int lz = wz - c.getOriginZ();

        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ)
            return 0;

        return c.getBlock(lx, ly, lz);
    }

    public void registerMaterial(int blockID, Material mat) {
        materials.put(blockID, mat);
    }

    public Iterable<Chunk> getChunks() {
        return chunks.values();
    }
    
    /**
     * Set the torch data (normal and hit position) for a torch at the given world position.
     * @param wx World X coordinate (block position where torch ID is stored)
     * @param wy World Y coordinate
     * @param wz World Z coordinate
     * @param normal Normal vector indicating placement face
     * @param hitPosition Exact position where raycast hit the face
     */
    public void setTorchData(int wx, int wy, int wz, Vector3f normal, Vector3f hitPosition) {
        String key = wx + "," + wy + "," + wz;
        torchData.put(key, new TorchData(normal, hitPosition));
    }
    
    /**
     * Get the torch data for a torch at the given world position.
     * Returns null if no torch exists at that position or data is not stored.
     * @param wx World X coordinate
     * @param wy World Y coordinate
     * @param wz World Z coordinate
     * @return TorchData (normal + hit position) or null
     */
    public TorchData getTorchData(int wx, int wy, int wz) {
        String key = wx + "," + wy + "," + wz;
        return torchData.get(key);
    }
    
    public void setChunkCreatedCallback(ChunkCreatedCallback callback) {
        this.entityManagerCallback = callback;
    }
    
    // ---------------------------------------------------------
    // CHUNK MODIFICATION PERSISTENCE
    // ---------------------------------------------------------
    
    /**
     * Save a block modification for chunk persistence.
     * When the chunk is unloaded and later reloaded, this modification will be applied.
     * @param cx Chunk X coordinate
     * @param cz Chunk Z coordinate
     * @param lx Local block X coordinate within chunk
     * @param ly Local block Y coordinate within chunk
     * @param lz Local block Z coordinate within chunk
     * @param blockID The block ID to save
     */
    private void saveBlockModification(int cx, int cz, int lx, int ly, int lz, int blockID) {
        String chunkKey = key(cx, cz);
        String blockKey = lx + "," + ly + "," + lz;
        
        // Get or create the modifications map for this chunk
        Map<String, Integer> modifications = chunkModifications.computeIfAbsent(chunkKey, k -> new HashMap<>());
        
        // Save the modification
        modifications.put(blockKey, blockID);
    }
    
    /**
     * Apply saved modifications to a newly loaded chunk.
     * This restores any block changes made before the chunk was unloaded.
     * @param chunk The chunk to apply modifications to
     * @param chunkKey The chunk key (e.g., "0,0")
     */
    private void applySavedModifications(Chunk chunk, String chunkKey) {
        Map<String, Integer> modifications = chunkModifications.get(chunkKey);
        if (modifications == null || modifications.isEmpty()) {
            return; // No modifications for this chunk
        }
        
        // Apply each saved modification
        for (Map.Entry<String, Integer> entry : modifications.entrySet()) {
            String blockKey = entry.getKey();
            int blockID = entry.getValue();
            
            // Parse the local block position
            String[] parts = blockKey.split(",");
            if (parts.length != 3) continue;
            
            try {
                int lx = Integer.parseInt(parts[0]);
                int ly = Integer.parseInt(parts[1]);
                int lz = Integer.parseInt(parts[2]);
                
                // Validate bounds
                if (lx >= 0 && lx < sizeX && ly >= 0 && ly < sizeY && lz >= 0 && lz < sizeZ) {
                    chunk.setBlock(lx, ly, lz, blockID);
                }
            } catch (NumberFormatException e) {
                // Skip invalid entries
            }
        }
    }
    
    // ---------------------------------------------------------
    // LEVEL SAVE/LOAD (level.dat)
    // ---------------------------------------------------------
    
    /**
     * Save the world data to level.dat file.
     * Saves the world seed, time of day, block modifications, and torch data.
     */
    public void saveWorld() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(SAVE_FILE))) {
            // Write header
            writer.write("# BlockCube World Save File");
            writer.newLine();
            
            // Write world seed
            writer.write("SEED:" + worldSeed);
            writer.newLine();
            
            // Write time of day
            writer.write("TIME:" + timeOfDay);
            writer.newLine();
            
            // Write block modifications
            // Format: MOD:chunkKey|lx,ly,lz|blockID
            for (Map.Entry<String, Map<String, Integer>> chunkEntry : chunkModifications.entrySet()) {
                String chunkKey = chunkEntry.getKey();
                Map<String, Integer> modifications = chunkEntry.getValue();
                
                for (Map.Entry<String, Integer> blockEntry : modifications.entrySet()) {
                    String blockKey = blockEntry.getKey();
                    int blockID = blockEntry.getValue();
                    writer.write("MOD:" + chunkKey + "|" + blockKey + "|" + blockID);
                    writer.newLine();
                }
            }
            
            // Write torch data
            // Format: TORCH:wx,wy,wz|nx,ny,nz|hx,hy,hz
            for (Map.Entry<String, TorchData> entry : torchData.entrySet()) {
                String posKey = entry.getKey();
                TorchData data = entry.getValue();
                Vector3f normal = data.getNormal();
                Vector3f hitPos = data.getHitPosition();
                
                writer.write("TORCH:" + posKey + "|" + 
                    normal.getX() + "," + normal.getY() + "," + normal.getZ() + "|" +
                    hitPos.getX() + "," + hitPos.getY() + "," + hitPos.getZ());
                writer.newLine();
            }
            
            System.out.println("World saved to " + SAVE_FILE + " (seed: " + worldSeed + ", modifications: " + countTotalModifications() + ")");
            
        } catch (IOException e) {
            System.err.println("Failed to save world: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Load the world data from level.dat file.
     * Loads the world seed, block modifications, and torch data.
     * @return true if a save file was found and loaded, false otherwise
     */
    public boolean loadWorld() {
        File saveFile = new File(SAVE_FILE);
        if (!saveFile.exists()) {
            System.out.println("No save file found, generating new world with seed: " + worldSeed);
            return false;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(saveFile))) {
            String line;
            int modCount = 0;
            int torchCount = 0;
            
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                
                // Skip empty lines and comments
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                
                // Parse seed
                if (line.startsWith("SEED:")) {
                    try {
                        worldSeed = Long.parseLong(line.substring(5));
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid seed in save file: " + line);
                    }
                }
                
                // Parse time of day
                else if (line.startsWith("TIME:")) {
                    try {
                        timeOfDay = Float.parseFloat(line.substring(5));
                        timeOfDay = Math.max(0, Math.min(1, timeOfDay)); // Clamp to 0-1
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid time in save file: " + line);
                    }
                }
                
                // Parse block modifications
                // Format: MOD:chunkKey|lx,ly,lz|blockID
                else if (line.startsWith("MOD:")) {
                    try {
                        String data = line.substring(4);
                        String[] parts = data.split("\\|");
                        if (parts.length == 3) {
                            String chunkKey = parts[0];
                            String blockKey = parts[1];
                            int blockID = Integer.parseInt(parts[2]);
                            
                            Map<String, Integer> modifications = chunkModifications.computeIfAbsent(chunkKey, k -> new HashMap<>());
                            modifications.put(blockKey, blockID);
                            modCount++;
                        }
                    } catch (Exception e) {
                        System.err.println("Invalid modification entry: " + line);
                    }
                }
                
                // Parse torch data
                // Format: TORCH:wx,wy,wz|nx,ny,nz|hx,hy,hz
                else if (line.startsWith("TORCH:")) {
                    try {
                        String data = line.substring(6);
                        String[] parts = data.split("\\|");
                        if (parts.length == 3) {
                            String posKey = parts[0];
                            
                            String[] normalParts = parts[1].split(",");
                            Vector3f normal = new Vector3f(
                                Float.parseFloat(normalParts[0]),
                                Float.parseFloat(normalParts[1]),
                                Float.parseFloat(normalParts[2])
                            );
                            
                            String[] hitParts = parts[2].split(",");
                            Vector3f hitPos = new Vector3f(
                                Float.parseFloat(hitParts[0]),
                                Float.parseFloat(hitParts[1]),
                                Float.parseFloat(hitParts[2])
                            );
                            
                            torchData.put(posKey, new TorchData(normal, hitPos));
                            torchCount++;
                        }
                    } catch (Exception e) {
                        System.err.println("Invalid torch entry: " + line);
                    }
                }
            }
            
            System.out.println("World loaded from " + SAVE_FILE + " (seed: " + worldSeed + ", time: " + timeOfDay + ", modifications: " + modCount + ", torches: " + torchCount + ")");
            return true;
            
        } catch (IOException e) {
            System.err.println("Failed to load world: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Count total number of block modifications across all chunks.
     */
    private int countTotalModifications() {
        int count = 0;
        for (Map<String, Integer> modifications : chunkModifications.values()) {
            count += modifications.size();
        }
        return count;
    }
}