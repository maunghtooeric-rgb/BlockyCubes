package blockcube.blockcube.graphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;
import blockcube.blockcube.utils.Noise;

public class Chunk {
    private final int sizeX;
    private final int sizeY;
    private final int sizeZ;
    private static final int MAX_TERRAIN_HEIGHT = 32; // Maximum height in blocks (matches chunk height)

    // 0 = air, 1 = dirt, 2 = log, 3 = leaves
    private final int[][][] blocks;
    private final byte[][][] light; // same size as blocks
    private byte[][][] skyLight;
    private byte[][][] blockLight;

    private final Material material;
    private Mesh mesh;
    private Mesh vegetationMesh; // Separate mesh for vegetation (crossed quads)

    private final int originX, originY, originZ;
    private final long seed; // World seed for consistent terrain generation
    private final Random chunkRandom; // Seeded random for this chunk

    public Chunk(int sizeX, int sizeY, int sizeZ,
            int originX, int originY, int originZ,
            Material material, long seed) {
		   this.sizeX = sizeX;
		   this.sizeY = sizeY;
		   this.sizeZ = sizeZ;
		   this.originX = originX;
		   this.originY = originY;
		   this.originZ = originZ;
		   this.material = material;
		   this.seed = seed;
		   
		   // Create a seeded random for this chunk (based on seed + chunk position)
		   // This ensures the same chunk always generates the same features
		   long chunkSeed = seed ^ ((long)originX * 341873128712L + (long)originZ * 132897987541L);
		   this.chunkRandom = new Random(chunkSeed);
		
		   this.blocks     = new int[sizeX][sizeY][sizeZ];
		   this.light      = new byte[sizeX][sizeY][sizeZ];      // optional
		   this.skyLight   = new byte[sizeX][sizeY][sizeZ];
		   this.blockLight = new byte[sizeX][sizeY][sizeZ];
		   
		   // Seed offset for noise (creates unique but consistent terrain per seed)
		   double seedOffsetX = (seed % 10000) * 1000.0;
		   double seedOffsetZ = ((seed / 10000) % 10000) * 1000.0;
		
		   // Noise-based terrain generation
		   // Noise parameters for base terrain
		   double noiseScale = 0.05; // Controls how spread out the terrain features are
		   int octaves = 3; // Number of noise layers for more natural terrain
		   double persistence = 0.5; // How much each octave contributes
		   
		   // Player spawn position (0, 60, 0)
		   int spawnX = 0;
		   int spawnZ = 0;
		   int mountainStartDistance = 100; // Mountains start 100 blocks away from spawn
		   
		   // Mountain noise parameters (using gradient/Perlin noise)
		   double mountainNoiseScale = 0.02; // Smaller scale for larger mountain features
		   int mountainOctaves = 4; // More octaves for detailed mountains
		   double mountainPersistence = 0.6;
		   double mountainAmplitude = 20.0; // Height multiplier for mountains
		   
		   for (int x = 0; x < sizeX; x++) {
		       for (int z = 0; z < sizeZ; z++) {
		           // Calculate world coordinates
		           int worldX = originX + x;
		           int worldZ = originZ + z;
		           
		           // Calculate distance from spawn
		           double distFromSpawn = Math.sqrt((worldX - spawnX) * (worldX - spawnX) + 
		                                            (worldZ - spawnZ) * (worldZ - spawnZ));
		           
		           // Generate base terrain noise value (-1.0 to 1.0) with seed offset
		           double baseNoiseValue = Noise.octaveNoise2D(worldX + seedOffsetX, worldZ + seedOffsetZ, octaves, persistence, noiseScale);
		           
		           // Convert base noise to height (0 to MAX_TERRAIN_HEIGHT)
		           // Map from [-1, 1] to [0, MAX_TERRAIN_HEIGHT]
		           int baseHeight = (int) Math.round((baseNoiseValue + 1.0) * 0.5 * MAX_TERRAIN_HEIGHT);
		           baseHeight = Math.max(0, Math.min(MAX_TERRAIN_HEIGHT, baseHeight)); // Clamp to [0, MAX_TERRAIN_HEIGHT]
		           
		           // Add mountain height if far enough from spawn
		           int finalHeight = baseHeight;
		           if (distFromSpawn >= mountainStartDistance) {
		               // Generate mountain noise using gradient/Perlin noise with seed offset
		               double mountainNoise = Noise.octaveNoise2D(worldX + seedOffsetX, worldZ + seedOffsetZ, mountainOctaves, mountainPersistence, mountainNoiseScale);
		               
		               // Map mountain noise from [-1, 1] to [0, mountainAmplitude]
		               // Only apply positive values to create peaks
		               double mountainHeight = (mountainNoise + 1.0) * 0.5 * mountainAmplitude;
		               
		               // Apply distance-based falloff to make mountains gradually appear
		               // Smooth transition from 100 to 150 blocks
		               double distanceFactor = 1.0;
		               if (distFromSpawn < 150) {
		                   distanceFactor = (distFromSpawn - mountainStartDistance) / 50.0; // 0 to 1 from 100 to 150 blocks
		                   distanceFactor = Math.max(0.0, Math.min(1.0, distanceFactor)); // Clamp
		               }
		               
		               // Add mountain height to base height
		               int mountainHeightInt = (int) Math.round(mountainHeight * distanceFactor);
		               finalHeight = baseHeight + mountainHeightInt;
		               
		               // Clamp to chunk height (32 blocks)
		               finalHeight = Math.max(0, Math.min(MAX_TERRAIN_HEIGHT, finalHeight));
		           }
		           
		           // Fill blocks from y=0 up to finalHeight
		           for (int y = 0; y < sizeY; y++) {
		               int worldY = originY + y;
		               
		               // Place dirt blocks up to the calculated height
		               if (worldY >= 0 && worldY < finalHeight) {
		                   blocks[x][y][z] = 1; // dirt
		               } else {
		                   blocks[x][y][z] = 0; // air
		               }
		               
		               light[x][y][z]      = 0;
		               skyLight[x][y][z]   = 0;
		               blockLight[x][y][z] = 0;
		           }
		       }
		   }
		
		   // Generate caves using 3D noise
		   generateCaves();
		
		   generateTrees();
		   
		   generateVegetation();
	}

    // Get sunlight (skyLight) from local coords, clamped to chunk bounds
    private float sampleSunLightLocal(int lx, int ly, int lz,
                                      int fallbackBx, int fallbackBy, int fallbackBz) {
        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ) {
            return (skyLight[fallbackBx][fallbackBy][fallbackBz] & 0xFF) / 15.0f;
        }
        return (skyLight[lx][ly][lz] & 0xFF) / 15.0f;
    }

    // Get block light from local coords, clamped to chunk bounds
    private float sampleBlockLightLocal(int lx, int ly, int lz,
                                        int fallbackBx, int fallbackBy, int fallbackBz) {
        if (lx < 0 || ly < 0 || lz < 0 ||
            lx >= sizeX || ly >= sizeY || lz >= sizeZ) {
            return (blockLight[fallbackBx][fallbackBy][fallbackBz] & 0xFF) / 15.0f;
        }
        return (blockLight[lx][ly][lz] & 0xFF) / 15.0f;
    }

    /**
     * Calculate ambient occlusion for a vertex.
     * Checks the three blocks that form a corner around the vertex.
     * Returns 1.0 (no shadow) to 0.0 (full shadow).
     */
    private float calculateAO(FaceVisibility visibility, int wx, int wy, int wz, 
                             int dx1, int dy1, int dz1,  // First adjacent block
                             int dx2, int dy2, int dz2,  // Second adjacent block
                             int dx3, int dy3, int dz3) { // Diagonal block (corner)
        int occluded = 0;
        
        // Check if first adjacent block is solid
        if (!visibility.isAir(wx + dx1, wy + dy1, wz + dz1)) occluded++;
        // Check if second adjacent block is solid
        if (!visibility.isAir(wx + dx2, wy + dy2, wz + dz2)) occluded++;
        // Check if diagonal (corner) block is solid
        if (!visibility.isAir(wx + dx3, wy + dy3, wz + dz3)) occluded++;
        
        // AO values: 0 blocks = 1.0, 1 block = 0.8, 2 blocks = 0.6, 3 blocks = 0.4
        // This creates smooth shadows in corners
        switch (occluded) {
            case 0: return 1.0f;  // No occlusion
            case 1: return 0.8f;  // Light shadow
            case 2: return 0.6f;  // Medium shadow
            case 3: return 0.4f;  // Dark shadow
            default: return 1.0f;
        }
    }

    private void addFace(List<Vertex> vertices, List<Integer> indices,
            int bx, int by, int bz, Direction dir, FaceVisibility visibility) {
			// Local block center
			float x = bx + 0.5f;
			float y = by + 0.5f;
			float z = bz + 0.5f;
			
			int blockTextureID = getTextureIndex(blocks[bx][by][bz]);
			
			// World coordinates for AO calculation
			int wx = originX + bx;
			int wy = originY + by;
			int wz = originZ + bz;
			
			float sunLevel;
			float blockLevel;
			
			switch (dir) {
			case RIGHT:  // +X
			   sunLevel   = sampleSunLightLocal  (bx + 1, by, bz, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx + 1, by, bz, bx, by, bz);
			   break;
			case LEFT:   // -X
			   sunLevel   = sampleSunLightLocal  (bx - 1, by, bz, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx - 1, by, bz, bx, by, bz);
			   break;
			case TOP:    // +Y
			   sunLevel   = sampleSunLightLocal  (bx, by + 1, bz, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx, by + 1, bz, bx, by, bz);
			   break;
			case BOTTOM: // -Y
			   sunLevel   = sampleSunLightLocal  (bx, by - 1, bz, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx, by - 1, bz, bx, by, bz);
			   break;
			case FRONT:  // +Z
			   sunLevel   = sampleSunLightLocal  (bx, by, bz + 1, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx, by, bz + 1, bx, by, bz);
			   break;
			case BACK:   // -Z
			   sunLevel   = sampleSunLightLocal  (bx, by, bz - 1, bx, by, bz);
			   blockLevel = sampleBlockLightLocal(bx, by, bz - 1, bx, by, bz);
			   break;
			default:
			   sunLevel   = (skyLight  [bx][by][bz] & 0xFF) / 15.0f;
			   blockLevel = (blockLight[bx][by][bz] & 0xFF) / 15.0f;
			   break;
			}
			
			int base = vertices.size();
			
			// Calculate AO for each vertex based on corner position
			// Each vertex checks 3 blocks: the two adjacent to the face and the diagonal corner
			float ao0, ao1, ao2, ao3;
			
			switch (dir) {
			case RIGHT: { // +X face
			   // Vertex 0: top-left corner (y+, z-)
			   ao0 = calculateAO(visibility, wx, wy, wz, 1, 1, 0, 1, 0, -1, 1, 1, -1);
			   // Vertex 1: bottom-left corner (y-, z-)
			   ao1 = calculateAO(visibility, wx, wy, wz, 1, -1, 0, 1, 0, -1, 1, -1, -1);
			   // Vertex 2: bottom-right corner (y-, z+)
			   ao2 = calculateAO(visibility, wx, wy, wz, 1, -1, 0, 1, 0, 1, 1, -1, 1);
			   // Vertex 3: top-right corner (y+, z+)
			   ao3 = calculateAO(visibility, wx, wy, wz, 1, 1, 0, 1, 0, 1, 1, 1, 1);
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z - 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z - 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z + 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z + 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			case LEFT: { // -X face
			   ao0 = calculateAO(visibility, wx, wy, wz, -1, 1, 0, -1, 0, 1, -1, 1, 1);
			   ao1 = calculateAO(visibility, wx, wy, wz, -1, -1, 0, -1, 0, 1, -1, -1, 1);
			   ao2 = calculateAO(visibility, wx, wy, wz, -1, -1, 0, -1, 0, -1, -1, -1, -1);
			   ao3 = calculateAO(visibility, wx, wy, wz, -1, 1, 0, -1, 0, -1, -1, 1, -1);
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z + 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z + 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z - 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z - 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			case TOP: { // +Y face
			   ao0 = calculateAO(visibility, wx, wy, wz, 0, 1, 1, -1, 1, 0, -1, 1, 1);
			   ao1 = calculateAO(visibility, wx, wy, wz, 0, 1, -1, -1, 1, 0, -1, 1, -1);
			   ao2 = calculateAO(visibility, wx, wy, wz, 0, 1, -1, 1, 1, 0, 1, 1, -1);
			   ao3 = calculateAO(visibility, wx, wy, wz, 0, 1, 1, 1, 1, 0, 1, 1, 1);
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z + 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z - 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z - 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z + 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			case BOTTOM: { // -Y face
			   ao0 = calculateAO(visibility, wx, wy, wz, 0, -1, -1, -1, -1, 0, -1, -1, -1);
			   ao1 = calculateAO(visibility, wx, wy, wz, 0, -1, 1, -1, -1, 0, -1, -1, 1);
			   ao2 = calculateAO(visibility, wx, wy, wz, 0, -1, 1, 1, -1, 0, 1, -1, 1);
			   ao3 = calculateAO(visibility, wx, wy, wz, 0, -1, -1, 1, -1, 0, 1, -1, -1);
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z - 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z + 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z + 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z - 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			case FRONT: { // +Z face
			   ao0 = calculateAO(visibility, wx, wy, wz, -1, 0, 1, 0, 1, 1, -1, 1, 1);
			   ao1 = calculateAO(visibility, wx, wy, wz, -1, 0, 1, 0, -1, 1, -1, -1, 1);
			   ao2 = calculateAO(visibility, wx, wy, wz, 1, 0, 1, 0, -1, 1, 1, -1, 1);
			   ao3 = calculateAO(visibility, wx, wy, wz, 1, 0, 1, 0, 1, 1, 1, 1, 1);
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z + 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z + 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z + 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z + 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			case BACK: { // -Z face (north face - user specifically mentioned this)
			   ao0 = calculateAO(visibility, wx, wy, wz, 1, 0, -1, 0, 1, -1, 1, 1, -1);
			   ao1 = calculateAO(visibility, wx, wy, wz, 1, 0, -1, 0, -1, -1, 1, -1, -1);
			   ao2 = calculateAO(visibility, wx, wy, wz, -1, 0, -1, 0, -1, -1, -1, -1, -1);
			   ao3 = calculateAO(visibility, wx, wy, wz, -1, 0, -1, 0, 1, -1, -1, 1, -1);
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y + 0.5f, z - 0.5f), new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao0));
			   vertices.add(new Vertex(new Vector3f(x + 0.5f, y - 0.5f, z - 0.5f), new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao1));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y - 0.5f, z - 0.5f), new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao2));
			   vertices.add(new Vertex(new Vector3f(x - 0.5f, y + 0.5f, z - 0.5f), new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao3));
			   break;
			}
			}
			
			// Consistent triangles
			indices.add(base + 0);
			indices.add(base + 1);
			indices.add(base + 2);
			indices.add(base + 0);
			indices.add(base + 2);
			indices.add(base + 3);
		}

    /**
     * Build mesh using neighbor-aware visibility check.
     * visibility.isAir(wx, wy, wz) should return true if the neighbor is air.
     * Skips vegetation blocks - they are rendered separately as crossed quads.
     */
    public void buildMesh(FaceVisibility visibility) {
        List<Vertex> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();

        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                for (int z = 0; z < sizeZ; z++) {
                    int block = blocks[x][y][z];
                    if (block == 0) continue; // air
                    
                    // Skip vegetation blocks - they use separate mesh with crossed quads
                    if (BlockType.isVegetation(block)) continue;
                    
                    // Skip torch blocks - they are rendered separately with custom orientation
                    if (block == BlockType.TORCH.id) continue;

                    int wx = originX + x;
                    int wy = originY + y;
                    int wz = originZ + z;

                    if (visibility.isAir(wx + 1, wy, wz)) addFace(vertices, indices, x, y, z, Direction.RIGHT, visibility);
                    if (visibility.isAir(wx - 1, wy, wz)) addFace(vertices, indices, x, y, z, Direction.LEFT, visibility);
                    if (visibility.isAir(wx, wy + 1, wz)) addFace(vertices, indices, x, y, z, Direction.TOP, visibility);
                    if (visibility.isAir(wx, wy - 1, wz)) addFace(vertices, indices, x, y, z, Direction.BOTTOM, visibility);
                    if (visibility.isAir(wx, wy, wz + 1)) addFace(vertices, indices, x, y, z, Direction.FRONT, visibility);
                    if (visibility.isAir(wx, wy, wz - 1)) addFace(vertices, indices, x, y, z, Direction.BACK, visibility);
                }
            }
        }

        mesh = new Mesh(
            vertices.toArray(new Vertex[0]),
            indices.stream().mapToInt(i -> i).toArray(),
            material
        );
        mesh.create();
    }
    
    /**
     * Add crossed quads (X-shaped) for vegetation blocks.
     * Creates two vertical quads intersecting at 90 degrees:
     * - Quad A: facing north-south (aligned with Z-axis)
     * - Quad B: facing east-west (aligned with X-axis)
     * 
     * @param vertices Vertex list to add to
     * @param indices Index list to add to
     * @param bx Local block X coordinate
     * @param by Local block Y coordinate
     * @param bz Local block Z coordinate
     * @param blockID Block ID (determines texture)
     * @param visibility Face visibility checker
     * @param quadWidth Width of each quad (default 1.0 = full block width)
     * @param quadHeight Height of each quad (default 1.0 = full block height)
     */
    private void addCrossedQuads(List<Vertex> vertices, List<Integer> indices,
                                 int bx, int by, int bz, int blockID,
                                 FaceVisibility visibility,
                                 float quadWidth, float quadHeight) {
        // Local block center
        float x = bx + 0.5f;
        float y = by + 0.5f;
        float z = bz + 0.5f;
        
        // World coordinates for lighting (currently using local block lighting)
        // int wx = originX + bx;
        // int wy = originY + by;
        // int wz = originZ + bz;
        
        // Get lighting from the block itself (vegetation doesn't cast shadows)
        float sunLevel = (skyLight[bx][by][bz] & 0xFF) / 15.0f;
        float blockLevel = (blockLight[bx][by][bz] & 0xFF) / 15.0f;
        
        // Vegetation blocks don't use ambient occlusion (always 1.0)
        float ao = 1.0f;
        
        // Texture index based on block ID
        // Vegetation textures are bound to slots 4-8 in the renderer
        int blockTextureID = getVegetationTextureIndex(blockID);
        
        // Half dimensions for quads
        float halfWidth = quadWidth * 0.5f;
        float halfHeight = quadHeight * 0.5f;
        
        // QUAD A: North-South facing (aligned with Z-axis)
        // This quad extends along the Z-axis, facing east/west
        int baseA = vertices.size();
        
        // Top-left, bottom-left, bottom-right, top-right
        // Quad A vertices (facing +X direction, centered at block position)
        vertices.add(new Vertex(
            new Vector3f(x + halfWidth, y + halfHeight, z),  // Top-left
            new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x + halfWidth, y - halfHeight, z),  // Bottom-left
            new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x - halfWidth, y - halfHeight, z),  // Bottom-right
            new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x - halfWidth, y + halfHeight, z),  // Top-right
            new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao
        ));
        
        // Quad A indices (two triangles)
        indices.add(baseA + 0);
        indices.add(baseA + 1);
        indices.add(baseA + 2);
        indices.add(baseA + 0);
        indices.add(baseA + 2);
        indices.add(baseA + 3);
        
        // QUAD B: East-West facing (aligned with X-axis)
        // This quad extends along the X-axis, facing north/south
        int baseB = vertices.size();
        
        // Quad B vertices (facing +Z direction, centered at block position)
        vertices.add(new Vertex(
            new Vector3f(x, y + halfHeight, z + halfWidth),  // Top-left
            new Vector2f(0f, 0f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x, y - halfHeight, z + halfWidth),  // Bottom-left
            new Vector2f(0f, 1f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x, y - halfHeight, z - halfWidth),  // Bottom-right
            new Vector2f(1f, 1f), blockTextureID, sunLevel, blockLevel, ao
        ));
        vertices.add(new Vertex(
            new Vector3f(x, y + halfHeight, z - halfWidth),  // Top-right
            new Vector2f(1f, 0f), blockTextureID, sunLevel, blockLevel, ao
        ));
        
        // Quad B indices (two triangles)
        indices.add(baseB + 0);
        indices.add(baseB + 1);
        indices.add(baseB + 2);
        indices.add(baseB + 0);
        indices.add(baseB + 2);
        indices.add(baseB + 3);
    }
    
    /**
     * Build vegetation mesh with crossed quads (X-shaped).
     * Only processes vegetation blocks (grass, flower, fern, dead_bush, mushroom).
     * 
     * @param visibility Face visibility checker (not used for vegetation, but kept for consistency)
     * @param quadWidth Width of vegetation quads (default 1.0)
     * @param quadHeight Height of vegetation quads (default 1.0)
     */
    public void buildVegetationMesh(FaceVisibility visibility, float quadWidth, float quadHeight) {
        List<Vertex> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();
        
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                for (int z = 0; z < sizeZ; z++) {
                    int block = blocks[x][y][z];
                    
                    // Only process vegetation blocks
                    if (!BlockType.isVegetation(block)) continue;
                    
                    // Only render if there's air above (vegetation needs space)
                    // Actually, vegetation can be placed on any solid block, so we'll render it
                    // The visibility check is mainly for optimization, but vegetation always renders
                    addCrossedQuads(vertices, indices, x, y, z, block, visibility, quadWidth, quadHeight);
                }
            }
        }
        
        if (vertices.isEmpty()) {
            vegetationMesh = null;
            return;
        }
        
        vegetationMesh = new Mesh(
            vertices.toArray(new Vertex[0]),
            indices.stream().mapToInt(i -> i).toArray(),
            material
        );
        vegetationMesh.create();
    }
    
    /**
     * Build vegetation mesh with default quad size (1.0 x 1.0).
     */
    public void buildVegetationMesh(FaceVisibility visibility) {
        buildVegetationMesh(visibility, 1.0f, 1.0f);
    }

    /**
     * Generate caves using 3D Perlin noise.
     * Creates a smoothed 3D noise field and carves out caves where noise values
     * fall below a threshold, creating tunnels and cave systems.
     */
    private void generateCaves() {
        // Cave generation parameters
        double caveScale = 0.04; // Controls cave size - smaller = larger caves (more open underground)
        int caveOctaves = 2; // Number of noise layers for smoother caves
        double cavePersistence = 0.5; // How much each octave contributes
        double caveThreshold = 0.25; // Threshold below which blocks become air (caves)
        // Lower threshold = more caves/open spaces, higher threshold = fewer caves
        
        final int MAX_CAVE_HEIGHT = 30; // Maximum Y coordinate for caves (caves only below y=30)
        
        // Seed offset for caves (different from terrain to create varied caves)
        double seedOffsetX = (seed % 10000) * 1000.0 + 50000.0;
        double seedOffsetY = ((seed / 10000) % 10000) * 100.0;
        double seedOffsetZ = ((seed / 100000000) % 10000) * 1000.0 + 50000.0;
        
        // Only generate caves in solid blocks (dirt)
        for (int x = 0; x < sizeX; x++) {
            for (int y = 0; y < sizeY; y++) {
                for (int z = 0; z < sizeZ; z++) {
                    // Only carve caves in solid blocks (dirt)
                    if (blocks[x][y][z] == 1) { // dirt
                        // Calculate world coordinates
                        int worldX = originX + x;
                        int worldY = originY + y;
                        int worldZ = originZ + z;
                        
                        // Only generate caves below the maximum cave height
                        if (worldY >= MAX_CAVE_HEIGHT) {
                            continue; // Skip cave generation for blocks at or above y=30
                        }
                        
                        // Generate 3D noise value (-1.0 to 1.0) with seed offset
                        // This creates a smoothed 3D field of random values
                        double noiseValue = Noise.octaveNoise3D(
                            worldX + seedOffsetX, worldY + seedOffsetY, worldZ + seedOffsetZ,
                            caveOctaves, cavePersistence, caveScale
                        );
                        
                        // Convert noise to 0-1 range for easier threshold comparison
                        double normalizedNoise = (noiseValue + 1.0) * 0.5;
                        
                        // If noise is below threshold, create a cave (air)
                        if (normalizedNoise < caveThreshold) {
                            blocks[x][y][z] = 0; // air (cave)
                        }
                    }
                }
            }
        }
    }

    private void generateTrees() {
        if (originY != 0) return;
        if (chunkRandom.nextDouble() > 0.08) return;

        int tx = chunkRandom.nextInt(sizeX);
        int tz = chunkRandom.nextInt(sizeZ);

        int ty = -1;
        for (int y = sizeY - 1; y >= 0; y--) {
            if (blocks[tx][y][tz] == 1) {
                ty = y + 1;
                break;
            }
        }
        if (ty < 0 || ty + 6 >= sizeY) return;

        int height = 4 + chunkRandom.nextInt(3);

        for (int i = 0; i < height; i++) {
            blocks[tx][ty + i][tz] = 2; // log
        }

        int leafStart = ty + height - 2;
        for (int x = -2; x <= 2; x++) {
            for (int y = 0; y <= 3; y++) {
                for (int z = -2; z <= 2; z++) {
                    int lx = tx + x;
                    int ly = leafStart + y;
                    int lz = tz + z;

                    if (lx < 0 || ly < 0 || lz < 0 ||
                        lx >= sizeX || ly >= sizeY || lz >= sizeZ)
                        continue;

                    if (Math.abs(x) == 2 && Math.abs(z) == 2) continue;

                    if (blocks[lx][ly][lz] == 0) {
                        blocks[lx][ly][lz] = 3; // leaves
                    }
                }
            }
        }
    }
    
    /**
     * Generate vegetation on the ground (grass, flowers, ferns, dead bushes, mushrooms).
     * Places vegetation randomly on top of dirt blocks, similar to tree generation.
     * No special rules - just random placement.
     */
    private void generateVegetation() {
        // Only generate vegetation on ground-level chunks
        if (originY != 0) return;
        
        // Iterate through all positions in the chunk
        for (int x = 0; x < sizeX; x++) {
            for (int z = 0; z < sizeZ; z++) {
                // Find the top dirt block
                int topDirtY = -1;
                for (int y = sizeY - 1; y >= 0; y--) {
                    if (blocks[x][y][z] == 1) { // dirt
                        topDirtY = y;
                        break;
                    }
                }
                
                // If we found dirt and there's air above it, randomly place vegetation
                if (topDirtY >= 0 && topDirtY + 1 < sizeY && blocks[x][topDirtY + 1][z] == 0) {
                    // Random chance to place vegetation (15% chance per dirt block)
                    if (chunkRandom.nextDouble() < 0.15) {
                        // Randomly select vegetation type
                        double rand = chunkRandom.nextDouble();
                        int vegetationType;
                        
                        if (rand < 0.4) {
                            vegetationType = 5; // grass (40% chance)
                        } else if (rand < 0.6) {
                            vegetationType = 6; // flower (20% chance)
                        } else if (rand < 0.75) {
                            vegetationType = 7; // fern (15% chance)
                        } else if (rand < 0.9) {
                            vegetationType = 8; // dead_bush (15% chance)
                        } else {
                            vegetationType = 9; // mushroom (10% chance)
                        }
                        
                        // Place vegetation on top of dirt
                        blocks[x][topDirtY + 1][z] = vegetationType;
                    }
                }
            }
        }
    }

    private int getTextureIndex(int blockID) {
        switch (blockID) {
            case 1: return 0; // dirt
            case 2: return 1; // log
            case 3: return 2; // leaves
            case 4: return 3; // leaves
            default: return 0;
        }
    }
    
    /**
     * Get texture index for vegetation blocks.
     * Vegetation textures are bound to slots 4-8 in the renderer.
     */
    private int getVegetationTextureIndex(int blockID) {
        switch (blockID) {
            case 5: return 4; // grass
            case 6: return 5; // flower
            case 7: return 6; // fern
            case 8: return 7; // dead_bush
            case 9: return 8; // mushroom
            default: return 4; // fallback to grass
        }
    }

    public Mesh getMesh()            { return mesh; }
    public Mesh getVegetationMesh()  { return vegetationMesh; }
    public int  getOriginX()         { return originX; }
    public int  getOriginY()         { return originY; }
    public int  getOriginZ()         { return originZ; }
    
    public int  getSizeX()           { return sizeX; }
    public int  getSizeY()           { return sizeY; }
    public int  getSizeZ()           { return sizeZ; }

    public interface FaceVisibility {
        boolean isAir(int wx, int wy, int wz);
    }

    public int  getBlock(int x, int y, int z)        { return blocks[x][y][z]; }
    public byte getLight(int x, int y, int z)        { return light[x][y][z]; }
    public void setLight(int x, int y, int z, byte v){ light[x][y][z] = v; }
    public void setBlock(int x, int y, int z, int v) { blocks[x][y][z] = v; }
    
    public byte getSkyLight(int x, int y, int z)     { return skyLight[x][y][z]; }
    public void setSkyLight(int x, int y, int z, byte v) { skyLight[x][y][z] = v; }
    public byte getBlockLight(int x, int y, int z)   { return blockLight[x][y][z]; }
    public void setBlockLight(int x, int y, int z, byte v) { blockLight[x][y][z] = v; }
}