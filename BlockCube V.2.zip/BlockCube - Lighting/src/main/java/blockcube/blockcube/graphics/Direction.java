package blockcube.blockcube.graphics;

public enum Direction {
    RIGHT, LEFT, TOP, BOTTOM, FRONT, BACK
}