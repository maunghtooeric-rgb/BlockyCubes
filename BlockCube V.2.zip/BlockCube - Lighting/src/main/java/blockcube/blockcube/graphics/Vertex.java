package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

public class Vertex {
    private Vector3f position;
    private Vector2f textureCoord;
    public int textureID;
    public float sunLight;    // 0–1, from skyLight
    public float blockLight;  // 0–1, from blockLight
    public float ambientOcclusion; // 0–1, shadow from adjacent blocks (1.0 = no shadow, 0.0 = full shadow)

    public Vertex(Vector3f position,
                  Vector2f textureCoord,
                  int textureID,
                  float sunLight,
                  float blockLight,
                  float ambientOcclusion) {
        this.position = position;
        this.textureCoord = textureCoord;
        this.textureID = textureID;
        this.sunLight = sunLight;
        this.blockLight = blockLight;
        this.ambientOcclusion = ambientOcclusion;
    }

    public Vector3f getPosition()     { return position; }
    public Vector2f getTextureCoord() { return textureCoord; }
}