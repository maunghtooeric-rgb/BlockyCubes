package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Pig model mesh - Minecraft Alpha-style with torso and 4 legs
 * 
 * Model structure:
 * - Torso: 0.9 x 0.9 x 1.2 (pink body)
 * - 4 Legs: 0.2 x 0.5 x 0.2 each (pink legs at corners)
 * 
 * Each part is a separate mesh for individual rendering/animation
 */
public class PigMesh {
    private static Mesh torsoMesh;
    private static Mesh legMesh;
    
    // Pig colors (pink-ish)
    private static final float BODY_R = 0.96f;
    private static final float BODY_G = 0.76f;
    private static final float BODY_B = 0.76f;
    
    private static final float LEG_R = 0.90f;
    private static final float LEG_G = 0.70f;
    private static final float LEG_B = 0.70f;
    
    /**
     * Get the torso mesh (body of the pig)
     * Centered at origin, should be positioned at (0, LEG_HEIGHT + TORSO_HEIGHT/2, 0)
     */
    public static Mesh getTorso() {
        if (torsoMesh != null) return torsoMesh;
        
        float hw = 0.45f;  // Half width (0.9 / 2)
        float hh = 0.45f;  // Half height (0.9 / 2)
        float hd = 0.6f;   // Half depth (1.2 / 2)
        
        torsoMesh = createBox(hw, hh, hd, BODY_R, BODY_G, BODY_B);
        return torsoMesh;
    }
    
    /**
     * Get the leg mesh (one leg, reused for all 4)
     * Origin is at the TOP of the leg (hip joint) so rotation pivots correctly
     */
    public static Mesh getLeg() {
        if (legMesh != null) return legMesh;
        
        float hw = 0.1f;   // Half width (0.2 / 2)
        float hh = 0.25f;  // Half height (0.5 / 2)
        float hd = 0.1f;   // Half depth (0.2 / 2)
        
        // Create leg with pivot at TOP (origin at hip joint)
        // The leg extends DOWNWARD from the origin
        legMesh = createBoxWithPivotTop(hw, hh, hd, LEG_R, LEG_G, LEG_B);
        return legMesh;
    }
    
    /**
     * Create a box mesh with pivot at the TOP (for leg rotation)
     * The box extends from y=0 (top/pivot) to y=-height (bottom)
     */
    private static Mesh createBoxWithPivotTop(float hw, float hh, float hd, float r, float g, float b) {
        List<Vertex> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();
        
        // Box from y=0 (top) to y=-2*hh (bottom)
        float top = 0;
        float bottom = -hh * 2;
        
        int baseIdx = 0;
        
        // Bottom face (-Y) - at the bottom of the leg
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, bottom, -hd),
            new Vector3f( hw, bottom, -hd),
            new Vector3f( hw, bottom,  hd),
            new Vector3f(-hw, bottom,  hd),
            r * 0.5f, g * 0.5f, b * 0.5f);
        baseIdx += 4;
        
        // Top face (+Y) - at the pivot point
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, top,  hd),
            new Vector3f( hw, top,  hd),
            new Vector3f( hw, top, -hd),
            new Vector3f(-hw, top, -hd),
            r, g, b);
        baseIdx += 4;
        
        // Front face (+Z)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, bottom,  hd),
            new Vector3f( hw, bottom,  hd),
            new Vector3f( hw, top,  hd),
            new Vector3f(-hw, top,  hd),
            r * 0.8f, g * 0.8f, b * 0.8f);
        baseIdx += 4;
        
        // Back face (-Z)
        addFace(vertices, indices, baseIdx,
            new Vector3f( hw, bottom, -hd),
            new Vector3f(-hw, bottom, -hd),
            new Vector3f(-hw, top, -hd),
            new Vector3f( hw, top, -hd),
            r * 0.8f, g * 0.8f, b * 0.8f);
        baseIdx += 4;
        
        // Right face (+X)
        addFace(vertices, indices, baseIdx,
            new Vector3f( hw, bottom,  hd),
            new Vector3f( hw, bottom, -hd),
            new Vector3f( hw, top, -hd),
            new Vector3f( hw, top,  hd),
            r * 0.7f, g * 0.7f, b * 0.7f);
        baseIdx += 4;
        
        // Left face (-X)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, bottom, -hd),
            new Vector3f(-hw, bottom,  hd),
            new Vector3f(-hw, top,  hd),
            new Vector3f(-hw, top, -hd),
            r * 0.7f, g * 0.7f, b * 0.7f);
        
        Vertex[] vertArray = vertices.toArray(new Vertex[0]);
        int[] idxArray = indices.stream().mapToInt(i -> i).toArray();
        
        Mesh mesh = new Mesh(vertArray, idxArray, null);
        mesh.create();
        return mesh;
    }
    
    /**
     * Create a box mesh centered at origin
     * @param hw Half width (X)
     * @param hh Half height (Y)
     * @param hd Half depth (Z)
     * @param r Red color component
     * @param g Green color component
     * @param b Blue color component
     */
    private static Mesh createBox(float hw, float hh, float hd, float r, float g, float b) {
        List<Vertex> vertices = new ArrayList<>();
        List<Integer> indices = new ArrayList<>();
        
        // Create a colored box (no texture, solid color via vertex color simulation)
        // We use the sunLevel and blockLevel to pass color info
        
        // 6 faces, 4 vertices each = 24 vertices
        int baseIdx = 0;
        
        // Bottom face (-Y)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, -hh, -hd),
            new Vector3f( hw, -hh, -hd),
            new Vector3f( hw, -hh,  hd),
            new Vector3f(-hw, -hh,  hd),
            r * 0.5f, g * 0.5f, b * 0.5f); // Darker bottom
        baseIdx += 4;
        
        // Top face (+Y)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw,  hh,  hd),
            new Vector3f( hw,  hh,  hd),
            new Vector3f( hw,  hh, -hd),
            new Vector3f(-hw,  hh, -hd),
            r, g, b); // Full brightness top
        baseIdx += 4;
        
        // Front face (+Z)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, -hh,  hd),
            new Vector3f( hw, -hh,  hd),
            new Vector3f( hw,  hh,  hd),
            new Vector3f(-hw,  hh,  hd),
            r * 0.8f, g * 0.8f, b * 0.8f);
        baseIdx += 4;
        
        // Back face (-Z)
        addFace(vertices, indices, baseIdx,
            new Vector3f( hw, -hh, -hd),
            new Vector3f(-hw, -hh, -hd),
            new Vector3f(-hw,  hh, -hd),
            new Vector3f( hw,  hh, -hd),
            r * 0.8f, g * 0.8f, b * 0.8f);
        baseIdx += 4;
        
        // Right face (+X)
        addFace(vertices, indices, baseIdx,
            new Vector3f( hw, -hh,  hd),
            new Vector3f( hw, -hh, -hd),
            new Vector3f( hw,  hh, -hd),
            new Vector3f( hw,  hh,  hd),
            r * 0.7f, g * 0.7f, b * 0.7f);
        baseIdx += 4;
        
        // Left face (-X)
        addFace(vertices, indices, baseIdx,
            new Vector3f(-hw, -hh, -hd),
            new Vector3f(-hw, -hh,  hd),
            new Vector3f(-hw,  hh,  hd),
            new Vector3f(-hw,  hh, -hd),
            r * 0.7f, g * 0.7f, b * 0.7f);
        
        Vertex[] vertArray = vertices.toArray(new Vertex[0]);
        int[] idxArray = indices.stream().mapToInt(i -> i).toArray();
        
        Mesh mesh = new Mesh(vertArray, idxArray, null);
        mesh.create();
        return mesh;
    }
    
    /**
     * Add a face (quad) to the mesh
     */
    private static void addFace(List<Vertex> vertices, List<Integer> indices, int baseIdx,
                                Vector3f v0, Vector3f v1, Vector3f v2, Vector3f v3,
                                float r, float g, float b) {
        // Use sunLevel to pass the color (shader will use this)
        // We pass it as the first component and use blockLevel for green, ao for blue
        vertices.add(new Vertex(v0, new Vector2f(0, 1), 0, r, g, b));
        vertices.add(new Vertex(v1, new Vector2f(1, 1), 0, r, g, b));
        vertices.add(new Vertex(v2, new Vector2f(1, 0), 0, r, g, b));
        vertices.add(new Vertex(v3, new Vector2f(0, 0), 0, r, g, b));
        
        // Two triangles
        indices.add(baseIdx);
        indices.add(baseIdx + 1);
        indices.add(baseIdx + 2);
        indices.add(baseIdx);
        indices.add(baseIdx + 2);
        indices.add(baseIdx + 3);
    }
    
    /**
     * Get leg position offsets for a pig (hip joint positions)
     * @param legIndex 0=front-left, 1=front-right, 2=back-left, 3=back-right
     * @return Position offset from entity feet position (hip joints at bottom of torso)
     */
    public static Vector3f getLegOffset(int legIndex) {
        float torsoHalfWidth = 0.45f;
        float torsoHalfDepth = 0.6f;
        float legInset = 0.15f; // How far inward from torso edge
        float legHeight = 0.5f; // Full leg height
        
        float xOffset = torsoHalfWidth - legInset;
        float zOffset = torsoHalfDepth - legInset;
        
        // Hip joints are at the bottom of the torso (top of legs)
        // Y offset is the leg height (hip is at leg_height above ground)
        switch (legIndex) {
            case 0: // Front-left
                return new Vector3f(-xOffset, legHeight, -zOffset);
            case 1: // Front-right
                return new Vector3f( xOffset, legHeight, -zOffset);
            case 2: // Back-left
                return new Vector3f(-xOffset, legHeight,  zOffset);
            case 3: // Back-right
                return new Vector3f( xOffset, legHeight,  zOffset);
            default:
                return new Vector3f(0, legHeight, 0);
        }
    }
    
    /**
     * Get the Y position of the torso center (above legs)
     */
    public static float getTorsoYOffset() {
        float legHeight = 0.5f;
        float torsoHalfHeight = 0.45f;
        return legHeight + torsoHalfHeight;
    }
    
    /**
     * Destroy all cached meshes
     */
    public static void destroy() {
        if (torsoMesh != null) {
            torsoMesh.destroy();
            torsoMesh = null;
        }
        if (legMesh != null) {
            legMesh.destroy();
            legMesh = null;
        }
    }
}
