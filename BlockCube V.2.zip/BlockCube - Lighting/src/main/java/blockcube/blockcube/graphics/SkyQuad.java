package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Vector2f;
import blockcube.blockcube.math.Vector3f;

public class SkyQuad {

    private static Mesh mesh;

    public static Mesh get() {
        if (mesh != null) return mesh;

        // Simple quad centered at origin, facing +Z
        Vertex[] v = new Vertex[] {
            new Vertex(new Vector3f(-0.5f, -0.5f, 0), new Vector2f(0, 1), 0, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f( 0.5f, -0.5f, 0), new Vector2f(1, 1), 0, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f( 0.5f,  0.5f, 0), new Vector2f(1, 0), 0, 1.0f, 0.0f, 1.0f),
            new Vertex(new Vector3f(-0.5f,  0.5f, 0), new Vector2f(0, 0), 0, 1.0f, 0.0f, 1.0f),
        };

        int[] idx = {
            0, 1, 2,
            0, 2, 3
        };

        mesh = new Mesh(v, idx, null);
        mesh.create();
        return mesh;
    }
}
