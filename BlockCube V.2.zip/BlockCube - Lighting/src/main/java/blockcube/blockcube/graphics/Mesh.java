package blockcube.blockcube.graphics;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import blockcube.blockcube.math.Vector2f;

public class Mesh {
    private Vertex[] vertices;
    private int[] indices;
    private Material material;

    private int vao;
    private int pbo; // position buffer
    private int ibo; // index buffer
    private int tbo; // uv buffer
    private int cbo; // texID buffer
    private int lbo; // sunLight buffer
    private int bbo; // blockLight buffer
    private int abo; // ambientOcclusion buffer

    public Mesh(Vertex[] vertices, int[] indices, Material material) {
        this.vertices = vertices;
        this.indices = indices;
        this.material = material;
    }

    public void create() {
        vao = GL30.glGenVertexArrays();
        GL30.glBindVertexArray(vao);

        // --- Positions -> location 0 (vec3) ---
        FloatBuffer positionBuffer = MemoryUtil.memAllocFloat(vertices.length * 3);
        float[] positionData = new float[vertices.length * 3];
        for (int i = 0; i < vertices.length; i++) {
            positionData[i * 3]     = vertices[i].getPosition().getX();
            positionData[i * 3 + 1] = vertices[i].getPosition().getY();
            positionData[i * 3 + 2] = vertices[i].getPosition().getZ();
        }
        positionBuffer.put(positionData).flip();

        pbo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, pbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, positionBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 0, 0); // aPos
        GL20.glEnableVertexAttribArray(0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(positionBuffer);

        // --- UVs -> location 1 (vec2) ---
        FloatBuffer uvBuffer = MemoryUtil.memAllocFloat(vertices.length * 2);
        float[] uvData = new float[vertices.length * 2];
        for (int i = 0; i < vertices.length; i++) {
            Vector2f uv = vertices[i].getTextureCoord();
            if (uv != null) {
                uvData[i * 2]     = uv.getX();
                uvData[i * 2 + 1] = uv.getY();
            } else {
                uvData[i * 2]     = 0f;
                uvData[i * 2 + 1] = 0f;
            }
        }
        uvBuffer.put(uvData).flip();

        tbo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, tbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, uvBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 0, 0); // aUV
        GL20.glEnableVertexAttribArray(1);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(uvBuffer);

        // --- Texture IDs -> location 2 (float) ---
        FloatBuffer texIDBuffer = MemoryUtil.memAllocFloat(vertices.length);
        float[] texIDData = new float[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            texIDData[i] = (float)vertices[i].textureID;
        }
        texIDBuffer.put(texIDData).flip();

        cbo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, cbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, texIDBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(2, 1, GL11.GL_FLOAT, false, 0, 0); // aTexID
        GL20.glEnableVertexAttribArray(2);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(texIDBuffer);

        // --- Sun light -> location 3 (float) ---
        FloatBuffer sunBuffer = MemoryUtil.memAllocFloat(vertices.length);
        float[] sunData = new float[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            sunData[i] = vertices[i].sunLight;
        }
        sunBuffer.put(sunData).flip();

        lbo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, lbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, sunBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(3, 1, GL11.GL_FLOAT, false, 0, 0); // aSunLight
        GL20.glEnableVertexAttribArray(3);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(sunBuffer);

        // --- Block light -> location 4 (float) ---
        FloatBuffer blockBuffer = MemoryUtil.memAllocFloat(vertices.length);
        float[] blockData = new float[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            blockData[i] = vertices[i].blockLight;
        }
        blockBuffer.put(blockData).flip();

        bbo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, bbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, blockBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(4, 1, GL11.GL_FLOAT, false, 0, 0); // aBlockLight
        GL20.glEnableVertexAttribArray(4);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(blockBuffer);

        // --- Ambient Occlusion -> location 5 (float) ---
        FloatBuffer aoBuffer = MemoryUtil.memAllocFloat(vertices.length);
        float[] aoData = new float[vertices.length];
        for (int i = 0; i < vertices.length; i++) {
            aoData[i] = vertices[i].ambientOcclusion;
        }
        aoBuffer.put(aoData).flip();

        abo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, abo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, aoBuffer, GL15.GL_STATIC_DRAW);
        GL20.glVertexAttribPointer(5, 1, GL11.GL_FLOAT, false, 0, 0); // aAmbientOcclusion
        GL20.glEnableVertexAttribArray(5);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        MemoryUtil.memFree(aoBuffer);

        // --- Indices (EBO) ---
        IntBuffer indicesBuffer = MemoryUtil.memAllocInt(indices.length);
        indicesBuffer.put(indices).flip();

        ibo = GL15.glGenBuffers();
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ibo);
        GL15.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, indicesBuffer, GL15.GL_STATIC_DRAW);
        MemoryUtil.memFree(indicesBuffer);

        // Done setting up VAO
        GL30.glBindVertexArray(0);
    }

    public void destroy() {
        GL15.glDeleteBuffers(pbo);
        GL15.glDeleteBuffers(ibo);
        GL15.glDeleteBuffers(tbo);
        GL15.glDeleteBuffers(cbo);
        GL15.glDeleteBuffers(lbo);
        GL15.glDeleteBuffers(bbo);
        GL15.glDeleteBuffers(abo);
        GL30.glDeleteVertexArrays(vao);
    }

    public Vertex[] getVertices() { return vertices; }
    public int[] getIndices()     { return indices; }
    public int getVAO()           { return vao; }
    public int getPBO()           { return pbo; }
    public int getCBO()           { return cbo; }
    public int getTBO()           { return tbo; }
    public int getIBO()           { return ibo; }
    public Material getMaterial() { return material; }
}