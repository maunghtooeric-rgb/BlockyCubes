package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Matrix4f;

/**
 * Frustum culling - extracts view frustum from view-projection matrix
 * and tests if chunks are visible
 */
public class Frustum {
    // 6 planes: left, right, bottom, top, near, far
    private Plane[] planes = new Plane[6];
    
    private static class Plane {
        float a, b, c, d; // Plane equation: ax + by + cz + d = 0
        
        Plane(float a, float b, float c, float d) {
            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
        }
        
        /**
         * Calculate distance from point to plane
         * Positive = in front of plane, Negative = behind plane
         */
        float distance(float x, float y, float z) {
            return a * x + b * y + c * z + d;
        }
    }
    
    /**
     * Update frustum from view-projection matrix
     * Uses the standard method for extracting frustum planes (like Minecraft)
     * Based on: http://www8.cs.umu.se/kurser/5DV051/HT12/lab/plane_extraction.pdf
     * 
     * For a view-projection matrix M, planes are extracted from rows:
     * - Left:   M[3] + M[0]
     * - Right:  M[3] - M[0]
     * - Bottom: M[3] + M[1]
     * - Top:    M[3] - M[1]
     * - Near:   M[3] + M[2]
     * - Far:    M[3] - M[2]
     * 
     * Note: get(x, y) returns element at column x, row y
     * So M[row][col] = get(col, row)
     */
    public void update(Matrix4f view, Matrix4f projection) {
        // Combine view and projection matrices: projection * view
        Matrix4f viewProj = Matrix4f.multiply(projection, view);
        
        // Extract planes using standard method
        // Left plane: M[3] + M[0] where M[row][col] = get(col, row)
        planes[0] = extractPlane(viewProj, 0);
        
        // Right plane: M[3] - M[0]
        planes[1] = extractPlane(viewProj, 0, true);
        
        // Bottom plane: M[3] + M[1]
        planes[2] = extractPlane(viewProj, 1);
        
        // Top plane: M[3] - M[1]
        planes[3] = extractPlane(viewProj, 1, true);
        
        // Near plane: M[3] + M[2]
        planes[4] = extractPlane(viewProj, 2);
        
        // Far plane: M[3] - M[2]
        planes[5] = extractPlane(viewProj, 2, true);
    }
    
    /**
     * Extract a plane from the view-projection matrix
     * @param m The view-projection matrix
     * @param rowIndex Row index (0, 1, or 2) to combine with row 3
     * @param subtract If true, subtract row from row3, else add
     */
    private Plane extractPlane(Matrix4f m, int rowIndex, boolean subtract) {
        // Extract plane coefficients from matrix rows
        // M[row][col] = get(col, row)
        // For left plane: M[3][col] + M[0][col] = get(col, 3) + get(col, 0)
        float a = m.get(0, 3) + (subtract ? -m.get(0, rowIndex) : m.get(0, rowIndex));
        float b = m.get(1, 3) + (subtract ? -m.get(1, rowIndex) : m.get(1, rowIndex));
        float c = m.get(2, 3) + (subtract ? -m.get(2, rowIndex) : m.get(2, rowIndex));
        float d = m.get(3, 3) + (subtract ? -m.get(3, rowIndex) : m.get(3, rowIndex));
        
        // Normalize the plane equation
        float length = (float)Math.sqrt(a * a + b * b + c * c);
        if (length > 0.0001f) {
            float invLength = 1.0f / length;
            a *= invLength;
            b *= invLength;
            c *= invLength;
            d *= invLength;
        }
        
        return new Plane(a, b, c, d);
    }
    
    private Plane extractPlane(Matrix4f m, int rowIndex) {
        return extractPlane(m, rowIndex, false);
    }
    
    /**
     * Test if an AABB (axis-aligned bounding box) intersects the frustum
     * @param minX Minimum X of the bounding box
     * @param minY Minimum Y of the bounding box
     * @param minZ Minimum Z of the bounding box
     * @param maxX Maximum X of the bounding box
     * @param maxY Maximum Y of the bounding box
     * @param maxZ Maximum Z of the bounding box
     * @return true if the AABB is inside or intersects the frustum
     */
    public boolean isAABBVisible(float minX, float minY, float minZ, 
                                 float maxX, float maxY, float maxZ) {
        // Test against all 6 planes
        // Use a small epsilon to avoid precision issues at frustum edges
        // Positive epsilon makes us more lenient (don't skip chunks that are barely visible)
        final float EPSILON = 0.0f; // Start with 0, can increase if needed
        
        for (Plane plane : planes) {
            // Find the point on the AABB that is farthest in the positive direction of the plane normal
            // If this point is behind the plane, the entire AABB is outside
            float px = plane.a > 0 ? maxX : minX;
            float py = plane.b > 0 ? maxY : minY;
            float pz = plane.c > 0 ? maxZ : minZ;
            
            // If the farthest point is behind the plane, the AABB is outside
            // Distance > 0 means point is in front of plane (inside frustum)
            // Distance < 0 means point is behind plane (outside frustum)
            if (plane.distance(px, py, pz) < EPSILON) {
                return false; // AABB is completely outside this plane
            }
        }
        
        return true; // AABB is inside or intersects the frustum
    }
    
    /**
     * Test if a chunk is visible in the frustum
     * @param chunk The chunk to test
     * @return true if the chunk is visible
     */
    public boolean isChunkVisible(Chunk chunk) {
        float minX = chunk.getOriginX();
        float minY = chunk.getOriginY();
        float minZ = chunk.getOriginZ();
        float maxX = minX + chunk.getSizeX();
        float maxY = minY + chunk.getSizeY();
        float maxZ = minZ + chunk.getSizeZ();
        
        return isAABBVisible(minX, minY, minZ, maxX, maxY, maxZ);
    }
}
