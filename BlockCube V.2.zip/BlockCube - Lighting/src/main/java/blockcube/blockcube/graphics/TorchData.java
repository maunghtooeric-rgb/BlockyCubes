package blockcube.blockcube.graphics;

import blockcube.blockcube.math.Vector3f;

/**
 * Stores torch placement data: the face normal and the exact hit position on that face.
 */
public class TorchData {
    private final Vector3f normal;      // Face normal (which face the torch is on)
    private final Vector3f hitPosition; // Exact position where raycast hit the face
    
    public TorchData(Vector3f normal, Vector3f hitPosition) {
        this.normal = normal;
        this.hitPosition = hitPosition;
    }
    
    public Vector3f getNormal() {
        return normal;
    }
    
    public Vector3f getHitPosition() {
        return hitPosition;
    }
}
