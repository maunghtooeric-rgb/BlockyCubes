package blockcube;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

import blockcube.blockcube.graphics.BlockType;
import blockcube.blockcube.graphics.Chunk;
import blockcube.blockcube.graphics.ChunkManager;
import blockcube.blockcube.graphics.Material;
import blockcube.blockcube.graphics.Mesh;
import blockcube.blockcube.graphics.Renderer;
import blockcube.blockcube.graphics.Shader;
import blockcube.blockcube.graphics.TorchData;
import blockcube.blockcube.io.Input;
import blockcube.blockcube.io.Window;
import blockcube.blockcube.math.Vector3f;
import blockcube.blockcube.objects.Camera;
import blockcube.blockcube.objects.GameObject;
import blockcube.blockcube.particle.ParticleSystem;
import blockcube.blockcube.raycast.RaycastResult;
import blockcube.blockcube.raycast.Raycaster;
import blockcube.blockcube.world.DayNightCycle;
import blockcube.blockcube.entity.Entity;
import blockcube.blockcube.entity.EntityManager;
import blockcube.blockcube.graphics.PigMesh;

public class Main implements Runnable {
    public Thread game;
    public Window window;
    public Renderer renderer;
    public Shader shader;
    public final int WIDTH = 1280, HEIGHT = 760;
    private Chunk chunk;
    private ChunkManager chunkManager;
    private EntityManager entityManager;
    private ParticleSystem particleSystem;
    public Shader particleShader;  // NEW: particle shader

    //Materials
    
    private Material dirt;
    private Material log;
    private Material leaves;
    private Material break1;
    private Material break2;
    private Material break3;
    private Material break4;
    private Material lightBlock;
    
    // Vegetation textures
    private Material grass;
    private Material flower;
    private Material fern;
    private Material deadBush;
    private Material mushroom;
    
    // Torch texture (white for debug)
    private Material torch;

    private boolean leftClickDown = false;
    private boolean rightClickDown = false;
    private boolean f11Pressed = false; // Track F11 key state to prevent rapid toggling
    private boolean xRayMode = false; // X-ray debug mode (makes chunk blocks transparent)
    private boolean xKeyPressed = false; // Track X key state to prevent rapid toggling
    private boolean torchDebugMode = false; // Torch position debug mode
    private boolean tKeyPressed = false; // Track T key state to prevent rapid toggling
    private boolean flyMode = false; // Fly debug mode
    private boolean fKeyPressed = false; // Track F key state to prevent rapid toggling
    
    // Torch debug offset (adjustable with WASD/SPACE/SHIFT when debug mode is enabled)
    private Vector3f torchDebugOffset = new Vector3f(0, 0, 0);
    // Torch debug Y rotation (adjustable with left/right arrows when debug mode is enabled)
    private float torchDebugRotationY = 0.0f;

    private int currentBlockToPlace = 1; // default = dirt

    //Camera

    public Camera camera = new Camera(new Vector3f(0, 60, 0), new Vector3f(0, 0, 0));

    // Breaking
    private boolean isBreaking = false;
    private float breakProgress = 0f;
    private final float breakSpeed = 1.0f; // seconds per full break
    private int breakFrame = 0;
    private RaycastResult lastHit = null;
    private DayNightCycle dayNight;

    public void start() {
        game = new Thread(this, "game");
        game.start();
    }

    public void init() {

        window = new Window(WIDTH, HEIGHT, "BlockCube");
        
        shader = new Shader("/shaders/mainVertex.glsl", "/shaders/mainFragment.glsl");
        particleShader = new Shader("/shaders/particleVertex.glsl", "/shaders/particleFragment.glsl");
        
        renderer = new Renderer(window, shader, particleShader);

        window.setBGColor(1.0f, 0, 0);
        window.create(); // GL context becomes current here

        //Initialize Game

        // Global GL state
        GL11.glDisable(GL11.GL_CULL_FACE);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthFunc(GL11.GL_LESS);
        
        // Create shaders
        shader.create();
        particleShader.create();
        
        shader.bind();
        shader.setUniform("textures[0]", 0);
        shader.setUniform("textures[1]", 1);
        shader.setUniform("textures[2]", 2);
        shader.unbind();

        // Load ALL block textures (use fields, no new locals)
        dirt   = new Material("/textures/Dirt.png");
        log    = new Material("/textures/log.png");
        leaves = new Material("/textures/leaves.png");
        break1 = new Material("/textures/break_anim/BA_01.png");
        break2 = new Material("/textures/break_anim/BA_02.png");
        break3 = new Material("/textures/break_anim/BA_03.png");
        break4 = new Material("/textures/break_anim/BA_04.png");
        
        // Load vegetation textures
        grass = new Material("/textures/grass.png");
        flower = new Material("/textures/flower.png");
        fern = new Material("/textures/fern.png");
        deadBush = new Material("/textures/dead_bush.png");
        mushroom = new Material("/textures/mushroom.png");
        
        // Torch texture (using Dirt.png as white placeholder for debug)
        torch = new Material("/textures/Dirt.png");
        
        //Light Block Setup
        lightBlock = new Material("/textures/Dirt.png");
        lightBlock.create();

        //Material Creation
        dirt.create();
        log.create();
        leaves.create();

        break1.create();
        break2.create();
        break3.create();
        break4.create();
        
        // Create vegetation textures
        grass.create();
        flower.create();
        fern.create();
        deadBush.create();
        mushroom.create();
        
        // Create torch texture
        torch.create();
        
        // Create particle and cycle systems
        particleSystem = new ParticleSystem(dirt.getTextureID());
        
        dayNight = new DayNightCycle(0.002f); // 50 seconds per full cycle

        // Create chunk manager (sizeX, sizeY, sizeZ, loadRadius, unloadRadius, material)
        // Changed sizeY from 128 to 32 blocks tall
        // Render distance: 4 chunks, unload distance: 4 chunks
        chunkManager = new ChunkManager(16, 32, 16, 4, 4, dirt);
        
        // Load saved world data (seed, time, block modifications, torch data)
        // If no save file exists, a new world is generated with a random seed
        chunkManager.loadWorld();
        
        // Restore day/night cycle time from saved world
        dayNight.setTime(chunkManager.getTimeOfDay());
        
        // Reset pig mesh cache to ensure fresh mesh creation
        PigMesh.destroy();
        
        // Create entity manager for mobs
        entityManager = new EntityManager(chunkManager);
        
        // Set up chunk manager to spawn entities when new chunks are created
        chunkManager.setChunkCreatedCallback(chunk -> {
            entityManager.spawnEntitiesInChunk(chunk);
        });

        // Give renderer the texture IDs
        renderer.setBreakTextures(break1, break2, break3, break4);
        renderer.setBlockTextures(dirt, log, leaves, lightBlock);
        renderer.setVegetationTextures(grass, flower, fern, deadBush, mushroom);
        renderer.setTorchTexture(torch);

        window.mouseState(true);

        // keep a reference for destroy()
        //this.dirt = dirt;
    }

    public void run() {
        init();
        while (!window.shouldClose() && !Input.isKeyDown(GLFW.GLFW_KEY_ESCAPE)) {
            update();
            render();
            
            // Handle F11 fullscreen toggle (only toggle once per key press)
            boolean f11CurrentlyPressed = Input.isKeyDown(GLFW.GLFW_KEY_F11);
            if (f11CurrentlyPressed && !f11Pressed) {
                // F11 was just pressed (wasn't pressed last frame)
                window.setFullscreen(!window.isFullscreen());
            }
            f11Pressed = f11CurrentlyPressed;
            
            if (Input.isKeyDown(GLFW.GLFW_KEY_E)) window.mouseState(false);
        }
        close();
    }

    private void update() {

        //Game logic updates
        window.update();
        // Disable camera movement when torch debug mode is enabled
        camera.update(chunkManager, !torchDebugMode, flyMode);
        chunkManager.update(camera.getPosition());
    
        dayNight.update((float) window.getDeltaTime());
        
        // Update entities (pass player position for AI behaviors)
        if (entityManager != null) {
            entityManager.setPlayerPosition(camera.getPosition());
            entityManager.update((float) window.getDeltaTime());
        }
        
        //Debug particleSystem null check
        if (particleSystem == null) {
            System.out.println("particleSystem is NULL in update!");
        }

        // Block switching
        if (Input.isKeyDown(GLFW.GLFW_KEY_1)) currentBlockToPlace = 1; // dirt
        if (Input.isKeyDown(GLFW.GLFW_KEY_2)) currentBlockToPlace = 2; // log
        if (Input.isKeyDown(GLFW.GLFW_KEY_3)) currentBlockToPlace = 3; // leaves
        if (Input.isKeyDown(GLFW.GLFW_KEY_4)) currentBlockToPlace = 4; // light source (emits block light)
        
        // Vegetation block selection (starting after 4)
        if (Input.isKeyDown(GLFW.GLFW_KEY_5)) currentBlockToPlace = 5; // grass
        if (Input.isKeyDown(GLFW.GLFW_KEY_6)) currentBlockToPlace = 6; // flower
        if (Input.isKeyDown(GLFW.GLFW_KEY_7)) currentBlockToPlace = 7; // fern
        if (Input.isKeyDown(GLFW.GLFW_KEY_8)) currentBlockToPlace = 8; // dead_bush
        if (Input.isKeyDown(GLFW.GLFW_KEY_9)) currentBlockToPlace = 9; // mushroom
        
        // Torch selection (key 0)
        if (Input.isKeyDown(GLFW.GLFW_KEY_0)) currentBlockToPlace = BlockType.TORCH.id; // torch
        
        // X-ray debug mode toggle (X key)
        boolean xKeyCurrentlyPressed = Input.isKeyDown(GLFW.GLFW_KEY_X);
        if (xKeyCurrentlyPressed && !xKeyPressed) {
            xRayMode = !xRayMode;
        }
        xKeyPressed = xKeyCurrentlyPressed;
        
        // Torch debug mode toggle (T key)
        boolean tKeyCurrentlyPressed = Input.isKeyDown(GLFW.GLFW_KEY_T);
        if (tKeyCurrentlyPressed && !tKeyPressed) {
            torchDebugMode = !torchDebugMode;
            if (!torchDebugMode) {
                // Reset offset and rotation when disabling debug mode
                torchDebugOffset = new Vector3f(0, 0, 0);
                torchDebugRotationY = 0.0f;
            }
            System.out.println("Torch debug mode: " + (torchDebugMode ? "ENABLED" : "DISABLED"));
        }
        tKeyPressed = tKeyCurrentlyPressed;
        
        // Fly mode toggle (F key)
        boolean fKeyCurrentlyPressed = Input.isKeyDown(GLFW.GLFW_KEY_F);
        if (fKeyCurrentlyPressed && !fKeyPressed) {
            flyMode = !flyMode;
            System.out.println("Fly mode: " + (flyMode ? "ENABLED" : "DISABLED"));
        }
        fKeyPressed = fKeyCurrentlyPressed;
        
        // Torch position adjustment with WASD/SPACE/SHIFT (only when debug mode is enabled)
        if (torchDebugMode) {
            float debugSpeed = 0.1f; // Speed of position adjustment
            float rotationSpeed = 1.0f; // Speed of rotation adjustment (degrees per frame)
            
            // Y movement (up/down)
            if (Input.isKeyDown(GLFW.GLFW_KEY_W)) {
                torchDebugOffset.setY(torchDebugOffset.getY() + debugSpeed);
            }
            if (Input.isKeyDown(GLFW.GLFW_KEY_S)) {
                torchDebugOffset.setY(torchDebugOffset.getY() - debugSpeed);
            }
            if (Input.isKeyDown(GLFW.GLFW_KEY_SPACE)) {
                torchDebugOffset.setY(torchDebugOffset.getY() + debugSpeed);
            }
            if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT_SHIFT) || Input.isKeyDown(GLFW.GLFW_KEY_RIGHT_SHIFT)) {
                torchDebugOffset.setY(torchDebugOffset.getY() - debugSpeed);
            }
            
            // X movement (left/right)
            if (Input.isKeyDown(GLFW.GLFW_KEY_A)) {
                torchDebugOffset.setX(torchDebugOffset.getX() - debugSpeed);
            }
            if (Input.isKeyDown(GLFW.GLFW_KEY_D)) {
                torchDebugOffset.setX(torchDebugOffset.getX() + debugSpeed);
            }
            
            // Y rotation (left/right arrows)
            if (Input.isKeyDown(GLFW.GLFW_KEY_LEFT)) {
                torchDebugRotationY -= rotationSpeed;
            }
            if (Input.isKeyDown(GLFW.GLFW_KEY_RIGHT)) {
                torchDebugRotationY += rotationSpeed;
            }
        }

        RaycastResult hit = Raycaster.raycast(camera, chunkManager, 10.0f);

        //Placing and breaking blocks
        if (hit != null) {

            // LEFT CLICK = break
            if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_1)) {
                if (lastHit != null &&
                    lastHit.getBlockX() == hit.getBlockX() &&
                    lastHit.getBlockY() == hit.getBlockY() &&
                    lastHit.getBlockZ() == hit.getBlockZ()) {

                    isBreaking = true;
                    breakProgress += window.getDeltaTime();

                    // Determine animation frame (0–3)
                    breakFrame = Math.min(3, (int)((breakProgress / breakSpeed) * 4));

                    if (breakProgress >= breakSpeed) {
                    	                    	
                    	int blockID = chunkManager.getBlockAtWorld(hit.getBlockX(), hit.getBlockY(), hit.getBlockZ());
                    	
                        chunkManager.setBlockAtWorld(hit.getBlockX(), hit.getBlockY(), hit.getBlockZ(), 0);
                        // Lighting is automatically recomputed in setBlockAtWorld
                        
                        Vector3f n = hit.getNormal().mul(0.1f);
                        Vector3f spawnPos = new Vector3f(
                            hit.getHitPos().getX() + n.getX(),
                            hit.getHitPos().getY() + n.getY(),
                            hit.getHitPos().getZ() + n.getZ()
                        );

                        // Get texture for block (handles both solid blocks and vegetation)
                        int texID;
                        if (BlockType.isVegetation(blockID)) {
                            texID = renderer.getTextureForVegetation(blockID);
                        } else {
                            texID = renderer.getTextureForBlock(blockID);
                        }

                        particleSystem.spawn(spawnPos, 12, texID);
                        
                        isBreaking = false;
                        breakProgress = 0;
                    }

                } else {
                    // New block targeted
                    isBreaking = true;
                    breakProgress = 0;
                    breakFrame = 0;
                }
            } else {
                isBreaking = false;
                breakProgress = 0;
                breakFrame = 0;
            }

            // RIGHT CLICK = place block
            if (Input.isButtonDown(GLFW.GLFW_MOUSE_BUTTON_2)) {
                if (!rightClickDown) {
                    rightClickDown = true;

                    System.out.println("Place at: " + hit.getPlaceX() + ", " + hit.getPlaceY() + ", " + hit.getPlaceZ());
                    System.out.println("Player at: " + camera.getPosition());
                    
                    //Vector3f n = hit.getNormal();

                    int placeX = hit.getPlaceX();
                    int placeY = hit.getPlaceY();
                    int placeZ = hit.getPlaceZ();

                    chunkManager.setBlockAtWorld(placeX, placeY, placeZ, currentBlockToPlace);
                    
                    // If placing a torch, store its data (normal and hit position)
                    // The normal points INTO the hit block, so we negate it to get the face the torch is placed ON
                    if (currentBlockToPlace == BlockType.TORCH.id) {
                        Vector3f hitPos = hit.getHitPos(); // Exact position where raycast hit the face
                        Vector3f n = hit.getNormal(); // DO NOT FLIP HERE
                        chunkManager.setTorchData(placeX, placeY, placeZ, n, hitPos);
                    }


                    
                    // Lighting is automatically recomputed in setBlockAtWorld
                }
            } else {
                rightClickDown = false;
            }

            lastHit = hit;
        }
        
        particleSystem.update((float) window.getDeltaTime());
    }

    private void render() {
    	
        //Render game
    	float[] sky = dayNight.getSkyColor();
    	window.setBGColor(sky[0], sky[1], sky[2]);
    	
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
        
        shader.bind();
        shader.setUniform("daylight", dayNight.getDaylight());
        // Set default alpha (opaque) - will be overridden by renderMesh if x-ray is enabled
        shader.setUniform("alpha", 1.0f);
        shader.unbind();

        // Render solid blocks (chunks) - with x-ray mode if enabled
        for (Chunk c : chunkManager.getChunks()) {
            Mesh m = c.getMesh();
            if (m == null || m.getIndices() == null || m.getIndices().length == 0) continue;

            GameObject chunkGO = new GameObject(
                new Vector3f(c.getOriginX(), c.getOriginY(), c.getOriginZ()),
                new Vector3f(0, 0, 0),
                new Vector3f(1, 1, 1),
                m
            );
            renderer.renderMesh(chunkGO, camera, xRayMode);
        }
        
        // Render vegetation (crossed quads) after solid blocks
        for (Chunk c : chunkManager.getChunks()) {
            Mesh vegMesh = c.getVegetationMesh();
            if (vegMesh == null || vegMesh.getIndices() == null || vegMesh.getIndices().length == 0) continue;

            GameObject vegGO = new GameObject(
                new Vector3f(c.getOriginX(), c.getOriginY(), c.getOriginZ()),
                new Vector3f(0, 0, 0),
                new Vector3f(1, 1, 1),
                vegMesh
            );
            renderer.renderVegetationMesh(vegGO, camera);
        }
        
        // Render torches (after vegetation, before particles)
        for (Chunk c : chunkManager.getChunks()) {
            // Check all blocks in this chunk for torches
            for (int x = 0; x < 16; x++) {
                for (int y = 0; y < 32; y++) {
                    for (int z = 0; z < 16; z++) {
                        int blockID = c.getBlock(x, y, z);
                        if (blockID == BlockType.TORCH.id) {
                            // Get world position
                            int wx = c.getOriginX() + x;
                            int wy = c.getOriginY() + y;
                            int wz = c.getOriginZ() + z;
                            
                            // Get torch data (normal) - must exist from raycast
                            TorchData torchData = chunkManager.getTorchData(wx, wy, wz);
                            if (torchData == null) {
                                // Skip rendering if no torch data (shouldn't happen if placed correctly)
                                continue;
                            }
                            
                            // Get normal for rotation calculation
                            Vector3f normal = torchData.getNormal();
                            
                            // Apply debug offset and rotation if debug mode is enabled
                            if (torchDebugMode) {
                                // Print torch position every frame when debug mode is enabled
                                System.out.println(String.format("Torch Block: X=%d Y=%d Z=%d | Rotation Y=%.1f", 
                                    wx, wy, wz, torchDebugRotationY));
                                renderer.renderTorch(wx, wy, wz, normal, camera, torchDebugRotationY);
                            } else {
                                renderer.renderTorch(wx, wy, wz, normal, camera, 0.0f);
                            }
                        }
                    }
                }
            }
        }

        // Break overlay
        if (isBreaking && lastHit != null) {
            renderer.renderBreakOverlay(
                new Vector3f(
                    lastHit.getBlockX(),
                    lastHit.getBlockY(),
                    lastHit.getBlockZ()
                ),
                breakFrame,
                camera
            );
        }
        
        particleSystem.render(renderer, camera);
        
        // Render entities (pigs, etc.)
        if (entityManager != null) {
            for (Entity entity : entityManager.getEntities()) {
                renderer.renderEntity(entity, camera);
            }
        }

        // Render sun/moon (Minecraft-style sky renderer)
        renderSkyObjects(camera, dayNight);

        // Outline cube and face highlighting
        RaycastResult hit = Raycaster.raycast(camera, chunkManager, 10.0f);
        if (hit != null) {
            // Render outline cube
            renderer.renderOutlineCube(
                new Vector3f(
                    hit.getBlockX(),
                    hit.getBlockY(),
                    hit.getBlockZ()
                ),
                camera
            );
        }

        window.swapBuffers();
    }
    
    /**
     * Render sun and moon in the sky (Minecraft-style)
     * Sun and moon are fixed in world space, rotate around sky dome based on time
     */
    private void renderSkyObjects(Camera camera, DayNightCycle dayNight) {
        float time = dayNight.getTime();
        Vector3f cameraPos = camera.getPosition();
        
        // Sky dome parameters
        float skyRadius = 1000.0f; // Large radius so they appear infinitely far away
        float sunSize = 100.0f; // Size of sun quad
        float moonSize = 80.0f; // Size of moon quad
        
        // Calculate sun angle: rotates around sky dome
        // time = 0 -> midnight (bottom), time = 0.5 -> noon (top)
        // Sun starts at -90 degrees (bottom of circle)
        float sunAngleRad = (time * (float)Math.PI * 2.0f) - ((float)Math.PI / 2.0f);
        
        // Calculate sun position on vertical circle (Y-X plane)
        // Circle is perpendicular to X-Z ground plane
        float sunX = (float)Math.cos(sunAngleRad) * skyRadius;
        float sunY = (float)Math.sin(sunAngleRad) * skyRadius;
        float sunz = 0;
        
        // Moon is 180 degrees opposite (always opposite the sun)
        float moonAngleRad = sunAngleRad + (float)Math.PI;
        float moonX = (float)Math.cos(moonAngleRad) * skyRadius;
        float moonY = (float)Math.sin(moonAngleRad) * skyRadius;
        float moonZ = 0;
        
        // Position relative to camera (like Minecraft - they follow player but stay in world space)
        // The sun/moon are always at a fixed distance from the player
        Vector3f sunPos = new Vector3f(
            cameraPos.getX() + sunX,
            cameraPos.getY() + sunY,
            cameraPos.getZ() + sunz
        );
        
        Vector3f moonPos = new Vector3f(
            cameraPos.getX() + moonX,
            cameraPos.getY() + moonY,
            cameraPos.getZ() + moonZ
        );
        
        // Calculate rotation angle for quad orientation
        // SkyQuad faces +Z by default, rotate -90 around X to face downward, then add sky angle
        float sunRotationAngle = 0f;
        float moonRotationAngle = 0f;
        
        // Render sun (bright yellow/white)
        renderer.renderSun(sunPos, sunSize, sunRotationAngle, camera);
        
        // Render moon (bright blue/white)
        renderer.renderMoon(moonPos, moonSize, moonRotationAngle, camera);
    }
    
    private void close() {
        // Save world data before closing
        if (chunkManager != null) {
            // Store current time of day for persistence
            if (dayNight != null) {
                chunkManager.setTimeOfDay(dayNight.getTime());
            }
            chunkManager.saveWorld();
        }
        
        window.destory();
        if (chunk != null && chunk.getMesh() != null) chunk.getMesh().destroy();
        shader.destroy();
        if (dirt != null) dirt.destroy();
    }

    public static void main(String[] args) {
        new Main().start();
    }
}
